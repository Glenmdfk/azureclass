'''   ##########  Comienza importación de módulos ##########   '''
from  etl_oi import cnx,get_query
from datetime import date, timedelta, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Modulos generales
import os, sys, pathlib, socket, smtplib
import win32com.client as win32
from os.path import basename
from time import sleep
import win32com.client
import pandas as pd
#Email SMTP
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.message import EmailMessage as msg
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
#Email
olApp = win32.Dispatch('Outlook.Application')
olNS = olApp.GetNameSpace('MAPI')
#SQL Alchemy
#from sqlalchemy import create_engine
#from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.distro as distro
import Libraries.config as config
import Libraries.lib_mail as mail
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')

'''   ##########  Comienza definición de variables ##########   '''
#Fechas
today = date.today()
yesterday = today - timedelta(days = 1)
#Variables para Excel
xFile = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/AVAYA/ECHI/REPORTE/SKILL_14/President Office Skill 14 Generico.xlsx'
newFile = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/AVAYA/ECHI/REPORTE/SKILL_14/President Office Skill 14.xlsx'
the_path = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/AVAYA/ECHI/REPORTE/SKILL_14'
distro_sk14 = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/AVAYA/ECHI/ETL/SKILL 14/Distro.json'
#Detalles de ejecución
path_file = pathlib.Path(__file__)
st_hostn = socket.gethostname()
exec_path = str(os.getcwd())
#Mail Authentication
jVar = pd.read_json('C:\\App\\Variables\\Domain.json')
UsMail = jVar['Username']['OUTLOOK']
PsMail = jVar['Password']['PASS_OUTLOOK']
MailFrom = distro.GeneralNew['Sender']
Host = '135.208.33.18'
Port = 587
#Class name
Key = 'Skill_14'
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')

'''   ##########  Comineza ejecución del programa ##########   '''
class Skill_14:
    #1.Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
        self.no_info = 0
    #2.Conexión a SQL:
    def conn_red(self):
        try:
            
            server = config.DATAMANAGEMENT_CONFIG["Server"]
            #conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_ChardDM_Connection()})
            #conn_url = cnx()
            #engine = create_engine(conn_url)
            engine = cnx()
            conn = engine.raw_connection()
            cursor = conn.cursor()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa al servidor: ' + str(server))
            return engine, conn, cursor
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_red')
    #3.Queries
    def queries(self):
        qry_sk14 = """DECLARE @End DATE = CAST(GETDATE()-1 AS DATE) 
        DECLARE @St DATE = DATEADD(MONTH,-1,DATEADD(DAY,-DAY(@End)+1,@End)) 
        DECLARE @Start DATE = CASE WHEN DAY(@End) < 4 THEN @St ELSE DATEADD(DAY,-DAY(@End)+1,@End) END 
        SELECT 
            CAST(SegStart AS DATE) Fecha 
            ,COUNT(*) Cantidad 
        FROM [echi].[tbl_ECHI] e WITH(NOLOCK) 
        WHERE CAST(SegStart AS DATE) BETWEEN @Start AND @End 
            AND [DISPVDN] = 798462 AND [DISPSPLIT] = 14 
        GROUP BY CAST(SegStart AS DATE) ORDER BY Fecha"""
        return qry_sk14     
    #4.Actualizar archivo de Excel
    def upgrade_file(self):
        try:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Actualizando archivo Skill 14')
            sleep(5)
            File = win32com.client.Dispatch("Excel.Application")
            File.Visible = 0
            Workbook = File.Workbooks.open(xFile)
            Workbook.RefreshAll()
            File.DisplayAlerts = False
            Workbook.SaveAs(newFile)
            File.Quit()
            File.DisplayAlerts = True
            sleep(3)
            os.system('taskkill /IM excel.exe /F')
            sleep(3)
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Skill 14 fue actualizado correctamente')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on upgrade_file')
    #5.Distro
    def distro_skill14(self):
        try:
            Distribution_list = pd.read_json(distro_sk14)
            w32_separator = '; '
            smtp_separator = ', '
            #To Distro
            list_to = []
            for i in Distribution_list['Distribution_List']['To']['to_distro']:
                list_to.append(Distribution_list['Distribution_List']['To']['to_distro'][i])
            MailTo = smtp_separator.join(list_to)
            wMailTo = w32_separator.join(list_to)
            #Cc Distro
            list_cc = []
            for j in Distribution_list['Distribution_List']['CC']['cc_distro']:
                list_cc.append(Distribution_list['Distribution_List']['CC']['cc_distro'][j])
            MailCC = smtp_separator.join(list_cc)
            wMailCC = w32_separator.join(list_cc)
            #BCc Distro
            list_bcc = []
            for k in Distribution_list['Distribution_List']['BCC']['bcc_distro']:
                list_bcc.append(Distribution_list['Distribution_List']['BCC']['bcc_distro'][k])
            MailBCC = smtp_separator.join(list_bcc)
            wMailBCC = w32_separator.join(list_bcc)
            #To Client
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lista de Distribución establecida') 
            self.trns += 1
            return MailTo, MailCC, MailBCC, wMailTo, wMailCC, wMailBCC
        except Exception as error:
            self.err += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on distro_sk14')
    #6.Envío df_csv correo SMTP
    def send_file_SMTP(self, MailTo, MailCC, MailBCC, qry_sk14):
        try:
            df_sk14 = get_query(qry_sk14)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrame para mail Skill 14 listo')
            mail_sk14 = df_sk14.to_html()
            subject = 'CC | President Office | Skill 14 | ' + str(yesterday)
            body = '''
            <html><head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <style type="text/css">
                p {font-size: 11pt; font-family: 'calibri'}
                table {border: 0px; border-spacing:0;}
                thead tr th {border: 0.5px solid black;text-align: center; background: rgb(91,155,213); color: white;}
                tbody {border-spacing:0; text-align: center; border: 0.5px solid black;}
            </style>
            </head>
            <body>
                <p>
                Saludos!<br>
                <br> Les compartimos la base de Skill 14 al <b>''' + str(yesterday) + '''</b><br>
                ''' + mail_sk14 + '''
                <br> Para cualquier duda o comentario mandar un correo a:<br>
                <ul>
                    <li>Mexico ATC OI (mx.atcoperativeintelligenc@mx.att.com)</li>
                    <li>SUAREZ FERNANDEZ, OCTAVIO (os940m@mx.att.com)</li>
                    <li>JAIMES MARTINEZ JESUS ENRIQUE (jj0669@att.com)</li>
                </ul>
                <br> Saludos Cordiales.<br><br>
                <b style="color:black;">Operational Intelligence</b><br>
                <b style="color:#0070C0">Customer and Enterprise Care</b><br>
                <b style="color:#FB1F6E">#CambiaElJuego </b>
                <b style="font-size:24.0pt;color:#BF0CEA">•</b><br><br>
                <p>
                <b style="color:#00B0F0">AT&T México</b><br>
                Blvd Manuel Ávila Camacho 5 Lomas de Sotelo, Naucalpan de Juárez, Estado de México, CP 53390<br><br>
                El uso o divulgación fuera de las empresas AT&T está prohibido, excepto mediante acuerdo escrito.
                Este mensaje y cualesquiera archivos adjuntos contienen información confidencial de la empresa dirigidos exclusivamente para los destinatarios.
                Si usted ha recibido este mensaje por error, favor de no reenviar o distribuir a cualquier otra persona
                , pero favor de llamar al teléfono [55.30302737]  para reportar el error y posteriormente le pedimos borrar este mensaje de su sistema
                </p>
            </body>
            </html>
            '''
            part = MIMEBase('application', "octet-stream")
            with open(newFile, "rb") as fil:
                part = MIMEApplication(
                    fil.read(),
                    Name=basename(newFile)
                )
            # After the file is closed
            part['Content-Disposition'] = 'attachment; filename="%s"' % basename(newFile)
            load_msg = msg()
            load_msg = MIMEMultipart()
            load_msg['From'] = MailFrom
            #load_msg['To'] = MailTo
            #load_msg['Cc'] = MailCC
            #load_msg['Bcc'] = MailBCC
            load_msg['To'] = 'om988b@mx.att.com'
            load_msg['Subject'] = subject
            load_msg.attach(MIMEText(body, 'html'))
            load_msg.attach(part)
            load_conn = smtplib.SMTP(host = Host,port = Port)
            load_conn.starttls()
            load_conn.login(UsMail, PsMail)
            load_conn.send_message(load_msg)
            load_conn.quit()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Sabana Skill 14 enviada con SMTP')
        except Exception as error:
            self.err += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on send_file_SMTP')
    #6.Envío df_csv correo WIN32
    def send_file_W32(self, wMailTo, wMailCC, wMailBCC, qry_sk14, engine):
        try:
            mailItem = olApp.CreateItem(0)
            df_sk14 = pd.read_sql(qry_sk14, engine)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrame para mail Skill 14 listo')
            mail_sk14 = df_sk14.to_html()
            subject = 'CC | President Office | Skill 14 | ' + str(yesterday)
            body = '''
            <html><head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <style type="text/css">
                p {font-size: 11pt; font-family: 'calibri'}
                table {border: 0px; border-spacing:0;}
                thead tr th {border: 0.5px solid black;text-align: center; background: rgb(91,155,213); color: white;}
                tbody {border-spacing:0; text-align: center; border: 0.5px solid black;}
            </style>
            </head>
            <body>
                <p>
                Saludos!<br>
                <br> Les compartimos la base de Skill 14 al <b>''' + str(yesterday) + '''</b><br>
                ''' + mail_sk14 + '''
                <br> Para cualquier duda o comentario mandar un correo a:<br>
                <ul>
                    <li>Mexico ATC OI (mx.atcoperativeintelligenc@mx.att.com)</li>
                    <li>SUAREZ FERNANDEZ, OCTAVIO (os940m@mx.att.com)</li>
                    <li>JAIMES MARTINEZ JESUS ENRIQUE (jj0669@att.com)</li>
                </ul>
                <br> Saludos Cordiales.<br><br>
                <b style="color:black;">Operational Intelligence</b><br>
                <b style="color:#0070C0">Customer and Enterprise Care</b><br>
                <b style="color:#FB1F6E">#CambiaElJuego </b>
                <b style="font-size:24.0pt;color:#BF0CEA">•</b><br><br>
                <p>
                <b style="color:#00B0F0">AT&T México</b><br>
                Blvd Manuel Ávila Camacho 5 Lomas de Sotelo, Naucalpan de Juárez, Estado de México, CP 53390<br><br>
                El uso o divulgación fuera de las empresas AT&T está prohibido, excepto mediante acuerdo escrito.
                Este mensaje y cualesquiera archivos adjuntos contienen información confidencial de la empresa dirigidos exclusivamente para los destinatarios.
                Si usted ha recibido este mensaje por error, favor de no reenviar o distribuir a cualquier otra persona
                , pero favor de llamar al teléfono [55.30302737]  para reportar el error y posteriormente le pedimos borrar este mensaje de su sistema
                </p>
            </body>
            </html>
            '''
            mailItem.BodyFormat = 2 #1 texto plano, 2 html
            mailItem.HTMLBody = body
            mailItem.Subject = subject
            mailItem.To = wMailTo
            mailItem.Cc = wMailCC
            mailItem.Bcc = wMailBCC
            mailItem.Sensitivity  = 2
            mailItem.SentOnBehalfOfName = MailFrom
            mailItem.Attachments.Add(newFile)
            mailItem.Send()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Sabana Skill 14 enviada con WIN32')
        except Exception as error:
            self.err += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on send_file_W32')
    #7.Ejecución del proceso
    def load(self, proc):
        try:
            MailTo, MailCC, MailBCC, wMailTo, wMailCC, wMailBCC = Skill_14.distro_skill14(self)
            engine, conn, cursor = Skill_14.conn_red(self)
            qry_sk14 = Skill_14.queries(self)
            
            try:
                Skill_14.upgrade_file(self)
                try: Skill_14.send_file_SMTP(self, MailTo, MailCC, MailBCC, qry_sk14)
                #except: Skill_14.send_file_W32(self, wMailTo, wMailCC, wMailBCC, qry_sk14, engine)
                except: pass 
            except Exception as error:
                conn.close()
                raise ValueError(repr(error))
        except Exception as error:
            status = 'NOK'
            msg_proc = 'Caught this error: ' + repr(error) if int(self.no_info) == 0 else 'SIN_INFO Caught this error: ' + repr(error)
            #mail.send_notification('Error Job', msg_proc, 'Skill 14', str(today), self.trns, self.err, st_hostn, exec_path)
        else:
            status = 'OK'
            msg_proc =  'Nothing went wrong'
            #mail.send_notification('Confirmation Job', msg_proc, 'Skill 14', str(today), self.trns, self.err, st_hostn, exec_path)
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            print(status, msg_proc)
            return status, msg_proc
'''
def main():
    runObj = Skill_14()
    run_process = str(Key)
    result = runObj.load(run_process)
main()
'''
