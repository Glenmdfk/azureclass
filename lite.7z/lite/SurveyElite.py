'''   ##########  Comienza importación de módulos ##########   '''
#Necesario instalar las librerías: html5lib, lxml
from datetime import date, timedelta, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Módulos Generales
from openpyxl import load_workbook
import matplotlib.pyplot as plt
import pathlib, socket, os, sys
import win32com.client as win32
from time import sleep
import pandas as pd
import numpy as np
import Libraries.data_profiling as dp
#Selenium
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium import webdriver
#Config Mail
olApp = win32.Dispatch('Outlook.Application')
olNS = olApp.GetNameSpace('MAPI')
#SQL Alchemy
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.distro as distro
import Libraries.config as config
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')
'''   ##########  Comienza definición de variables ##########   '''
Key = 'SurveyElite'
sub = '.'
#Detalles de ejecución
path_file = pathlib.Path(__file__) #Lectura archivo actual
st_pathn = str(path_file).upper() #Ruta Mayuscula
st_hostn = socket.gethostname() #Hostname
#Fechas
today = date.today() #Hoy
yesterday = today - timedelta(days=1)
nombre_dia = dt.strftime(yesterday,'%a')
now = dt.now() #Ahora
ed_date = today - timedelta(days = 1) #Día vencido
month = ed_date.month #Mes actual
#Variables de correo - Envio
MailFrom = distro.GeneralNew['Sender']
MailTo = distro.GeneralNew['ToDistro']
MailCC = distro.GeneralNew['CcDistro']
#Variables para usuarios
jVar = pd.read_json('C:\\App\\Variables\\Domain.json')
UsMail = jVar['Username']['CFR']
PsMail = jVar['Password']['PASS_CFR']
default_dw = '\\\\135.208.36.251\\Op_Intelligence\\DOCUMENTACION\\Scripts\\files\\'
#Variables de directorio
path = pathlib.Path(__file__).parent.absolute() #Directorio actual
default_dw = '\\\\135.208.36.251\\Op_Intelligence\\MASTER_REPORTS\\ELITE\\MIGRACION\\Encuestas_CE\\ETL\\Insumos\\'
path_download = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/ELITE/MIGRACION/Encuestas_CE/ETL/Insumos'
path_plots = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/ELITE/MIGRACION/Encuestas_CE/ETL/Plots'
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')
'''   ##########  Comineza ejecución del programa ##########   '''
class SurveyElite:
    #Conexión a DataManagement
    def conn_red(self):
        server = config.DATAMANAGEMENT_CONFIG["Server"]
        try:
            conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_ChardDM_Connection()})
            engine = create_engine(conn_url)
            conn = engine.raw_connection()
            cursor = conn.cursor()
        except:
            raise ValueError(dt.now(), '%d/%m/%Y %H:%M:%S'+ 'No fue posible conectarse a ' + str(server))
        else:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': SQL Alchemy - Conexión red establecida')
            return engine, conn, cursor
        
    def conn_blue(self):
        try:
            conn_url, engine_blue, conn_blue, cursor_blue = dbConn.get_ETL_OIEngineBlue_Connection()
            
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa OI Bue Server')
            return conn_blue, engine_blue, cursor_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_blue: ' +  repr(error)) 
            
            raise ValueError(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_blue: ' +  repr(error))


    #Queries
    def queries(self, nYearMonth, cMonth, cYear, SQL_stDate, SQL_edDate):
        #Cartera Blue
        qry_cartera = "SELECT DISTINCT nAccountBlue, nMonth, cConsultor, cDirector, cGerente, cCoordinador\
            ,cRegion_Elite, cMarca FROM elt.tbl_KPI_CarteraBlue\
            WHERE nMonth >= '" + str(nYearMonth) + "' AND cMarca LIKE 'ATT'"
        #Head Count
        qry_hc = "SELECT DISTINCT REPLACE(cNombreCompleto,'Ñ','N') cNombreCompleto, cATTUID\
            FROM hc.tbl_hcMonthly WHERE nWeek >= '" + str(nYearMonth) +"'"
        #Limpieza elt.tbl_KPI_EncuestasBlue
        qry_del = ("DELETE FROM elt.tbl_KPI_EncuestasBlue WHERE dFecha_Encuesta\
            BETWEEN '" + SQL_stDate + "' AND '" + SQL_edDate +"';")
        #Limpieza elt.tbl_Encuestas
        qry_del2 = ("DELETE FROM elt.tbl_Encuestas WHERE Mes = '" + cMonth + "' AND nAño = " + cYear + ";")
        #Plot1 - Promotor Neutro y Detractor
        qry_plot1 = "SELECT CAST(SUM(IIF(nNPS <= 6, 1, 0)) AS FLOAT) / CAST(SUM(IIF(nNPS >= 1, 1, 0)) AS FLOAT) DetNPS \
            ,CAST(SUM(IIF(nNPS IN (7,8), 1, 0)) AS FLOAT) / CAST(SUM(IIF(nNPS >= 1, 1, 0)) AS FLOAT) NeuNPS \
            ,CAST(SUM(IIF(nNPS >= 9, 1, 0)) AS FLOAT) / CAST(SUM(IIF(nNPS >= 1, 1, 0)) AS FLOAT) PromNPS \
            ,CAST(SUM(IIF(nCSAT <= 6, 1, 0)) AS FLOAT) / CAST(SUM(IIF(nCSAT >= 1, 1, 0)) AS FLOAT) DetCSAT \
            ,CAST(SUM(IIF(nCSAT IN (7,8), 1, 0)) AS FLOAT) / CAST(SUM(IIF(nCSAT >= 1, 1, 0)) AS FLOAT) NeuCSAT \
            ,CAST(SUM(IIF(nCSAT >= 9, 1, 0)) AS FLOAT) / CAST(SUM(IIF(nCSAT >= 1, 1, 0)) AS FLOAT) PromCSAT \
        FROM [elt].[tbl_KPI_EncuestasBlue] WHERE dFecha_Encuesta BETWEEN '" + SQL_stDate + "' AND ' " + SQL_edDate +"'"
        #Plot2 - Daily NPS vs CSAT
        qry_plot2 = "SELECT dFecha_Encuesta Fecha\
            ,(CAST(SUM(IIF(nNPS >= 9, 1, 0)) AS FLOAT)-CAST(SUM(IIF(nNPS <= 6, 1, 0)) AS FLOAT))/CAST(SUM(IIF(nNPS >= 1, 1, 0)) AS FLOAT) NPS \
            ,(CAST(SUM(IIF(nCSAT >= 9, 1, 0)) AS FLOAT)-CAST(SUM(IIF(nCSAT <= 6, 1, 0)) AS FLOAT))/CAST(SUM(IIF(nCSAT >= 1, 1, 0)) AS FLOAT) CSAT \
        FROM elt.tbl_KPI_EncuestasBlue WHERE dFecha_Encuesta BETWEEN '" + SQL_stDate + "' AND ' " + SQL_edDate +"' \
        GROUP BY dFecha_Encuesta ORDER BY Fecha DESC"
        #Resumen de calificaciones
        qry_acum = "SELECT LEFT(cMes,3) cMes \
        ,CAST(RIGHT(cMes,4) AS INT) nYear \
        ,LTRIM(RTRIM(cCve_Dir)) cDirector \
        ,LTRIM(RTRIM(cCve_Ger)) cManager \
        ,LTRIM(RTRIM(cCve_Coo)) cCoordinador \
        ,LTRIM(RTRIM(cRegion)) cRegion \
        ,LTRIM(RTRIM(cCve_Eje_Evaluado)) cATTUID \
        ,SUM(IIF(cXx_Nps = 'PROMOTORES', 1, 0)) NPSPositivo \
        ,SUM(IIF(cXx_Nps = 'NEUTRALES', 1, 0)) NPSNeutral \
        ,SUM(IIF(cXx_Nps = 'DETRACTORES', 1, 0)) NPSNegativo \
        ,SUM(IIF(cXx_Csat = 'POSITIVO', 1, 0)) CSATPositivo \
        ,SUM(IIF(cXx_Csat = 'NEUTRALES', 1, 0)) CSATNeutral \
        ,SUM(IIF(cXx_Csat = 'NEGATIVO', 1, 0)) CSATNegativo \
        ,(CAST(SUM(IIF(cXx_Nps = 'PROMOTORES', 1, 0)) AS FLOAT) - CAST(SUM(IIF(cXx_Nps = 'DETRACTORES', 1, 0)) AS FLOAT)) \
            / CAST(COUNT(cXx_Nps) AS FLOAT) nNPS \
        ,(CAST(SUM(IIF(cXx_Csat = 'POSITIVO', 1, 0)) AS FLOAT) - CAST(SUM(IIF(cXx_Csat = 'NEGATIVO', 1, 0)) AS FLOAT)) \
            / CAST(COUNT(cXx_Csat) AS FLOAT) nNRS \
        ,COUNT(cXx_Csat) Encuestas \
        FROM elt.tbl_KPI_EncuestasBlue Enc WHERE nMonth = "+ str(nYearMonth) +" \
        GROUP BY cMes, cCve_Dir, cCve_Ger, cCve_Coo, cCve_Dir, cRegion, cCve_Eje_Evaluado"
        ##Qry HC de Coordinadores
        qry_hcc="SELECT DISTINCT LTRIM(RTRIM(REPLACE(REPLACE(cNombreCompleto,'  ',' '),'Ñ','N'))) cNombreCompleto \
        ,CASE WHEN cATTUID = 'AL224U' THEN 'OMAR LEDEZMA' \
            WHEN cATTUID = 'FN503X' THEN 'FRANCISCO NUÑO' ELSE \
        REPLACE(CONCAT(LTRIM(RTRIM(SUBSTRING(cNombre, 1, IIF(CHARINDEX(' ',cNombre)=0,LEN(cNombre),CHARINDEX(' ',cNombre))))), \
        ' ', cPaterno),'Ñ','N') END cNombre FROM hc.tbl_HCMonthly \
        WHERE nWeek >= 202203 AND cPuestoSimplificado <> 'Ejecutivo'"

        qry_del_b = ("DELETE FROM elt.tbl_kpi_survey_blue WHERE survey_date\
            BETWEEN '" + SQL_stDate + "' AND '" + SQL_edDate +"';")
        
        return qry_cartera, qry_hc, qry_del, qry_del2, qry_plot1, qry_plot2, qry_acum, qry_hcc,qry_del_b
    #Limpieza de carpetas
    def clean_files(self):
        try:
            for i in os.listdir(path_download):
                if i.endswith('xlsx'):
                    os.replace(path_download + '/' + i, path_download + '/Cargados/' + i)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Archivos anteriores movidos al historico')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on scrapping_survey')
    #Descarga de insumos Tacrift
    def scrapping_survey(self):
        
        try:
            #Configuraciones
            url = 'https://attmx-my.sharepoint.com/personal/it9824_mx_att_com/_layouts/15/onedrive.aspx?id=%2Fpersonal%2Fit9824%5Fmx%5Fatt%5Fcom%2FDocuments%2FElite%20Bases%20Dashboard%20Nodo&FolderCTID=0x012000F06A10FB7344944AA152796054578C1E&view=0'
            driver_path = '//135.208.36.251/Op_Intelligence/DOCUMENTACION/CONTROLES_INTERNOS/Aplicaciones/chromedriver.exe'
            driver_service = Service(executable_path=driver_path)
            prefs = {"download.default_directory":default_dw}
            options = Options()
            options.add_argument("--window-size=1950,1100")
            options.add_argument('--disable-extensions')
            options.add_experimental_option("prefs",prefs)
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            driver = webdriver.Chrome(service=driver_service, options=options)
            #Abrir el programa
            driver.get(url)
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +'Ingresando Usuario')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.NAME, 'loginfmt')))\
                .send_keys(UsMail)
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Boton siguiente')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.ID, 'idSIButton9')))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Ingresando Usuario')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.NAME, 'passwd')))\
                .send_keys(PsMail)
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Siguiente')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.ID, 'idSIButton9')))\
                .click()
            sleep(3)
            try:
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Boton siguiente')
                WebDriverWait(driver, 5) \
                    .until(EC.element_to_be_clickable((By.ID, 'idBtn_Back')))\
                    .click()
                sleep(3)
            except:
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Elemento no encontrado, continúa proceso')
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Boton nombre')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH,'//*[text()="Nombre"]')))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Ordenamiento')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="De la A a la Z"]')))\
                .click() 
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Boton modified')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH,'//*[text()="Modificado"]')))\
                .click()
            sleep(3)    
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Mas nuevo')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="De más nuevo a más antiguo"]')))\
                .click() 
            sleep(5)    
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Archivo ATT Dash')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/div/div[2]/div/div/div[2]/div[2]/main/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div[1]/div/div/div[1]')))\
                .click() 
            sleep(3) 
            #breakpoint()
            print('iniciar descarga')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button[title='Mostrar más acciones para este elemento']")))\
                .click() 
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Comenzando Descarga')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="Descargar"]')))\
                .click() 
            sleep(15)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Descarga Exitosa')
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Regresando')
            WebDriverWait(driver, 5)
            sleep(3)
            #breakpoint()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:')+'Scraping Exitoso')       
            
        except Exception as error:
            print('Error on scrapping: ' +  repr(error)) 
            raise ValueError('Error on scrapping')               
                
        '''
       #Descarga
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Descargando insumo')
            sleep(3)
            WebDriverWait(driver, 20)\
                .until(EC.element_to_be_clickable((By.ID, 'DownloadACopy')))\
                .click()
            sleep(45)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': El archivo fue descargando en ' + path_download)
            #Cierre de navegador Web
            driver.quit()
            #Finalizando
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Proceso de scrapping finalizado') 
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on scrapping_survey')  
        try:
            #Variables Chrome
            url='https://nodo-research.com/dashboard-att-2/'
            driver_path = '//135.208.36.251/Op_Intelligence/DOCUMENTACION/CONTROLES_INTERNOS/Aplicaciones/chromedriver.exe'
            driver_service = Service(executable_path=driver_path)
            #Opciones de navegación
            prefs = {"download.default_directory" : default_dw}
            options = Options()
            options.add_argument("--window-size=1950,1100")
            options.add_argument('--disable-extensions')
            options.add_experimental_option("prefs",prefs)
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            driver = webdriver.Chrome(service=driver_service, options=options)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': La configuración de Chrome esta lista')
            #Navegación iniciada
            driver.get(url)
            OriginalWindow = driver.current_window_handle
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Navegador iniciado')
            sleep(3)
            #Introducir contraseña
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Introduce llave 1')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.NAME, 'post_password')))\
                .send_keys(PsNodo)
            sleep(2)
            #Siguiente
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Boton Entrar')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.NAME, 'Submit')))\
                .click()
            sleep(4)
            try:
                driver.refresh()
            except:
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': No se pudo refrescar la pagina')
            sleep(4)
            #Swith to frame
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Swith to frame') 
            #clic en datos
            a = 0
            while a == 0:
                try:
                    driver.switch_to.frame(driver.find_element(By.CSS_SELECTOR, "iframe[title='dashboard_att - Inicio']"));
                    sleep(2)
                    
                    for i in range(4):
                        #RightXPATH = '//*[@id="embedWrapperID"]/div[2]/logo-bar/div/div/div/logo-bar-navigation/span/button[2]/i'
                        RightXPATH = '//*[@id="pbiAppPlaceHolder"]/report-embed/div/div[2]/logo-bar/div/div/div/logo-bar-navigation/span/button[2]'
                        print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Boton Datos')
                        WebDriverWait(driver, 5)\
                            .until(EC.element_to_be_clickable((By.XPATH,RightXPATH)))\
                            .click()
                        sleep(3)
                except:
                    a = 0
                else:
                    a = a + 1
            FileXPATH = '//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container[23]/transform/div/div[2]/div/visual-modern/div/div'
            #FileXPATH = '//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container[24]/transform/div/div[2]/div/visual-modern/div/div'
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Esperando la selección del archivo')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.XPATH, FileXPATH)))\
                .click()
            sleep(15)
            #Espera hasta que haya 2 ventanas
            WebDriverWait(driver,5).until(EC.number_of_windows_to_be(2))
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Cambiando a segunda ventana')
            #Cambia de ventana
            for window_handle in driver.window_handles:
                    if window_handle != OriginalWindow:
                        driver.switch_to.window(window_handle)
                        break
            sleep(3)
            driver.switch_to.default_content()
            #Introduce Usuario
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Autenticando')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, 
                    "input[name='loginfmt']")))\
                .send_keys(UsMaster)
            sleep(3)
            #Next
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, 
                    'input#idSIButton9')))\
                .click()
            sleep(5)
            #Introduce Pass
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Autenticando')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, 
                    "input[name='passwd']")))\
                .send_keys(PsMaster)
            sleep(5)
            #Next - two times
            for i in range(2):
                sleep(5)
                WebDriverWait(driver, 5)\
                    .until(EC.element_to_be_clickable((By.CSS_SELECTOR, 
                        'input#idSIButton9')))\
                    .click()
            #Variables XPATH Excel
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Esperando al archivo de ex el')
            sleep(10)
            #Menu de Archivo
            sleep(3)
            ##########  IMPORTANTE: Esta línea se usa solo cuando se trabaja en sitios ASPX como PBI y EXCEL Online ##########
            driver.switch_to.frame("WebApplicationFrame")
            #driver.switch_to.default_content() #SwitchBack
            #Comienza busqueda en sitio ASPX
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Esperando al menu de Archivo')
            sleep(3)
            WebDriverWait(driver, 20)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR,
                    'span#id__3')))\
                .click()
            #Salvar
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Esperando al menu de guardado')
            sleep(3)
            WebDriverWait(driver, 20)\
                .until(EC.element_to_be_clickable((By.XPATH,
                    '//*[@id="FileSaveAsPage"]')))\
                .click()
            #Descarga
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Descargando insumo')
            sleep(3)
            WebDriverWait(driver, 20)\
                .until(EC.element_to_be_clickable((By.ID, 'DownloadACopy')))\
                .click()
            sleep(45)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': El archivo fue descargando en ' + path_download)
            #Cierre de navegador Web
            driver.quit()
            #Finalizando
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Proceso de scrapping finalizado') 
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on scrapping_survey')
        '''
    #DataFrame AT&T México Care
    def df_excel(self):
        try:
            global survey
            dict_month = {'1' : 'ENE','2' : 'FEB','3' : 'MAR','4' : 'ABR','5' : 'MAY','6' : 'JUN','7' : 'JUL','8' : 'AGO','9' : 'SEP','10' : 'OCT','11' : 'NOV','12' : 'DIC'}
            with os.scandir(path_download) as ficheros:
                ficheros = [fichero.name for fichero in ficheros if fichero.is_file()]
            #Nombre de archivo
            File = path_download + '/' + ficheros[0]
            wb = load_workbook(File, read_only=True, keep_links=False)
            #Identificar la hoja a leer
            for i in wb.sheetnames:
                if i.startswith('att_dash'):
                    Sheetname = i
            #Dataframe Excel
            survey = pd.read_excel(File, sheet_name = Sheetname)
            #Fecha de Inicio y fin a procesar
            dStart = min(survey['fecha'])
            dEnd = max(survey['fecha'])
            SQL_stDate = dt.strftime(dStart, '%Y-%m-%d') #Fecha inicio String YYYY-mm-dd
            SQL_edDate = dt.strftime(dEnd, '%Y-%m-%d') #Fecha fIN String YYYY-mm-dd
            st_start = dt.strftime(dStart, '%d/%m/%Y') #Fecha inicio String dd/mm/YYYY
            st_end = dt.strftime(dEnd, '%d/%m/%Y') #Fecha fin String dd/mm/YYYY
            nYearMonth = dStart.year * 100 + dStart.month
            nYear = dStart.year
            nMonth = str(dStart.month)
            cYear = str(dStart.year)
            #cMonth = nMonth.replace('1','ENE').replace('2','FEB').replace('3','MAR').replace('4','ABR').replace('5','MAY').replace('6','JUN').replace('7','JUL').replace('8','AGO').replace('9','SEP').replace('10','OCT').replace('11','NOV').replace('12','DIC')
            cMonth = dict_month[nMonth]
            #Comienzan Transformaciones
            survey['cNPS'] = np.where(survey['recomendacion'] <= 6, 'DETRACTORES', 
                np.where((survey['recomendacion'] == 7) | (survey['recomendacion'] == 8), 'NEUTRALES',
                    np.where(survey['recomendacion'] >= 9, 'PROMOTORES', None)))
            survey['cCSAT'] = np.where(survey['satisfaccion'] <= 6, 'NEGATIVO', 
                np.where((survey['satisfaccion'] == 7) | (survey['satisfaccion'] == 8), 'NEUTRALES',
                    np.where(survey['satisfaccion'] >= 9, 'POSITIVO', None)))
            survey['nFCR'] = np.where(survey['marcar_veces'] == 'Sigo sin solución', 0,
                np.where(survey['marcar_veces'] == '1 vez', 1,
                    np.where((survey['marcar_veces'] == 'Más de 1 vez') | (survey['marcar_veces'] == 'Más de 1'), 2, None)))
            survey['nYearMotn'] = pd.DatetimeIndex(survey['fecha']).year * 100 + pd.DatetimeIndex(survey['fecha']).month
            survey['cCuenta'] = survey['cuenta'].astype(int)
            survey['ejecutivo'] = survey['ejecutivo'].str.replace('Ã‘','N').str.replace('Ñ','N').str.replace('ÃƒÂ‘','N').str.replace('Â‘','').str.replace(' ',' ')
            survey['clave'] = survey['clave'].replace(np.nan, '(en blanco)')
            survey['cComentario'] = survey['satisfaccion_rzn'].str[:300].replace(np.nan, None)
            survey['nMes'] = pd.DatetimeIndex(survey['fecha']).month.astype(str)
            survey['nYear'] = pd.DatetimeIndex(survey['fecha']).year.astype(str)
            survey['cMes'] = survey['nMes'].replace('1','ENE').replace('2','FEB').replace('3','MAR').replace('4','ABR')\
                .replace('5','MAY').replace('6','JUN').replace('7','JUL').replace('8','AGO').replace('9','SEP')\
                .replace('10','OCT').replace('11','NOV').replace('12','DIC') + ' ' + survey['nYear']
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Se aplicaron las transfrmaciones al insumo de excel')
            return SQL_stDate, SQL_edDate, st_start, st_end, nYearMonth, cYear, cMonth
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on df_excel')
    #Testing
    def df_survey(self, engine, qry_cartera, qry_hc):
        try:
            global new_df,df_blue
            #Transformaciones para la cartera
            cartera = pd.read_sql(qry_cartera, engine)
            cartera['nAccountBlue'] =  cartera['nAccountBlue'].astype(int)
            hc = pd.read_sql(qry_hc, engine)
            #Cruce entre file y survey y HC
            surveyok = pd.merge(survey, hc, left_on='ejecutivo', right_on='cNombreCompleto', how='left')
            #Cruce entre encuestas y cartera por cuenta y año mes
            df_survey = pd.merge(surveyok, cartera, left_on=['cCuenta','nYearMotn'], right_on=['nAccountBlue','nMonth'], how='inner')
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': New DataFrame is Ready')
            df_survey['cClave'] = np.where(df_survey['clave'] == '(en blanco)', df_survey['cATTUID'], df_survey['clave'])
            #Comienza renombramiento de campos
            df_survey['cRazon_Social'] = df_survey['cliente']
            df_survey['cCve_Eje_Evaluado'] = df_survey['cClave']
            df_survey['cCve_Eje'] = df_survey['cConsultor']
            df_survey['cCve_Dir'] = df_survey['cDirector']
            df_survey['cCve_Ger'] = df_survey['cGerente']
            df_survey['cCve_Coo'] = df_survey['cCoordinador']
            df_survey['dFecha_Encuesta'] = pd.to_datetime(df_survey['fecha']).dt.date
            df_survey['dFecha_Encuesta'] = df_survey['dFecha_Encuesta'].astype(str)
            df_survey['cCampaña'] = df_survey['campaña']
            df_survey['nCsat'] = df_survey['satisfaccion']
            df_survey['nFcr'] = df_survey['nFCR']
            df_survey['nNps'] = df_survey['recomendacion']
            df_survey['nIncidente'] = df_survey['id']
            df_survey['cRegion'] = df_survey['cRegion_Elite']
            df_survey['cXx_Nps'] = df_survey['cNPS']
            df_survey['cXx_Csat'] = df_survey['cCSAT']
            df_survey['nMonth'] = df_survey['nYearMotn']
            #Comienza definición de nuevo DataFrame
            new_df = df_survey[['cCuenta','cRazon_Social','cCve_Eje_Evaluado','cCve_Eje','cCve_Dir','cCve_Ger','cCve_Coo'
                ,'dFecha_Encuesta','cCampaña','nCsat','nFcr','nNps','cComentario','nIncidente','cMes','cRegion'
                ,'cXx_Nps','cXx_Csat','nMonth']]
            df_blue=new_df.rename(columns={'cCuenta':'account_number','cRazon_Social':'social_reason','cCve_Eje_Evaluado':'cve_evaluated_axis','cCve_Eje':'cve_eje','cCve_Dir':'cve_dir','cCve_Ger':'cve_ger','cCve_Coo':'cve_coo','dFecha_Encuesta':'survey_date','cCampaña':'campaign','nCsat':'csat','nFcr':'fcr','nNps':'nps','cComentario':'comment','nIncidente':'incident_number','cMes':'row_month','cRegion':'region','cXx_Nps':'xx_nps','cXx_Csat':'xx_csat','nMonth':'year_month'})
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrame new_df listo para carga')
            return new_df
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on df_survey')
    #Carga de datos
    def load_survey(self, engine, conn, cursor, qry_del):
        try:
            cursor.execute(qry_del)
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': elt.tbl_KPI_EncuestasBlue ha sido limpiada')
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            new_df.to_sql('tbl_KPI_EncuestasBlue', engine, index=False, if_exists="append", schema="elt")
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': elt.tbl_KPI_EncuestasBlue ha sido actualizada')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on load_survey')
        
    def load_survey_blue(self, engine, conn, cursor, qry_del):
        try:
            cursor.execute(qry_del)
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': elt.tbl_kpi_survey_blue ha sido limpiada')
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            df_blue.to_sql('tbl_kpi_survey_blue', engine, index=False, if_exists="append", schema="elt")
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': elt.tbl_kpi_survey_blue ha sido actualizada')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on load_survey')
            
    #Generación del plot
    def gen_plot(self, engine, qry_plot1, qry_plot2):
        try:
            #DataFrames para plot
            df_plot1 = pd.read_sql(qry_plot1, engine)
            df_plot2 = pd.read_sql(qry_plot2, engine)
            #Conversiones para NPS
            nDet = max(df_plot1['DetNPS'])
            nNeu = max(df_plot1['NeuNPS'])
            nProm = max(df_plot1['PromNPS'])
            #Conversiones para CSAT
            cDet = max(df_plot1['DetCSAT'])
            cNeu = max(df_plot1['NeuCSAT'])
            cProm = max(df_plot1['PromCSAT'])
            #Listas de datos NPS vs CSAT
            dfg1 = pd.DataFrame({'Kpi':['Detractor','Neutral', 'Promotor'],
                'NPS':[nDet, nNeu, nProm],
                'CSAT':[cDet, cNeu, cProm]})
            #Lista de datos Daily NPS vs CSAT
            dfg2 = pd.DataFrame({
                'Fecha': df_plot2['Fecha'],
                'NPS': df_plot2['NPS'],
                'CSAT': df_plot2['CSAT']
            })
            #Comienza Ploteo
            fig, ax = plt.subplots(2,2)
            #NPS vs CSAT
            ax[0, 0].plot(dfg1['Kpi'], dfg1['NPS'], label = "NPS", marker = 'o')
            ax[0, 0].plot(dfg1['Kpi'], dfg1['CSAT'], label = "CSAT", marker = 'o')
            ax[0, 0].legend(ncol = 2)
            ax[0, 0].set_title("NPS vs CSAT")
            #Daily NPS vs CSAT
            ax[0, 1].plot(dfg2['Fecha'], dfg2['NPS'])
            ax[0, 1].plot(dfg2['Fecha'], dfg2['CSAT'])
            ax[0, 1].get_xaxis().set_visible(False)
            ax[0, 1].set_title("Daily NPS vs CSAT")
            #Daily NPS
            ax[1, 0].plot(dfg2['Fecha'], dfg2['NPS'], label = "NPS", color = 'tab:blue', marker = 'o')
            ax[1, 0].legend(ncol = 1)
            ax[1, 0].get_xaxis().set_visible(False)
            ax[1, 0].set_title("Daily NPS")
            #Daily CSAT
            ax[1, 1].plot(dfg2['Fecha'], dfg2['CSAT'], label = "CSAT", color = 'tab:orange', marker = 'o')
            ax[1, 1].legend(ncol = 1)
            ax[1, 1].get_xaxis().set_visible(False)
            ax[1, 1].set_title("Daily CSAT")
            #Coordenadas para las etiquetas NPS
            for x,y in zip(dfg1['Kpi'],dfg1['NPS']):
                label = '{:,.1%}'.format(y)
                ax[0, 0].annotate(label, (x,y), xytext=(x,y), textcoords="offset points", ha='center')
            #Coordenadas para las etiquetas CSAT
            for x,y in zip(dfg1['Kpi'],dfg1['CSAT']):
                label = '{:,.1%}'.format(y)
                ax[0, 0].annotate(label, (x,y), xytext=(x,y), textcoords="offset points", ha='center')
            #Salvar archivo
            filename = str(date.today()) + ".png"
            path_plot = path_plots + '/' + filename
            fig.savefig(path_plot, dpi=fig.dpi)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ploteo generado con éxito')
            return path_plot
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on gen_plot')
    #DataFrames para Mail
    def df_mail(self, engine, qry_plot2):
        try:
            global hnps_html, lnps_html, hcsat_html, hcsat_html, lcsat_html, load_html
            #DataFrame Plot y tablas
            df_plot2 = pd.read_sql(qry_plot2, engine)
            #TOP 3 NPS
            h_nps = df_plot2[['Fecha','NPS']].nlargest(3,'NPS')
            h_nps['NPS'] = h_nps['NPS'].map('{:,.1%}'.format)
            h_nps['nDay'] = pd.DatetimeIndex(h_nps['Fecha']).day.astype(str)
            h_nps['nMonth'] = pd.DatetimeIndex(h_nps['Fecha']).month.astype(str)
            h_nps['Date'] = h_nps['nDay'] + '/' + h_nps['nMonth']
            #OFFENDER NPS
            l_nps = df_plot2[['Fecha','NPS']].nsmallest(3,'NPS')
            l_nps['NPS'] = l_nps['NPS'].map('{:,.1%}'.format)
            l_nps['nDay'] = pd.DatetimeIndex(l_nps['Fecha']).day.astype(str)
            l_nps['nMonth'] = pd.DatetimeIndex(l_nps['Fecha']).month.astype(str)
            l_nps['Date'] = l_nps['nDay'] + '/' + l_nps['nMonth']
            #TOP 3 CSAT
            h_csat = df_plot2[['Fecha','CSAT']].nlargest(3,'CSAT')
            h_csat['CSAT'] = h_csat['CSAT'].map('{:,.1%}'.format)
            h_csat['nDay'] = pd.DatetimeIndex(h_csat['Fecha']).day.astype(str)
            h_csat['nMonth'] = pd.DatetimeIndex(h_csat['Fecha']).month.astype(str)
            h_csat['Date'] = h_csat['nDay'] + '7' + h_csat['nMonth']
            #OFFENDER CSAT
            l_csat = df_plot2[['Fecha','CSAT']].nsmallest(3,'CSAT')
            l_csat['CSAT'] = l_csat['CSAT'].map('{:,.1%}'.format)
            l_csat['nDay'] = pd.DatetimeIndex(l_csat['Fecha']).day.astype(str)
            l_csat['nMonth'] = pd.DatetimeIndex(l_csat['Fecha']).month.astype(str)
            l_csat['Date'] = l_csat['nDay'] + '/' + l_csat['nMonth']
            #CARGA SURVEY
            load_df = df_plot2
            load_df['NPS'] = load_df['NPS'].map('{:,.1%}'.format)
            load_df['CSAT'] = load_df['CSAT'].map('{:,.1%}'.format)
            load_df['nDay'] = pd.DatetimeIndex(load_df['Fecha']).day.astype(str)
            load_df['nMonth'] = pd.DatetimeIndex(load_df['Fecha']).month.astype(str)
            load_df['Date'] = load_df['nDay'] + '/' + load_df['nMonth']
            #Tablas con formato html
            hnps = pd.DataFrame({'Fecha': h_nps['Date'],'NPS': h_nps['NPS']}).reset_index(drop=True)
            lnps = pd.DataFrame({'Fecha': l_nps['Date'],'NPS': l_nps['NPS']}).reset_index(drop=True)
            hcsat = pd.DataFrame({'Fecha': h_csat['Date'],'CSAT': h_csat['CSAT']}).reset_index(drop=True)
            lcsat = pd.DataFrame({'Fecha': l_csat['Date'],'CSAT': l_csat['CSAT']}).reset_index(drop=True)
            dfload = pd.DataFrame({'Fecha': load_df['Date'],'NPS': load_df['NPS'],'CSAT': load_df['CSAT']}).reset_index(drop=True)
            #Tablas a formato html
            hnps_html = hnps.to_html()
            lnps_html = lnps.to_html()
            hcsat_html = hcsat.to_html()
            lcsat_html = lcsat.to_html()
            load_html = dfload.to_html()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrames para correo generados')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on df_mails')
    #DataFrame acumulado
    def df_acum(self, engine, qry_acum, qry_hcc):
        try:
            global df_acum
            #Conversión de Querys a dataframe
            df_res = pd.read_sql(qry_acum, engine)
            df_res['cDirector'] = df_res['cDirector'].str.strip()
            df_res['cDirector'] = df_res['cDirector'].replace('Ñ', 'N')
            df_res['cManager'] = df_res['cManager'].str.strip()
            df_res['cManager'] = df_res['cManager'].replace('Ñ', 'N')
            df_res['cCoordinador'] = df_res['cCoordinador'].str.strip()
            df_res['cCoordinador'] = df_res['cCoordinador'].replace('Ñ', 'N')
            df_hc = pd.read_sql(qry_hcc, engine)
            #Cruces para optener el nombre abreviado
            df_dir = pd.merge(df_res, df_hc, left_on='cDirector', right_on='cNombreCompleto', how='left')
            df_dir.rename(columns={'cNombre':'Director','cDirector':'cDir'},inplace=True)
            df_ger = pd.merge(df_dir, df_hc, left_on='cManager', right_on='cNombreCompleto', how='left')
            df_ger.rename(columns={'cNombre':'Gerente','cManager':'cMan'},inplace=True)
            df_coo = pd.merge(df_ger, df_hc, left_on='cCoordinador', right_on='cNombreCompleto', how='left')
            df_coo.rename(columns={'cNombre':'Coordinador','cCoordinador':'cCoo'},inplace=True)
            df_coo['Mes'] = df_coo['cMes']
            df_coo['nAño'] = df_coo['nYear']
            df_coo['cDirector'] = df_coo['Director']
            df_coo['cManager'] = df_coo['Gerente']
            df_coo['cCoordinator'] = df_coo['Coordinador']
            df_coo['CASTNegativo'] = df_coo['CSATNegativo']
            #Nuevo DataFrame acumulado
            df_acum = df_coo[['Mes','nAño','cDirector','cManager','cCoordinator','cRegion','cATTUID','NPSPositivo'
                ,'NPSNeutral','NPSNegativo','CSATPositivo','CSATNeutral','CASTNegativo','nNPS','nNRS','Encuestas']]
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrames acumulado listo para carga')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on df_acum')
    #Carga acumulado
    def load_acum(self, engine, conn, cursor, qry_del2):
        try:
            #Limpia tabla
            cursor.execute(qry_del2)
            conn.commit()
            #Carga datos acumulados
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            df_acum.to_sql('tbl_Encuestas', engine, index=False, if_exists="append", schema="elt")
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': elt.tbl_Encuestas ha sido actualizada')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on load_acum')
    #Notificación de descarga
    def notification_mail(self, subject, formato, result):
        try:
            mailItem = olApp.CreateItem(0)
            body = '''
            <html><head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <style type="text/css">
                p {font-size: 11pt; font-family: 'calibri'}
            </style>
            </head>
            <body>
                ''' + formato + result + '''</b><br>
                <ul>
                    <li><b>JOB:</b> ''' + st_pathn + ''' </li>
                    <li><b>FECHA:</b> ''' + dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + '''</li>
                    <li><b>HOSTNAME:</b> ''' + st_hostn + '''</li>
                </ul>
                <b style="color:black;">Operational Intelligence</b><br>
                <b style="color:#0070C0">Customer and Enterprise Care</b><br>
                <b style="color:#FB1F6E">#CambiaElJuego </b>
                <b style="font-size:24.0pt;color:#BF0CEA">•</b><br><br>
                <p>
                <b style="color:#00B0F0">AT&T México</b><br>
                Blvd Manuel  Ávila Camacho 5 Lomas de Sotelo, Naucalpan de Juárez, Estado de México, CP 53390<br><br>
                El uso o divulgación fuera de las empresas AT&T está prohibido, excepto mediante acuerdo escrito.
                Este mensaje y cualesquiera archivos adjuntos contienen información confidencial de la empresa dirigidos exclusivamente para los destinatarios.
                Si usted ha recibido este mensaje por error, favor de no reenviar o distribuir a cualquier otra persona
                , pero favor de llamar al teléfono [55.30302737]  para reportar el error y posteriormente le pedimos borrar este mensaje de su sistema
                </p>
            </body>
            </html>
            '''
            mailItem.Subject = subject
            mailItem.BodyFormat = 2
            mailItem.HTMLBody = body
            mailItem.To = MailTo
            mailItem.Cc = MailCC
            mailItem.SentOnBehalfOfName = MailFrom
            mailItem.Send()
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on download_mail')
    #Notificación de actualización
    def upgrade_mail_survey(self, st_start, st_end, path_plot):
        try:
            mailItem = olApp.CreateItem(0)
            attachment = mailItem.Attachments.Add(path_plot)
            attachment.PropertyAccessor.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x3712001F", "Id1")
            subject = 'IO | Confirmation Job | Upgrade Elite Survey | ' + dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')
            body = '''
                <html><head>
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                <style type="text/css">
                    p {font-size: 11pt; font-family: 'calibri'}
                    table {border: 0px; border-spacing:0; font-size: 10pt; font-family: 'calibri'}
                    thead tr th {border: 0px solid black;text-align: center; background: rgb(91,155,213); color: white;}
                    td {border: 0px solid black;text-align: center; color: black; border-style: none; border-color: orange;}
                    tr {border: 0px solid black;text-align: center; color: black; border-style: none; border-color: orange;}
                    tbody {border-spacing:0; text-align: center; border: 0.5px solid black;}
                </style>
                </head>
                <body>
                <table>
                    <tr>
                        <td colspan="4" style="text-align:left; padding:10px">
                            <p>Buen día a todos.<br><br>
                            La carga de encuestas del <b>''' + st_start +'''</b> al <b>''' + st_end +'''</b> fue completada. La información se encuentra disponible en la tabla <b>elt.tbl_KPI_EncuestasBlue</b>.<br>
                            <b>A cotinuación los indicadores mas relevantes:</b><br>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align:left"><img src="cid:Id1" style="width: 80%;"></td>
                        <td>
                            <b>Cargados</b><br>
                            ''' + load_html + '''
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>Top 3: Mayor NPS</b><br>
                            ''' + hnps_html + '''
                        </td>
                        <td>
                            <b>Top 3: Menor NPS</b><br>
                            ''' + lnps_html + '''
                        </td>
                        <td>
                            <b>Top 3: Mayor CSAT</b><br>
                            ''' + hcsat_html + '''
                        </td>
                        <td>
                            <b>Top 3: Menor CSAT</b><br>
                            ''' + lcsat_html + '''
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4" style="text-align:left; padding:5px">
                            <b>Detalles de la ejecución:</b><br>
                        </td>
                    </tr>
                </table>
                <ul>
                    <li><b>JOB:</b> ''' + st_pathn + ''' </li>
                    <li><b>FECHA:</b> ''' + dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + '''</li>
                    <li><b>HOSTNAME:</b> ''' + st_hostn + '''</li>
                </ul>
                <b style="color:black;">Operational Intelligence</b><br>
                <b style="color:#0070C0">Customer and Enterprise Care</b><br>
                <b style="color:#FB1F6E">#CambiaElJuego </b>
                <b style="font-size:24.0pt;color:#BF0CEA">•</b><br><br>
                <p>
                <b style="color:#00B0F0">AT&T México</b><br>
                Blvd Manuel  Ávila Camacho 5 Lomas de Sotelo, Naucalpan de Juárez, Estado de México, CP 53390<br><br>
                El uso o divulgación fuera de las empresas AT&T está prohibido, excepto mediante acuerdo escrito.
                Este mensaje y cualesquiera archivos adjuntos contienen información confidencial de la empresa dirigidos exclusivamente para los destinatarios.
                Si usted ha recibido este mensaje por error, favor de no reenviar o distribuir a cualquier otra persona
                , pero favor de llamar al teléfono [55.30302737]  para reportar el error y posteriormente le pedimos borrar este mensaje de su sistema
                </p>
                </body>
                </html>
                '''
            mailItem.Subject = subject
            mailItem.BodyFormat = 2
            mailItem.HTMLBody = body
            mailItem.To = MailTo
            mailItem.Cc = MailCC
            mailItem.SentOnBehalfOfName = MailFrom
            mailItem.Send()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': El correo de notificación de carga ha sido enviado')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on upgrade_mail_survey')
    #Proceso completo
    def load(self, proc):
        try:
            try:
                SurveyElite.clean_files(self)
                SurveyElite.scrapping_survey(self)
            except Exception as error:
                result = 'La descarga de encuestas Elite no fue completada debido a un error en el proceso'
                subject = 'IO | Error Job | Elite Survey Files | ' + dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')
                formato = '<b style="color:#FB1F6E">'
            else:
                result = 'La descarga de Encuestas Elite fue completada y guardada en la siguiente ruta: ' + path_download
                subject = 'IO | Confirmation Job | Elite Survey Files | ' + dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')
                formato = '<b style="color:black;">'
            finally:
                SurveyElite.notification_mail(self, subject, formato, result)
            '''
            '''
            #procesamiento de archivo
            try:
                SurveyElite.df_excel(self)
                engine, conn, cursor = SurveyElite.conn_red(self)
                conn_blue,engin_blue,crsor_blue = SurveyElite.conn_blue(self)
                SQL_stDate, SQL_edDate, st_start, st_end, nYearMonth, cYear, cMonth = SurveyElite.df_excel(self)
                qry_cartera, qry_hc, qry_del, qry_del2, qry_plot1, qry_plot2, qry_acum, qry_hcc,qry_del_b = SurveyElite.queries(self, nYearMonth, cMonth, cYear, SQL_stDate, SQL_edDate)
                new_df=SurveyElite.df_survey(self, engine, qry_cartera, qry_hc)
                registros_normales=dp.dp_server(new_df,'elt','tbl_KPI_EncuestasBlue','2023-08-01',yesterday,'dFecha_Encuesta',nombre_dia,conn)
                if registros_normales==1 :
                    SurveyElite.load_survey(self, engine, conn, cursor, qry_del)
                    SurveyElite.load_survey_blue(self, engin_blue, conn_blue, crsor_blue, qry_del_b)
                    

                SurveyElite.df_mail(self, engine, qry_plot2)
            except Exception as error:
                subject = 'IO | Error Job | Upgrade Elite Survey | ' + dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')
                result = 'La tabla elt.tbl_KPI_EncuestasBlue no pudó ser actualizada debido a un error en el proceso'
                formato = '<b style="color:#FB1F6E">'
                SurveyElite.notification_mail(self, subject, formato, result)
            else:
                path_plot = SurveyElite.gen_plot(self, engine, qry_plot1, qry_plot2)
                SurveyElite.upgrade_mail_survey(self, st_start, st_end, path_plot)
                try:
                    SurveyElite.df_acum(self, engine, qry_acum, qry_hcc)
                    SurveyElite.load_acum(self, engine, conn, cursor, qry_del2)
                except Exception as error:
                    subject = 'IO | Error Job | Upgrade Dashboard Elite | ' + dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')
                    result = 'La tabla elt.tbl_Encuestas no pudó ser actualizada debido a un error en el proceso'
                    formato = '<b style="color:#FB1F6E">'
                else:
                    subject = 'IO | Confirmation Job | Upgrade Dashboard Elite | ' + dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')
                    result = 'La tabla elt.tbl_Encuestas fue actualizada correctamente'
                    formato = '<b style="color:black;">'
                finally:
                    SurveyElite.notification_mail(self, subject, formato, result)
        except Exception as error:
            status = 'NOK'
            msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' + repr(error)
        else:
            status = 'OK'
            msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Nothing went wrong'
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            return status, msg_proc
   

       
'''
def main():
    runObj = SurveyElite()
    run_process = str(Key)
    result = runObj.load(run_process)
main()
'''