'''   ##########  Comienza importación de módulos ##########   '''
from datetime import datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Módulos Generales
import pathlib, socket, os, sys, warnings, time
import pandas as pd
import numpy as np
#SQL Alchemy
from sqlalchemy import event
from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.lib_mail as mail
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')
'''   ##########  Comienza definición de variables ##########   '''
warnings.filterwarnings("ignore")
#Detalles de ejecución
path_file = pathlib.Path(__file__)
st_hostn = socket.gethostname()
exec_path = str(os.getcwd())
#Fechas
today = dt.today()
#mtd_date = dt.strftime(today, '%Y-%m-%d %H:%M:%S') #Fecha final YYYY-mm-dd
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')
'''   ##########  Comineza ejecución del programa ##########   '''


class space_seeker:
    #0.Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
        self.no_info = 0
    #1.Conexión a Azul
    def conn_blue(self):
        try:
            conn_url, engine_blue, conn_blue, cursor_blue = dbConn.get_ETL_OIEngineBlue_Connection()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa OI Bue Server')
            return conn_url, engine_blue, conn_blue, cursor_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_blue: ' +  repr(error)) 
            self.err += 1
            raise ValueError(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_blue: ' +  repr(error))
    #3.Definición de directorios
    def lista_discos(self):
        try:
            disco_o = '\\\\135.208.36.251\\Op_Intelligence'
            disco_p = '\\\\135.208.36.233\\Inteligencia_op'
            disco_r = '\\\\135.208.36.251\\migracion_io'
            #list_disk = [disco_o, disco_p, disco_r]
            list_disk = [disco_p]
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lista de directorios generada')
            return list_disk
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on scan_files: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on scan_files')
    #3.Dataframe full
    def df_files(self, disk):
        try:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Escaneando ' + disk) 
            #Dataframe vacio para llenar
            columns = ['file_name', 'path_file', 'full_name', 'short_path', 'extension', 'mb_size', 'create_date'
                       ,'modify_date', 'disco']
            df_control = pd.DataFrame(columns = columns)
            sub_count = len(disk) + 1
            #Escaneo de archivos
            for path, subfolder, list_files in os.walk(disk):
                for file in list_files:
                    try:
                        full_name = os.path.join(path, file)
                        size_mb = os.path.getsize(full_name)/1000000
                        extension = os.path.splitext(full_name)[1].lower()
                        created = time.ctime(os.path.getctime(full_name))
                        created = time.strftime("%Y-%m-%d %H:%M:%S", time.strptime(created))
                        modified = time.ctime(os.path.getmtime(full_name))
                        modified = time.strftime("%Y-%m-%d %H:%M:%S", time.strptime(modified))
                        short_path = path[sub_count:]
                        #print(size_mb, extension, created, modified, short_path)
                        #Inicia creación del dataframe
                        data_list = [[file, path, full_name, short_path, extension, size_mb, created, modified, disk]]
                        df_file = pd.DataFrame(data_list, columns = columns)
                        df_control = pd.concat([df_control, df_file])
                    except Exception as error:
                        print('Error en ' + full_name + ' ' + repr(error))
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Dataframe con archivos generado') 
            return df_control
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on scan_files: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on scan_files')
    #4.DataLayer
    def df_levels(self, df_control):
        try:
            sub = '\\\\'
            df_control['mtd_date'] = dt.today() #df_control['mtd_date']
            df_control['create_date'] = pd.to_datetime(df_control['create_date'])
            df_control['modify_date'] = pd.to_datetime(df_control['modify_date'])
            df_control['level_list']  = df_control['short_path'].str.split(sub).astype(str)
            df_control['list']  = df_control['short_path'].str.split(sub)#.astype(str)
            df_control['folder'] = df_control['list'].str[-1].fillna(np.nan).replace([np.nan], [None])
            df_control['level_1'] = df_control['list'].str[0].fillna(np.nan).replace([np.nan], [None])
            df_control['level_2'] = df_control['list'].str[1].fillna(np.nan).replace([np.nan], [None])
            df_control['level_3'] = df_control['list'].str[2].fillna(np.nan).replace([np.nan], [None])
            df_control['level_4'] = df_control['list'].str[3].fillna(np.nan).replace([np.nan], [None])
            df_control['level_5'] = df_control['list'].str[4].fillna(np.nan).replace([np.nan], [None])
            df_control['level_6'] = df_control['list'].str[5].fillna(np.nan).replace([np.nan], [None])
            df_control['level_7'] = df_control['list'].str[6].fillna(np.nan).replace([np.nan], [None])
            
            df_to_sql = df_control[['level_list']]# ,'level_list' ,'folder' ,'short_path' ,'path_file' ,'full_name' ,'file_name' ,'extension' ,'create_date' ,'modify_date' ,'mb_size' ,'level_1' ,'level_2' ,'level_3' ,'level_4' ,'level_5' ,'level_6' ,'level_7', 'disco']]
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Dataframe de carga listo')
            return df_to_sql
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on df_levels: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on df_levels')
    #6.Carga a SQL
    def load_to_sql(self, df_to_sql, engine, conn, cursor, disk):
        try:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpiando io_internal.tbl_carpetas')
            clean_control = "DELETE FROM io_internal.tbl_carpetas WHERE disco = '" + disk + "';"
            cursor.execute(clean_control)
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Actualizando io_internal.tbl_carpetas')
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            df_to_sql.to_sql('tbl_carpetas', engine, index=False, if_exists="append", schema="io_internal")
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': io_internal.tbl_carpetas actualizada correctamente')
            self.trns += 1
        except Exception as error:
            self.err += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on load_to_sql: ' +  repr(error)) 
            raise ValueError('Error on load_to_sql')
    #Proceso completo
    def load(self, proc):
        try:
            conn_url, engine_blue, conn_blue, cursor_blue = space_seeker.conn_blue(self)
            lista_discos = space_seeker.lista_discos(self)
            for disk in lista_discos:
                df_control = space_seeker.df_files(self, disk)
                df_to_sql = space_seeker.df_levels(self, df_control)
                df_to_sql.to_excel('C:/Users/jx1636/Documents/Seeker.xlsx', index = False)
                space_seeker.load_to_sql(self, df_to_sql, engine_blue, conn_blue, cursor_blue, disk)
        except Exception as error:
            status = 'NOK'
            msg_proc = 'Caught this error: ' + repr(error) if int(self.no_info) == 0 else 'SIN_INFO Caught this error: ' + repr(error)
            #mail.send_notification('Error Job', msg_proc, 'Space Seeker', str(today), self.trns, self.err, st_hostn, exec_path)
        else:
            status = 'OK'
            msg_proc =  'Nothing went wrong'
            #mail.send_notification('Confirmation Job', msg_proc, 'Space Seeker', str(today), self.trns, self.err, st_hostn, exec_path)
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            print(status, msg_proc)
            return status, msg_proc
def main():
    runObj = space_seeker()
    run_process = 'space_seeker'
    result = runObj.load(run_process)
main()
'''
'''