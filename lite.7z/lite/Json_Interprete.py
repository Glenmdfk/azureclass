'''   ##########  Comienza importación de módulos ##########   '''
from datetime import date, datetime as dt
import os, sys, json
import pandas as pd
import warnings

warnings.simplefilter("ignore")

ruta = 'M:/DATA_SCIENCE/PROCESADOR RANKING/INSUMOS/Ranking/Full Service/Esquema.json'

class reader_json():
    #init
    def __init__(self):
        self.trns = 0
        self.err = 0
        self.ruta=ruta
    #read_json
    def read_json(self):
        try:
            with open(self.ruta) as archivo_json:
                data = json.load(archivo_json)
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lectura completada') 
            return data
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on read_json: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on read_json')
    #columnas
    def interprete(self, data):
        try:
            ranking = data["ranking"]
            year_month = data["year_month"]
            tenure = data["tenure"]
            Type_Tenure = data["type_tenure"]
            intervalos_tenure = data["tenure_threshold"]
            kpi = data["kpi"]
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Interpretación correcta de array') 
            return ranking, year_month, tenure, Type_Tenure, intervalos_tenure, kpi
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on interprete: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on interprete')
    #Procesador
    def df_json(self, ranking, year_month, tenure, Type_Tenure, intervalos_tenure, kpi):
        try:
            dataframes={}
            for i in kpi:
                dataframes[i] = pd.DataFrame(kpi[i])
                dataframes[i]["kpi"] = i
                dataframes[i]["tenure"] = tenure
                dataframes[i]["type_tenure"] = Type_Tenure
                dataframes[i]["tenure_threshold"] = intervalos_tenure
            new_data = pd.concat(dataframes.values(),keys = dataframes.keys()).reset_index(drop=True)
            new_data["year_month"]=year_month
            new_data["ranking"] = ranking
            new_data["goal"]=new_data["goal"].astype(str)
            new_data["wgt"]=new_data["wgt"].astype(str)
            new_data["mxsc"]=new_data["mxsc"].astype(str)
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrame generado') 
            return new_data
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on df_json: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on df_json')
    #Proceso completo
    def load(self, proc):
        try:
            data = reader_json.read_json(self)
            ranking, year_month, tenure, Type_Tenure, intervalos_tenure, kpi = reader_json.interprete(self, data)
            new_data = reader_json.df_json(self, ranking, year_month, tenure, Type_Tenure, intervalos_tenure, kpi)
            print(new_data)
        except Exception as error:
            status = 'NOK'
            msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' + repr(error)
        else:
            status = 'OK'
            msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Nothing went wrong'
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            return status, msg_proc

def main():
    runObj = reader_json()
    run_process = str('reader_json')
    result = runObj.load(run_process)
main()
'''
'''