'''   ##########  Comienza importación de módulos ##########   '''
from datetime import date, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
import os, sys, socket, pathlib, warnings
from time import sleep
import pandas as pd
#SQL Alchemy
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.config as config
import Libraries.lib_mail as mail
#Detalles de ejecución
path_file = pathlib.Path(__file__)
st_hostn = socket.gethostname()
exec_path = str(os.getcwd())
warnings.filterwarnings("ignore")
#Fechas
today = date.today()
#Objetos
#df_objects = pd.DataFrame(columns=['objeto', 'tipo_objeto', 'dependencia', 'tipo_dep'])

class depends:
    #1.Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
    #1.Conexión a DataManagement
    def conn_red(self):
        try:
            server = config.DATAMANAGEMENT_CONFIG["Server"]
            conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_ChardDM_Connection()})
            engine = create_engine(conn_url)
            conn = engine.raw_connection()
            cursor = conn.cursor()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa al servidor: ' + str(server))
            self.trns += 1
            return engine, conn, cursor
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_red: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_red')
    #2.Define objetos a explorar
    def execute_query(self, engine):
        try:
            qry_objetos = """SELECT CONCAT(SCHEMA_NAME(schema_id),'.',name) AS objeto
                    ,type_desc
                FROM sys.objects
                WHERE type_desc IN('SQL_STORED_PROCEDURE','VIEW')
            --WHERE type_desc IN('SQL_STORED_PROCEDURE','USER_TABLE','VIEW','SQL_TRIGGER','SYNONYM')
            ORDER BY SCHEMA_NAME(schema_id), name"""
            objects = pd.read_sql(qry_objetos, engine)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Los objetos fueron obtenidos')
            return objects
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on execute_query: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on execute_query')
    #3.Obtener dependencias de tablas
    def get_table_depends(self, objects, engine):
        try:
            df_tables = pd.DataFrame(columns=['objeto', 'tipo_objeto', 'dependencia', 'tipo_dep'])
            for index, row in objects.iterrows():
                objeto = row['objeto']
                tipo = row['type_desc']
                if tipo == 'USER_TABLE':
                    qry_depends = "EXEC SP_DEPENDS '" + objeto + "';"
                    try:
                        result = pd.read_sql(qry_depends, engine)
                        for index, row in result.iterrows():
                            df_to_append = pd.DataFrame({'objeto':[objeto]
                                ,'tipo_objeto':['USER_TABLE']
                                ,'dependencia':[row['name']]
                                ,'tipo_dep':[row['type']]
                            })
                            df_tables = df_tables.append(df_to_append, ignore_index = True)
                    except:
                        None
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Las dependencias de tablas fueron obtenidas')
            return df_tables
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on get_table_depends: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on get_table_depends')
    #3.Obtener dependencias de stored
    def get_sp_depends(self, objects, engine):
        try:
            df_stored = pd.DataFrame(columns=['objeto', 'tipo_objeto', 'dependencia', 'tipo_dep'])
            for index, row in objects.iterrows():
                objeto = row['objeto']
                tipo = row['type_desc']
                if tipo == 'SQL_STORED_PROCEDURE' or tipo == 'VIEW':
                    qry_depends = "EXEC SP_DEPENDS '" + objeto + "';"
                    try:
                        result = pd.read_sql(qry_depends, engine)
                        for index, row in result.iterrows():
                            df_to_append = pd.DataFrame({'objeto':[objeto]
                                ,'tipo_objeto':[tipo]
                                ,'dependencia':[row['name']]
                                ,'tipo_dep':[row['type']]
                            })
                            df_stored = df_stored.append(df_to_append, ignore_index = True)
                            df_stored = df_stored.drop_duplicates(subset=['objeto','tipo_objeto','dependencia', 'tipo_dep'], keep='last')
                    except:
                        None
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Las dependencias de stored procedure fueron obtenidas')
            return df_stored
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on get_sp_depends: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on get_sp_depends')
    #4.Unificar DataFrame
    def merge_df(self, df_tables, df_stored):
        try:
            df_objects = df_tables.append(df_stored)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Dataframe unificado')
            return df_objects
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on get_sp_depends: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on get_sp_depends')
    #5.Exporta a CSV
    def export_csv(self, df_objects):
        try:
            #os.makedirs('C:/Users/jx1636/Desktop/Reportes/Python/', exist_ok=True)  
            df_objects.to_excel('C:/Users/jx1636/Desktop/Reportes/Python/depends.xlsx',index=False)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Exportación completa')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on export_csv: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on export_csv')
    #6.Proceso completo
    def load(self, proc):
        try:
            engine, conn, cursor = depends.conn_red(self)
            objects = depends.execute_query(self, engine)
            df_tables = depends.get_table_depends(self, objects, engine)
            df_stored = depends.get_sp_depends(self, objects, engine)
            df_objects = depends.merge_df(self, df_tables, df_stored)
            depends.export_csv(self, df_objects)
        except Exception as error:
            status = 'NOK'
            msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' + repr(error)
            #mail.send_notification('Error Job', msg_proc, 'Tickets', str(today), self.trns, self.err, st_hostn, exec_path)
        else:
            status = 'OK'
            msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Nothing went wrong'
            #mail.send_notification('Confirmation Job', msg_proc, 'Tickets', str(today), self.trns, self.err, st_hostn, exec_path)
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            return status, msg_proc
'''
'''
def main():
    runObj = depends()
    run_process = str('depends')
    result = runObj.load(run_process)
main()