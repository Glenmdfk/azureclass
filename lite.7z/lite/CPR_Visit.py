'''   ##########  Comienza importación de módulos ##########   '''
#Necesario instalar las librerías: html5lib, lxml
from datetime import date, timedelta, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Módulos Generales
import pathlib, socket, os, sys, warnings
from dateutil.relativedelta import relativedelta
from time import sleep
import pandas as pd
import numpy as np
#Selenium
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium import webdriver
#SQL Alchemy
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.distro as distro
import Libraries.config as config
import Libraries.lib_mail as mail
import Libraries.lib_queries as qry
import Libraries.data_profiling as dp

print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')
'''   ##########  Comienza definición de variables ##########   '''
Key = 'CPR_Visit'
warnings.filterwarnings("ignore")
#Detalles de ejecución
path_file = pathlib.Path(__file__)
st_hostn = socket.gethostname()
exec_path = str(os.getcwd())
#Fechas
today = date.today()
year_month=today.year*100+today.month
ed_date = today - timedelta(days = 1) #Fecha fin (día vencido)
st_date = ed_date - timedelta(days = ed_date.day - 1) #Fecha inicio
days = ed_date.day #Días hasta la fecha fin
if days < 6: st_date = st_date - relativedelta(months = 1)
else: st_date = st_date
st_start = dt.strftime(st_date, '%d/%m/%Y') #Fecha inicial dd/mm/YYYY
st_end = dt.strftime(ed_date, '%d/%m/%Y') #Fecha final dd/mm/YYYY
sq_start = dt.strftime(st_date, '%Y-%m-%d') #Fecha inicio dd-mm-YYYY
sq_end = dt.strftime(ed_date, '%Y-%m-%d') #Fecha fin String dd-mm-YYYY
dw_date = dt.strftime(ed_date, '%d_%m_%Y') #Fecha descarga dd_mm_YYYY
#Variables de correo - Envio
MailFrom = distro.General['Sender']
MailTo = distro.General['ToDistro']
MailCC = distro.General['CcDistro']
wMailCC = distro.GeneralNew['CcDistro']
#Variables para usuarios
jVar = pd.read_json('C:/App/Variables/Domain.json')
UsGlobal = jVar['Username']['MASTER']
PsGlobal = jVar['Password']['PASS_MASTER']
#Variables de correo - Autenticación
UsMail = jVar['Username']['OUTLOOK']
PsMail = jVar['Password']['PASS_OUTLOOK']
Host = '135.208.33.24'
Port = 587
#Variables de directorio
path = pathlib.Path(__file__).parent.absolute() #Directorio actual
default_dw = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/EBS/CLUB_ELITE/CPR/ETL/INSUMOS/CPR VISITAS'
download_path = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/EBS/CLUB_ELITE/CPR/ETL/INSUMOS/CPR VISITAS/'
visit_path = download_path + 'ExportaATCVisitaCompleta.xls'
visit_path_prov = download_path + 'ExportaATCVisitaCompleta.xlsx'
#Ruta de visitas
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')
'''   ##########  Comineza ejecución del programa ##########   '''
class CPR_Visit:
    #1.Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
        self.no_info = 0
    #2.Conexión a DataManagement
    def conn_red(self):
        try:
            server = config.DATAMANAGEMENT_CONFIG["Server"]
            conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_ChardDM_Connection()})
            engine = create_engine(conn_url)
            conn = engine.raw_connection()
            cursor = conn.cursor()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa al servidor: ' + str(server))
            return engine, conn, cursor
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_red: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_red')
    #3.Queries
    def conn_blue(self):
        try:
            conn_url, engine_blue, conn_blue, cursor_blue = dbConn.get_ETL_OIEngineBlue_Connection()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa OI Bue Server')
            return conn_blue, engine_blue, cursor_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_blue: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_blue')
    #4.Mover Archivos
    def move_files(self):
        try:
            for i in os.listdir(download_path):
                if i.endswith('.xls'):
                    os.replace(download_path + i, download_path + 'HISTORICO/' + i.replace('.xls','_CPR_') + dw_date + '.xls')
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Archivos movidos al historico')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on move_files: ' +  repr(error)) 
            self.err += 1
            print('Error on move_files')
    #5.Downloading Files (Extract Visitas)
    def scrapping_visit(self):
        try:
            url='https://www.cpratt.mx/cpr_2016/welcome.aspx'
            driver_path = '//135.208.36.251/Op_Intelligence/DOCUMENTACION/CONTROLES_INTERNOS/Aplicaciones/chromedriver.exe'
            driver_service = Service(executable_path=driver_path)
            #Opciones de navegación
            prefs = {"download.default_directory" : default_dw}
            options = Options()
            options.add_argument('--start-maximized')
            options.add_argument('--disable-extensions')
            options.add_experimental_option("prefs",prefs)
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            driver = webdriver.Chrome(service=driver_service, options=options)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': La configuración de Chrome esta lista')
            #Navegación iniciada
            driver.get(url)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Navegador iniciado')
            sleep(5)
            #Usuario
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Introduciendo credenciales')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vNOMBRE')))\
                .send_keys(UsGlobal)
            sleep(3)
            #Contraseña
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vPIN')))\
                .send_keys(PsGlobal)
            sleep(3)
            #Iniciar sesión
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.NAME, 'LOG')))\
                .click()
            sleep(8)
            #Menú Retail
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vIMAGE2')))\
                .click()
            sleep(5)
            #Descarga Visitas
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Comienza busqueda de Visitas')
            visitas = 'https://www.cpratt.mx/cpr_2016/HATTExpATCVC.aspx'
            driver.get(visitas)
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Inicia descarga de Visitas del ' + str(st_start) + ' al ' + str(st_end))
            #Seleccionar Titulo
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CLASS_NAME, 'Titulo1')))\
                .click()
            sleep(3)
            #Seleccionar Fecha Inicio
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vSELFECINI')))\
                .click()
            sleep(3)
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vSELFECINI')))\
                .send_keys(st_start)
            sleep(3)
            #Seleccionar Fecha Fin
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vSELFECFIN')))\
                .click()
            sleep(3)
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vSELFECFIN')))\
                .send_keys(st_end)
            sleep(3)
            #Todos los consultores
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vCONSULTOR')))\
                .click()
            sleep(5)
            key_to_send = 'Todas'
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vCONSULTOR')))\
                .send_keys(key_to_send)
            sleep(3)
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'vCONSULTOR')))\
                .send_keys(Keys.ENTER)
            sleep(3)
            #Boton de exportar
            inicia_scrapping=dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.NAME, 'EXPORTA')))\
                .click()
            sleep(60)
            #Espera a que termine la descarga
            validacion= os.path.exists(visit_path)
            if dt.strftime(dt.now()+timedelta(seconds=60), '%d/%m/%Y %H:%M:%S')>inicia_scrapping and not validacion:
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')+': la descarga no se completo')
                scrpping_success=0
                sleep(3)
                driver.quit()                
            else:
                sleep(5)
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Descarga de visitas finalizada')
                #Finalizar
                sleep(3)
                driver.quit()
                self.trns += 1
                scrpping_success=0
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Scrapping de Visitas completado')
            
            return scrpping_success
            

            '''
            i = 0
            while i == 0: #Termina cuando la condición se deje de cumplir
                count = 0
                li = os.listdir(download_path)
                for i in li:
                    if i.endswith(".xls"):
                        count = count + 1
                if count == 0:
                    i = 0
                else:
                    i = 1
            '''

        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on scrapping_visit: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on scrapping_visit')
    #6.DataFrame de visitas
    def df_visit_xlsx(self,path):
        try:
            #lista_ap = pd.read_excel(visit_path, header=2)
            #Preparando para subir al servidor rojo
            red_df = pd.read_excel(path, header=2)
            red_df.columns = ['cRegion','cAttuidDirector','cDirector','cAttuidManager','cManager','cAttuidSupervisor','cSupervisor','cUser','cVisist','dDate','tHour','cFoto','cType','cPlatform','cAccount','cCostumer','cContact','cPhone','cMail','cMotive','cFotoCierre','cStrengths','cOpportunities','tHour2','cConsultant','cAttuid','cFirma1','cClient','cFirma2']
            red_df['lDate'] = pd.to_datetime(red_df['dDate'], dayfirst=True)
            red_df['dDate'] = red_df['lDate'].astype(str)
            red_df['tHour'] = np.where(red_df['tHour'] == 'N : :', None, red_df['tHour'])
            red_df['nMonth'] = red_df['lDate'].dt.year * 100 + red_df['lDate'].dt.month
            red_df['cStrengths'] = red_df['cStrengths'].fillna('') #Elminamos columnas nulas
            red_df['cOpportunities'] = red_df['cOpportunities'].fillna('') #Elminamos columnas nulas
            red_df['cCostumer'] = red_df['cCostumer'].fillna('') #Elminamos columnas nulas
            red_df['cPhone'] = red_df['cPhone'].fillna('') #Elminamos columnas nulas
            red_df['cClient'] = red_df['cClient'].fillna('') #Elminamos columnas nulas
            visit_red = red_df[['cRegion','cDirector','cManager','cSupervisor','cUser','cVisist','dDate','tHour','cType','cAccount','cCostumer','cContact','cPhone','cMail','cMotive','cStrengths','cOpportunities','cConsultant','cClient','nMonth']]
            visit_blue=visit_red.rename(columns={'cRegion':'region','cDirector':'director ','cManager':'manager ','cSupervisor':'supervisor ','cUser':'name_user ','cVisist':'visist ','dDate':'row_date','tHour':'hour_visit','cType':'name_type ','cAccount':'account ','cCostumer':'costumer ','cContact':'contact ','cPhone':'phone ','cMail':'mail ','cMotive':'motive ','cStrengths':'strengths ','cOpportunities':'opportunities ','cConsultant':'consultant ','cClient':'client ','nMonth':'month_number'})
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrame visitas rojo listo para carga')
            self.trns += 1
            return visit_red,visit_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on df_visit: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on df_visit')

    def df_visit(self):
        try:
            lista_ap = pd.read_html(visit_path, header=2)
            
            #Preparando para subir al servidor rojo
            red_df = lista_ap[0]
            red_df.columns = ['cRegion','cAttuidDirector','cDirector','cAttuidManager','cManager','cAttuidSupervisor','cSupervisor','cUser','cVisist','dDate','tHour','cFoto','cType','cPlatform','cAccount','cCostumer','cContact','cPhone','cMail','cMotive','cFotoCierre','cStrengths','cOpportunities','tHour2','cConsultant','cAttuid','cFirma1','cClient','cFirma2']
            red_df['lDate'] = pd.to_datetime(red_df['dDate'], dayfirst=True)
            red_df['dDate'] = red_df['lDate'].astype(str)
            red_df['tHour'] = np.where(red_df['tHour'] == 'N : :', None, red_df['tHour'])
            red_df['nMonth'] = red_df['lDate'].dt.year * 100 + red_df['lDate'].dt.month
            red_df['cStrengths'] = red_df['cStrengths'].fillna('') #Elminamos columnas nulas
            red_df['cOpportunities'] = red_df['cOpportunities'].fillna('') #Elminamos columnas nulas
            red_df['cCostumer'] = red_df['cCostumer'].fillna('') #Elminamos columnas nulas
            red_df['cPhone'] = red_df['cPhone'].fillna('') #Elminamos columnas nulas
            red_df['cClient'] = red_df['cClient'].fillna('') #Elminamos columnas nulas
            visit_red = red_df[['cRegion','cDirector','cManager','cSupervisor','cUser','cVisist','dDate','tHour','cType','cAccount','cCostumer','cContact','cPhone','cMail','cMotive','cStrengths','cOpportunities','cConsultant','cClient','nMonth']]
            visit_blue=visit_red.rename(columns={'cRegion':'region','cDirector':'director ','cManager':'manager ','cSupervisor':'supervisor ','cUser':'name_user ','cVisist':'visist ','dDate':'row_date','tHour':'hour_visit','cType':'name_type ','cAccount':'account ','cCostumer':'costumer ','cContact':'contact ','cPhone':'phone ','cMail':'mail ','cMotive':'motive ','cStrengths':'strengths ','cOpportunities':'opportunities ','cConsultant':'consultant ','cClient':'client ','nMonth':'month_number'})
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrame visitas rojo listo para carga')
            self.trns += 1
            return visit_red,visit_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on df_visit: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on df_visit')
    #7.Carga de visitas
    def load_visit(self, engine, conn, cursor, visit_red,schem,tabla,field_server,mes):
        try:
            if tabla=='tbl_cpr_results':
                qry_clean = "DELETE FROM "+schem+"."+tabla+" WHERE month_number='"+str(mes)+"'"
            else:
                qry_clean = "DELETE FROM "+schem+"."+tabla+" WHERE "+field_server+" BETWEEN '" + sq_start + "' AND '" + sq_end +"'"
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': '+qry_clean)
            cursor.execute(qry_clean)
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpiando '+tabla)
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            visit_red.to_sql(tabla, engine, index=False, if_exists="append", schema=schem)
            conn.commit()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga de '+tabla+' completa')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on load_visit: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on load_visit')
    #9.Proceso completo
    def cpr_results(self,cursor,conn,yearmonth):
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': comienza proceso CPR RESULTS')
            query=qry.read_qry('/10_103_133_108/DataManagement/qry_cpr_results.txt',1)
            data=qry.assign_variables(query,'YEAR_MONTH',yearmonth)            
            cursor.execute(data)
            conn.commit()
            query_blue="""select 
            cLoginPtn as login_ptn,
            nGrupos as groups,
            cRango as range_name,
            cAttuid as atitud,
            cConsultor as consultant,
            cCoordinador as coordinator,
            cGerente as manager,
            cDirector as director ,
            cRegion_Elite as region_elite,
            nMonth as month_number,
            cNum_Consultor as consultant_number,
            cHc_Direccion as hc_diretion,
            cHc_Director as hc_director,
            cHc_Supervisor as hc_supervisor,
            cHc_Gerencia as hc_management,
            cHc_Gerente as hc_manager,
            cHc_Avp as hc_avp,
            cNombre_Completo as full_name,
            cNombre as name_hc,
            cMaterno as last_name_maternal,
            cPaterno as last_name_paternal,
            cPuesto as position,
            nVisita_Asig as assigned_visit
            from elt.CPR_RESULTS where nMonth='"""+str(yearmonth)+"""'"""
            data_blue=pd.read_sql(query_blue,conn)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Finaliza proceso CPR RESULTS SERVER RED')
            return data_blue

    def load(self, proc):
        try:
            engine, conn, cursor = CPR_Visit.conn_red(self)
            engine_blue, conn_blue, cursor_blue = CPR_Visit.conn_blue(self)
            val_1=os.path.exists(visit_path)
            val_2=os.path.exists(visit_path_prov)

            print(val_1)
            print(val_2)


            if os.path.exists(visit_path)==True or os.path.exists(visit_path_prov)==True:
                validacion=True
            else:
                validacion=False

            print(validacion)

            schema_both='elt'
            tabla_red='CPR_VISIT'
            campo_red='dDate'
            campo_blue='row_date'
            tabla_blue='tbl_cpr_visit'
            tabla_result_blue='tbl_cpr_results'
            campo_result_blue='month_number'

            if not validacion:
                try:
                    result=CPR_Visit.scrapping_visit(self)
                    if result==1:
                       mail.send_notification('Confirmation Job', msg_proc, 'Scrapping CPR Visit', str(today), self.trns, self.err, st_hostn, exec_path)
                    else:
                        try:
                            result=CPR_Visit.scrapping_visit(self)
                            if result==1:
                                mail.send_notification('Confirmation Job', msg_proc, 'Scrapping CPR Visit', str(today), self.trns, self.err, st_hostn, exec_path)
                            else:
                                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Scrapping NO SE PUDO REALIZAR EN 2 INTENTOS ')
                                msg_proc = 'Caught this error: ' + repr(error) if int(self.no_info) == 0 else 'SIN_INFO Caught this error: ' + repr(error)
                                mail.send_notification('Error Job', msg_proc, 'Scrapping CPR Visit', str(today), self.trns, self.err, st_hostn, exec_path)
                                raise
                        except:
                            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Scrapping ERRONEO')
        
                except:
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Scrapping con Fallas')
                    mail.send_notification('Error Job', msg_proc, 'Scrapping CPR Visit', str(today), self.trns, self.err, st_hostn, exec_path)

                dia_name = dt.strftime((today-timedelta(days=1)),'%a')  
                visit_red,visita_blue = CPR_Visit.df_visit(self)
                resultado_dp=dp.dp_server(visit_red,schema_both,tabla_red,sq_start,sq_end,campo_red,dia_name,conn)
                if resultado_dp==1:
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga red_server')
                    CPR_Visit.load_visit(self, engine, conn, cursor, visit_red,schema_both,tabla_red,campo_red,year_month)
                    df_serv_blue=CPR_Visit.cpr_results(self,cursor,conn,year_month)
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga blue_server')
                    CPR_Visit.load_visit(self, conn_blue, engine_blue, cursor_blue, visita_blue,schema_both,tabla_blue,campo_blue,year_month)
                    CPR_Visit.load_visit(self,conn_blue,engine_blue,cursor_blue,df_serv_blue,schema_both,tabla_result_blue,campo_result_blue,year_month)
                    CPR_Visit.move_files(self)             
                else:
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Data profiling arroja resultados desfavorables')
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga red_server')
                    CPR_Visit.load_visit(self, engine, conn, cursor, visit_red,schema_both,tabla_red,campo_red,year_month)
                    df_serv_blue=CPR_Visit.cpr_results(self,cursor,conn,year_month)
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga blue_server')
                    CPR_Visit.load_visit(self, conn_blue, engine_blue, cursor_blue, visita_blue,schema_both,tabla_blue,campo_blue,year_month)
                    CPR_Visit.load_visit(self,conn_blue,engine_blue,cursor_blue,df_serv_blue,schema_both,tabla_result_blue,campo_result_blue,year_month)
                    CPR_Visit.move_files(self)    
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Se cargan datos al servidor, sin embargo se observo un volumen fueral del rango.')                    


            else:
                dia_name = dt.strftime((today-timedelta(days=1)),'%a')
                try:  
                    visit_red,visita_blue = CPR_Visit.df_visit(self)
                except:
                    visit_red,visita_blue = CPR_Visit.df_visit_xlsx(self,visit_path_prov)
                                    
                resultado_dp=dp.dp_server(visit_red,schema_both,tabla_red,'2023-09-01',sq_end,campo_red,dia_name,conn)
                if resultado_dp==1:
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga red_server')
                    CPR_Visit.load_visit(self, engine, conn, cursor, visit_red,schema_both,tabla_red,campo_red,year_month)
                    df_serv_blue=CPR_Visit.cpr_results(self,cursor,conn,year_month)
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga blue_server')
                    CPR_Visit.load_visit(self, conn_blue, engine_blue, cursor_blue, visita_blue,schema_both,tabla_blue,campo_blue,year_month)
                    CPR_Visit.load_visit(self,conn_blue,engine_blue,cursor_blue,df_serv_blue,schema_both,tabla_result_blue,campo_result_blue,year_month)
                    CPR_Visit.move_files(self)             
                else:
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Data profiling arroja resultados desfavorables')
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga red_server')
                    CPR_Visit.load_visit(self, engine, conn, cursor, visit_red,schema_both,tabla_red,campo_red,year_month)
                    df_serv_blue=CPR_Visit.cpr_results(self,cursor,conn,year_month)
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga blue_server')
                    CPR_Visit.load_visit(self, conn_blue, engine_blue, cursor_blue, visita_blue,schema_both,tabla_blue,campo_blue,year_month)
                    CPR_Visit.load_visit(self,conn_blue,engine_blue,cursor_blue,df_serv_blue,schema_both,tabla_result_blue,campo_result_blue,year_month)
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Se cargan datos al servidor, sin embargo se observo un volumen fueral del rango.') 
                    CPR_Visit.move_files(self)      
            
        except Exception as error:
            status = 'NOK'
            msg_proc = 'Caught this error: ' + repr(error) if int(self.no_info) == 0 else 'SIN_INFO Caught this error: ' + repr(error)
            mail.send_notification('Error Job', msg_proc, 'Load CPR Visit', str(today), self.trns, self.err, st_hostn, exec_path)
        else:
            status = 'OK'
            msg_proc =  'Nothing went wrong'
            mail.send_notification('Confirmation Job', msg_proc, 'Load CPR Visit', str(today), self.trns, self.err, st_hostn, exec_path)
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            print(status, msg_proc)
            return status, msg_proc

'''
def main():
    runObj = CPR_Visit()
    run_process = str(Key)
    result = runObj.load(run_process)
main()
'''