
'''   ##########  Comienza importación de módulos ##########   '''
from datetime import date, timedelta, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Módulos Generales
import smtplib, pathlib, socket, os, sys, warnings
from dateutil.relativedelta import relativedelta
import win32com.client as win32
from time import sleep
import pandas as pd
#Config Mail
olApp = win32.Dispatch('Outlook.Application')
olNS = olApp.GetNameSpace('MAPI')
#Email SMTP
from email.mime.multipart import MIMEMultipart
from email.message import EmailMessage as msg
from email.mime.text import MIMEText
#SQL Alchemy
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
#Selenium
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium import webdriver
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.distro as distro
import Libraries.config as config
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')
'''   ##########  Comienza definición de variables ##########   '''
Key = 'dr7_nps_jc'
warnings.filterwarnings("ignore")
#Detalles de ejecución
path_file = pathlib.Path(__file__) #Lectura archivo actual
st_pathn = str(path_file).upper() #Ruta Mayuscula
st_hostn = socket.gethostname() #Hostname
#Fechas
today = date.today()
fDate = today - timedelta(days = today.day-1)
stDate = fDate - relativedelta(months=1)
edDate = today - timedelta(days = 1)
sqlfirst = dt.strftime(fDate, '%Y-%m-%d')
sqlStart = dt.strftime(stDate, '%Y-%m-%d')
sqlEnd = dt.strftime(edDate, '%Y-%m-%d')
mail_date = dt.strftime(today, '%Y-%m-%d')
#Variables de correo - Envio
MailFrom = distro.General['Sender']
MailTo = distro.General['ToDistro']
MailCC = distro.General['CcDistro']
wMailCC = distro.GeneralNew['CcDistro']
#Variables para usuarios
jVar = pd.read_json('C:\\App\\Variables\\Domain.json')
UsMail = 'os940m@mx.att.com' #jVar['Username']['OUTLOOK']
PsMail = 'Oct1v3os.21_07' #jVar['Password']['PASS_OUTLOOK']
Host = '135.208.33.24'
Port = 587
#Variables de directorio
path = pathlib.Path(__file__).parent.absolute() #Directorio actual
default_dw = '\\\\135.208.36.251\\Op_Intelligence\\MASTER_REPORTS\\SPRINKLR\\CHAT_RETENCIONES\\'
path_ivr = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/IVR_Dashboard/Insumos/'
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')
'''   ##########  Comineza ejecución del programa ##########   '''

class approvals:
    #Lista de tickets
    def list_tickets(self):
        i = 299
        lista_tickets = []
        while i > 185:
            lista_tickets.append('Ticket # ' + str(i))
            i -= 1
        return lista_tickets
    #Scrapping
    def mail_scrapping(self, lista_tickets):
        try:
            #Variables Chrome
            url='https://make.powerautomate.com/environments/Default-2e716fbe-24c8-4fce-9588-dcb5ff25b01d/approvals/received'
            driver_path = '//135.208.36.251/Op_Intelligence/DOCUMENTACION/CONTROLES_INTERNOS/Aplicaciones/chromedriver.exe'
            driver_service = Service(executable_path=driver_path)
            #Opciones de navegación
            prefs = {"download.default_directory" : default_dw}
            options = Options()
            options.add_argument('--start-maximized')
            options.add_argument('--disable-extensions')
            options.add_experimental_option("prefs",prefs)
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            driver = webdriver.Chrome(service=driver_service, options=options)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': La configuración de Chrome esta lista')
            #Navegación iniciada
            driver.get(url)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Navegador iniciado')
            sleep(10)
            #User
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Solicitar user')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.NAME, 'loginfmt')))\
                .send_keys(UsMail)
            sleep(5)
            #Click
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Confirmar')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'idSIButton9')))\
                .click()
            sleep(5)
            #Pwd
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Solicitar pass')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.NAME, 'passwd')))\
                .send_keys(PsMail)
            sleep(5)
            #Click
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Confirmar')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'idSIButton9')))\
                .click()
            sleep(5)
            #Confirm
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': No guardar sesión')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'idBtn_Back')))\
                .click()
            sleep(7)
            x = 0
            y = len(lista_tickets)
            for i in range(y):
                try:
                    element = lista_tickets[x]
                    #Click ticket
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Buscando ' + element)
                    WebDriverWait(driver, 5)\
                        .until(EC.element_to_be_clickable((By.XPATH, '//button[contains(., "' + element + '")]')))\
                        .click()
                    sleep(4)
                    #Elegir respuesta
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Buscando Respuesta')
                    shell = win32.Dispatch("WScript.Shell")
                    shell.Sendkeys("{TAB}")
                    shell.Sendkeys("{TAB}")
                    sleep(1)
                    shell.Sendkeys("{ENTER}")
                    sleep(1)
                    shell.Sendkeys("{ENTER}")
                    sleep(1)
                    #Agregar un comentario
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Comentario')
                    WebDriverWait(driver, 5)\
                        .until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'textarea[aria-label="Agregar un comentario"]')))\
                        .send_keys('Aprobado por vencimiento')
                    sleep(5)
                    #Envíar respuesta
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Confirmar')
                    WebDriverWait(driver, 5)\
                        .until(EC.element_to_be_clickable((By.XPATH, '//button[contains(., "Confirmar")]')))\
                        .click()
                    sleep(8)
                    #Listo
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Listo')
                    WebDriverWait(driver, 5)\
                        .until(EC.element_to_be_clickable((By.XPATH, '//button[contains(., "Listo")]')))\
                        .click()
                    sleep(10)
                    x += 1
                    y += 1
                    lista_tickets.append(element)
                    #sleep(8)
                except:
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ticket No encontrado')
                    x += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Proceso de scrappig finalizado')
            driver.quit()
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on mail_scrapping')
    #Proceso completo
    def load(self, proc):
        lista_tickets = approvals.list_tickets(self)
        approvals.mail_scrapping(self, lista_tickets)
def main():
    runObj = approvals()
    run_process = str('approvals')
    result = runObj.load(run_process)
main()
'''
'''