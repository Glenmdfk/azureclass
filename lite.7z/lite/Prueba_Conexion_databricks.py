import subprocess, requests, json

result = subprocess.run(['databricks', 'cluster', 'list'], capture_output=True, text=True)
print(result.stdout)

#Variables de econexión
DATABRICKS_INSTANCE = 'https://adb-4782182804791024.4.azuredatabricks.net'
TOKEN = ''
SQL_ENDPOINT = '/api/2.0/sql/statements/execute'

#Header para authenticar
headers = {
    'Authorization': f'Bearer {TOKEN}',
    'Content-Type': 'application/json'
}

#Consulta SQL
query = 'SELECT* FROM vst_ctl_cliente LIMIT 10'

payload = {
    "statement": query
    ,"catalog": 'dlprod'
    ,"schema": 'sch_mst_blue'
}

#Enviar Solicitud
response = requests.post(f'{DATABRICKS_INSTANCE}{SQL_ENDPOINT}', headers=headers, data=json.dumps(payload))

if response.status_code == 200:
    result = response.json()
    print(json.dumps(result, indent=2))
else:
    print(f'Error: {response.status_code} - {response.text}')