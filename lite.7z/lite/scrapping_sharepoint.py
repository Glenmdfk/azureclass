from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium import webdriver
from time import sleep
import pandas as pd
jVar = pd.read_json('C:\\App\\Variables\\Domain.json')
UsMail = jVar['Username']['OUTLOOK2']
PsMail = jVar['Password']['PASS_OUTLOOK2']

default_dw = '\\\\135.208.36.251\\Op_Intelligence\\DOCUMENTACION\\Scripts\\files\\'
class Scrapping:
    def ejemplo_scrapping(self):
        try:
            #Configuraciones
            url = 'https://attmx-my.sharepoint.com/'
            driver_path = '//135.208.36.251/Op_Intelligence/DOCUMENTACION/CONTROLES_INTERNOS/Aplicaciones/chromedriver.exe'
            driver_service = Service(executable_path=driver_path)
            prefs = {"download.default_directory":default_dw}
            options = Options()
            options.add_argument('--start-maximized')
            options.add_argument('--disable-extensions')
            options.add_experimental_option("prefs",prefs)
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            driver = webdriver.Chrome(service=driver_service, options=options)
            #Abrir el programa
            driver.get(url)
            sleep(5)
            print('Ingresando Usuario')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.NAME, 'loginfmt')))\
                .send_keys(UsMail)
            sleep(3)
            print('Boton siguiente')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.ID, 'idSIButton9')))\
                .click()
            sleep(3)
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.NAME, 'passwd')))\
                .send_keys(PsMail)
            sleep(3)
            print('Boton siguiente')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.ID, 'idSIButton9')))\
                .click()
            sleep(3)
            try:
                print('Boton siguiente')
                WebDriverWait(driver, 5) \
                    .until(EC.element_to_be_clickable((By.ID, 'idBtn_Back')))\
                    .click()
                sleep(3)
            except:
                print('Elemento no encontrado, continúa proceso')
            print('Boton siguiente')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="HC.xlsx"]')))\
                .click()
            sleep(10)
            print('Ok')
        except Exception as error:
            print('Error on ejemplo_scrapping: ' +  repr(error)) 
            raise ValueError('Error on ejemplo_scrapping')
    
    def load(self, proc):
        Scrapping.ejemplo_scrapping(self)
def main():
    runObj = Scrapping()
    run_process = str('Scrapping')
    result = runObj.load(run_process)
main()