'''   ##########  Comienza importación de módulos ##########   '''
from datetime import date, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Módulos Generales
import pathlib, socket, os, sys, warnings
import pandas as pd
import numpy as np
#SQL Alchemy
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.config as config
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')
'''   ##########  Comienza definición de variables ##########   '''
Key = 'hc_weekly'
warnings.filterwarnings("ignore")
#Detalles de ejecución
path_file = pathlib.Path(__file__)
st_hostn = socket.gethostname()
exec_path = str(os.getcwd())
today = date.today()
file_date = dt.strftime(today, '%Y-%m-%d')
#Variables de directorio
path = pathlib.Path(__file__).parent.absolute()
path_insumo = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/HC/ETL/INSUMOS/Python/'
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')
'''   ##########  Comineza ejecución del programa ##########   '''
class hc_weekly:
    #0.Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
        self.no_info = 0
    #1.Conexión a DataManagement
    def conn_red(self):
        try:
            server = config.DATAMANAGEMENT_CONFIG["Server"]
            conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_TrustedChardDM_Connection()})
            engine = create_engine(conn_url)
            conn = engine.raw_connection()
            cursor = conn.cursor()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa DM Red Server')
            return engine, conn, cursor
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_red: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_red')
    #1.Conexión a OI Bue Server
    def conn_blue(self):
        try:
            conn_url, engine_blue, conn_blue, cursor_blue = dbConn.get_ETL_OIEngineBlue_Connection()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa OI Bue Server')
            return engine_blue, conn_blue, cursor_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_blue: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_blue')
    #2.Read File HC
    def read_file(self):
        try:
            count_fie = 0
            count_sheet = 0
            file_list = []
            #Validación de nombre de archivo
            for file in os.listdir(path_insumo):
                if file.endswith('.xlsx') and file.startswith('HC AT&T'):
                    insumo = path_insumo + file
                    file_list.append(insumo)
                    count_fie += 1
            if count_fie == 0: raise ValueError('Sin archivos para procesar')
            elif count_fie > 1: raise ValueError('Existe mas de un archivo en el directorio')
            else: excel_file = file_list[0]
            #Validación de hoja
            sheet_list = pd.ExcelFile(excel_file).sheet_names
            for sheet in sheet_list:
                if sheet == 'HC OPERATIVO AT&T':
                    count_sheet += 1
            if count_sheet == 0: raise ValueError('No se encontró la hoja HC OPERATIVO AT&T')
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lectura de archivos completada')
            return excel_file
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on read_file: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on read_file')
    #3.File validation
    def file_val(self, excel_file):
        try:
            col_names = ['cATTUID','cUsuarioUnico','nSuccesFactors','cLoginPTN','nLoginAvaya','nExtensionVirtual','nIex_Id','cUsuarioPVS','cUsuarioCCI','cUsuarioCRM','cEstatusCRM','cUsuarioWebBo1','cUsuarioWebBo2','cIdCMS','cUsuarioChat','cUsuarioPolo','cUsuarioWFO','cBlackout','cLicenciaSprinklr','cLicenciaRemedy','cLicenciaSmartchat','cLicenciaOffice','cNombre','cPaterno','cMaterno','cNombreCompleto','cPuesto','dFechaIngreso','dEntregaPosicion','dFechaEntregaOperacion','cAntiguedad','cNomina','cProveedor','cSite','cAreaOperativa','cMarca','cColor','cAplicativo','cTipoCanal','cNombreSkill','cMU','cEsquemaComision','cPostIdPDV','cAgrupacion','cClasificacion','cVP','cAVP','cDireccion','cDirector','cGerenciaSR','cGerente','cSupervisor','cSupervisorACE','cAttuid_jefe_inmediato','nEmp_jefe_inmediato','cJefe_inmediato','cAnalistaCalidad','cCapacitadorAula','cPuestoSimplificado','cClasificacionSimplificada','cCampII','cTurno','nJornada','tEntrada','tSalida','cDescanso','cLunes','cMartes','cMiercoles','cJueves','cViernes','cSabado','cDomingo','cAccesoPeatonal','cVPN','cHomeOffice','cEquipoComputo','cVideoCamara','cSilla','cComentarios','cExcepcionCallID','cMotivos_Excepciones_Calidad','cExclusiones','nWeek']
            sheet = 'HC OPERATIVO AT&T'
            df = pd.read_excel(excel_file, sheet_name=sheet, usecols='C:CH', header=7)
            cols = df.columns
            if cols[0] != 'ATTUID':
                raise ValueError('Validar que los encabezados se encuentren en la fila 8')
            df.columns = col_names
            count_nan = len(df[df['dFechaIngreso'] == '-'])
            if count_nan > 0:
                raise ValueError('El archivo tiene fechas de ingreso vacias')
            df['nWeek'] = df['nWeek'].replace(to_replace=r'[-]+', value='',regex=True)
            max_week = max(df['nWeek'])
            min_week = min(df['nWeek'])
            if max_week != min_week: raise ValueError('Existe más de un mes en el archivo')
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Validación de archivo éxitosa')
            self.trns += 1
            return df, col_names, max_week
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on file_val: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on file_val')
    #4.DataFrame Dates
    def df_week(self, engine, max_week):
        try:
            qry_week = """SELECT
                a.nYearWeekISO nWeek
                ,LAG(a.nYearWeekISO, 1, a.nYearWeekISO) OVER (ORDER BY a.nYearWeekISO DESC) AS next_week
                ,YEAR(MAX(a.dDate))*100+MONTH(MAX(a.dDate)) mes
                ,ISNULL(t1.mes_replica,YEAR(MAX(a.dDate))*100+MONTH(MAX(a.dDate))) mes_replica
                ,CONCAT(LEFT(MIN(a.dDate),8),'01') first_day
            FROM cat.l_date a
            LEFT JOIN (
                SELECT nYearWeekISO, nYearMonth + IIF(RIGHT(nYearMonth,2) = 12, 89, 1) mes_replica
                FROM
                    (
                    SELECT nYearWeekISO, nYearMonth, ROW_NUMBER() OVER(PARTITION BY nYearMonth ORDER BY nYearWeekISO DESC) r
                    FROM cat.l_date WHERE nYear >= YEAR(GETDATE())-2
                    GROUP BY nYearWeekISO, nYearMonth
                    HAVING DATEDIFF(d,MIN(dDate), MAX(dDate)) > 2
                    ) b
                WHERE r = 1) t1 ON a.nYearWeekISO = t1.nYearWeekISO
                WHERE a.nYear >= YEAR(GETDATE())-2
                GROUP BY a.nYearWeekISO, t1.mes_replica
            ORDER BY a.nYearWeekISO"""
            df_week = pd.read_sql(qry_week, engine)
            next_week = df_week['next_week'][df_week['nWeek'] == max_week].iloc[0]
            first_day = df_week['first_day'][df_week['nWeek'] == max_week].iloc[0]
            mes_replica = df_week['mes_replica'][df_week['nWeek'] == max_week].iloc[0]
            list_weeks = []
            list_weeks.append((max_week, first_day))
            list_weeks.append((next_week, first_day))
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lista de semanas generada')
            self.trns += 1
            return list_weeks, mes_replica
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on log_scanner: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on log_scanner')
    #4.DataFrame HC
    def df_hc(self, df, col_names, week, first_day):
        try:
            df_hc = df.copy()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Generando dataframe semana ' + str(week))
            cols_num = ['nSuccesFactors','nLoginAvaya','nIex_Id','nExtensionVirtual','nJornada','cAccesoPeatonal','nEmp_jefe_inmediato']
            def rep(x): 
                y = x.replace(to_replace='[^0-9]+', value=None, regex=True)
                return y
            df_hc[col_names] = np.where(df_hc[col_names] == '-', None, df_hc[col_names])
            df_hc['dFechaIngreso'] = pd.to_datetime(df_hc['dFechaIngreso']).astype(str)
            df_hc['dFechaEntregaOperacion'] = np.where(df_hc['dFechaEntregaOperacion'].fillna('-') == '-', None
                ,pd.to_datetime(df_hc['dFechaEntregaOperacion']).astype(str))
            df_hc['dEntregaPosicion'] = np.where(df_hc['dEntregaPosicion'].fillna('-') == '-', None
                ,pd.to_datetime(df_hc['dEntregaPosicion']).astype(str))
            df_hc[cols_num] = rep(df_hc[cols_num])
            df_hc['nLoginAvaya'] = df_hc['nLoginAvaya'].astype(float).astype("Int32")
            df_hc['tEntrada'] = df_hc['tEntrada'].replace(to_replace='[A-z]', value=None,regex=True).astype(str)
            df_hc['tSalida'] = df_hc['tSalida'].replace(to_replace='[A-z]', value=None,regex=True).astype(str)
            df_hc['tEntrada'] = df_hc['tEntrada'].str[:5].replace('None',None)
            df_hc['tSalida'] = df_hc['tSalida'].str[:5].replace('None',None)
            df_hc[['cLogin','cSexo','cCoordinadorAttendance','cYearWeek','nMonth','nIdPlantilla','cAreaPlantilla','nIdOperativa','cCalidadLlamadas','cPVSAnterior','cEncuestable', 'nWorkdays', 'nHoursPerweek','cEmployment','nLoginUnificado','cGerente1','cAPC_ID','cGlobalLogon']] = None
            df_hc['cGerenciaJR'] = df_hc['cGerenciaSR']
            df_hc['cUsuarioWebBo'] = df_hc['cUsuarioWebBo1']
            df_hc['nWeek'] = week
            df_hc['date_valid'] = df_hc.dFechaEntregaOperacion.combine_first(df.dEntregaPosicion)
            df_hc['first_day_month'] = first_day
            df_hc['first_day_month'] = df_hc['first_day_month'].astype('datetime64[ns]')
            df_hc['date_dif'] = df_hc['first_day_month'] - pd.to_datetime(df_hc['date_valid'])
            df_hc['days_tenure'] = df_hc['date_dif'].dt.days
            df_hc['cTenure'] = np.where(df_hc.days_tenure < 0, 'NA',np.where(df_hc.days_tenure <= 45, '1M',np.where(df_hc.days_tenure <= 75, '2M','3M')))
            df_red = df_hc[['cATTUID','cUsuarioUnico','nSuccesFactors','cLoginPTN','nLoginAvaya','cUsuarioPVS','cUsuarioCCI','cUsuarioCRM','cEstatusCRM','cUsuarioWebBo','nIex_Id','cMU','cAPC_ID','nExtensionVirtual','cUsuarioChat','cUsuarioPolo','cUsuarioWFO','cLicenciaRemedy','cLicenciaSmartchat','cNombre','cPaterno','cMaterno','cNombreCompleto','cPuesto','cSexo','dFechaIngreso','cNomina','cMarca','cDescanso','tEntrada','tSalida','nJornada','cTurno','cAreaOperativa','cColor','cAplicativo','cTipoCanal','cNombreSkill','cVP','cAVP','cDireccion','cDirector','cGerenciaSR','cGerente','cSupervisor','cClasificacion','cSite','cProveedor','cAgrupacion','cComentarios','cSupervisorACE','cPuestoSimplificado','cClasificacionSimplificada','dFechaEntregaOperacion','cCapacitadorAula','cAnalistaCalidad','cCoordinadorAttendance','cLunes','cMartes','cMiercoles','cJueves','cViernes','cSabado','cDomingo','cAntiguedad','cCampII','cEsquemaComision','dEntregaPosicion','cPostIdPDV','cAccesoPeatonal','cVPN','cHomeOffice','cEquipoComputo','cVideoCamara','cSilla','nWeek','cLogin','cGlobalLogon','cGerenciaJR','cGerente1','cIdCMS','cTenure','cBlackout','cAttuid_jefe_inmediato','nEmp_jefe_inmediato','cJefe_inmediato','cExclusiones','cMotivos_Excepciones_Calidad','cUsuarioWebBo2','cExcepcionCallID']]
            df_blue = df_hc[['cATTUID','cUsuarioUnico','nSuccesFactors','cLoginPTN','nLoginAvaya','cUsuarioPVS','cUsuarioCCI','cUsuarioCRM','cEstatusCRM','cUsuarioWebBo','nIex_Id','cMU','nExtensionVirtual','cUsuarioChat','cUsuarioPolo','cUsuarioWFO','cLicenciaRemedy','cLicenciaSmartchat','cNombre','cPaterno','cMaterno','cNombreCompleto','cPuesto','dFechaIngreso','cNomina','cMarca','cDescanso','tEntrada','tSalida','nJornada','cTurno','cAreaOperativa','cColor','cAplicativo','cTipoCanal','cNombreSkill','cVP','cAVP','cDireccion','cDirector','cGerenciaSR','cGerente','cSupervisor','cClasificacion','cSite','cProveedor','cAgrupacion','cComentarios','cSupervisorACE','cPuestoSimplificado','cClasificacionSimplificada','dFechaEntregaOperacion','cCapacitadorAula','cAnalistaCalidad','cLunes','cMartes','cMiercoles','cJueves','cViernes','cSabado','cDomingo','cAntiguedad','cCampII','cEsquemaComision','dEntregaPosicion','cPostIdPDV','cAccesoPeatonal','cVPN','cHomeOffice','cEquipoComputo','cVideoCamara','cSilla','nWeek','cGerenciaJR','cIdCMS','cTenure','cBlackout','cAttuid_jefe_inmediato','nEmp_jefe_inmediato','cJefe_inmediato','cExclusiones','cMotivos_Excepciones_Calidad','cUsuarioWebBo2','cExcepcionCallID']].copy()
            df_blue.columns = ['attuid','unique_user','success_factors','login_ptn','login_avaya','pvs_user','cci_user','crm_user','crm_status','webbo_user','iex_id','mu','virtual_extension','user_chat','user_polo','wfo_user','license_remedy','license_smartchat','name','last_name','mothers_last_name','full_name','position','admission_date','payroll','brand','days_off','entry_time','exit_time','workday','work shift','operative_area','color','aplicative','channel_type','skill_name',	'vp','avp','direction','director','sr_management','manager','supervisor','classification','site','supplier','group','comments','ace_supervisor','simplified_position','simplified_classification','operation_delivery_date','classroom_trainer','quality_analyst','monday','tuesday','wednesday','thrusday','friday','saturday','sunday','labor_old','campii','commission_scheme','delivery_position','post_id_pdv','pedestrian_access','vpn','home_office','computer_equipment','video_camera','chair','year_week','jr_management','id_cms','tenure','blackout','immediate_boss_id','emp_immediate_boss','immediate_boss','exclusions','reasons_exceptions_quality','web_bo2_user','exception_call_id']
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrame hc generado')
            self.trns += 1
            return df_red, df_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on df_hc: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on df_hc')
    #4.DataFrame HC Monthly
    def df_monthly(self, df, mes_replica):
        try:
            df_monthly = df.copy()
            col_names = ['cATTUID','cUsuarioUnico','nSuccesFactors','cLoginPTN','nLoginAvaya','nExtensionVirtual','nIex_Id','cUsuarioPVS','cUsuarioCCI','cUsuarioCRM','cEstatusCRM','cUsuarioWebBo1','cUsuarioWebBo2','cIdCMS','cUsuarioChat','cUsuarioPolo','cUsuarioWFO','cBlackout','cLicenciaSprinklr','cLicenciaRemedy','cLicenciaSmartchat','cLicenciaOffice','cNombre','cPaterno','cMaterno','cNombreCompleto','cPuesto','dFechaIngreso','dEntregaPosicion','dFechaEntregaOperacion','cAntiguedad','cNomina','cProveedor','cSite','cAreaOperativa','cMarca','cColor','cAplicativo','cTipoCanal','cNombreSkill','cMU','cEsquemaComision','cPostIdPDV','cAgrupacion','cClasificacion','cVP','cAVP','cDireccion','cDirector','cGerenciaSR','cGerente','cSupervisor','cSupervisorACE','cAttuid_jefe_inmediato','nEmp_jefe_inmediato','cJefe_inmediato','cAnalistaCalidad','cCapacitadorAula','cPuestoSimplificado','cClasificacionSimplificada','cCampII','cTurno','nJornada','tEntrada','tSalida','cDescanso','cLunes','cMartes','cMiercoles','cJueves','cViernes','cSabado','cDomingo','cAccesoPeatonal','cVPN','cHomeOffice','cEquipoComputo','cVideoCamara','cSilla','cComentarios','cExcepcionCallID','cMotivos_Excepciones_Calidad','cExclusiones','nWeek']
            cols_num = ['nSuccesFactors','nLoginAvaya','nIex_Id','nExtensionVirtual','nJornada','cAccesoPeatonal','nEmp_jefe_inmediato']
            def rep(x): 
                y = x.replace(to_replace='[^0-9]+', value=None, regex=True)
                return y
            df_monthly[col_names] = np.where(df_monthly[col_names] == '-', None, df_monthly[col_names])
            df_monthly['dFechaIngreso'] = pd.to_datetime(df_monthly['dFechaIngreso']).astype(str)
            df_monthly['dFechaEntregaOperacion'] = np.where(df_monthly['dFechaEntregaOperacion'].fillna('-') == '-', None
                ,pd.to_datetime(df_monthly['dFechaEntregaOperacion']).astype(str))
            df_monthly['dEntregaPosicion'] = np.where(df_monthly['dEntregaPosicion'].fillna('-') == '-', None
                ,pd.to_datetime(df_monthly['dEntregaPosicion']).astype(str))
            df_monthly['nWeek'] = mes_replica
            df_monthly[cols_num] = rep(df_monthly[cols_num])
            df_monthly['nLoginAvaya'] = df_monthly['nLoginAvaya'].astype(float).astype("Int32")
            df_monthly['nAccesoPeatonal'] = df_monthly['cAccesoPeatonal']
            df_monthly['cUsuarioWebBo'] = df_monthly['cUsuarioWebBo1']
            df_monthly['tEntrada'] = df_monthly['tEntrada'].replace(to_replace='[A-z]', value=None,regex=True).astype(str)
            df_monthly['tSalida'] = df_monthly['tSalida'].replace(to_replace='[A-z]', value=None,regex=True).astype(str)
            df_monthly['tEntrada'] = df_monthly['tEntrada'].str[:5].replace('None',None)
            df_monthly['tSalida'] = df_monthly['tSalida'].str[:5].replace('None',None)
            df_monthly[['cLogin','cSexo','cCoordinadorAttendance','cYearWeek','nMonth','nIdPlantilla','cAreaPlantilla','nIdOperativa','cCalidadLlamadas','cPVSAnterior','cEncuestable', 'nWorkdays', 'nHoursPerweek','cEmployment','nLoginUnificado','cGerente1','cAPC_ID']] = None
            df_monthly['cGerenciaJR'] = df_monthly['cGerenciaSR']
            df_monthly['date_valid'] = df_monthly.dFechaEntregaOperacion.combine_first(df_monthly.dEntregaPosicion)
            df_monthly['first_day_month'] = pd.to_datetime(((df_monthly['nWeek'].astype(int)*100) + 1), format='%Y%m%d')
            df_monthly['date_dif'] = df_monthly['first_day_month'] - pd.to_datetime(df_monthly['date_valid'])
            df_monthly['days_tenure'] = df_monthly['date_dif'].dt.days
            df_monthly['cTenure'] = np.where(df_monthly.days_tenure < 0, 'NA',np.where(df_monthly.days_tenure <= 45, '1M',np.where(df_monthly.days_tenure <= 75, '2M','3M')))
            monthly_red = df_monthly[['cATTUID','cUsuarioUnico','nSuccesFactors','cLoginPTN','cLogin','nLoginAvaya','cUsuarioPVS','cUsuarioCCI','cUsuarioCRM','cEstatusCRM','cUsuarioWebBo','nIex_Id','cMU','cIdCMS','nExtensionVirtual','cUsuarioChat','cUsuarioPolo','cUsuarioWFO','cLicenciaRemedy','cLicenciaSmartchat','cNombre','cPaterno','cMaterno','cNombreCompleto','cPuesto','cSexo','dFechaIngreso','cNomina','cMarca','cDescanso','tEntrada','tSalida','nJornada','cTurno','cAreaOperativa','cColor','cAplicativo','cTipoCanal','cNombreSkill','cVP','cAVP','cDireccion','cDirector','cGerenciaSR','cGerente','cSupervisor','cClasificacion','cSite','cProveedor','cAgrupacion','cComentarios','cSupervisorACE','cPuestoSimplificado','cClasificacionSimplificada','dFechaEntregaOperacion','cCapacitadorAula','cAnalistaCalidad','cCoordinadorAttendance','cLunes','cMartes','cMiercoles','cJueves','cViernes','cSabado','cDomingo','cAntiguedad','cCampII','cEsquemaComision','dEntregaPosicion','cPostIdPDV','nAccesoPeatonal','cVPN','cHomeOffice','cEquipoComputo','cVideoCamara','cSilla','nWeek','cYearWeek','nMonth','nIdPlantilla','cAreaPlantilla','nIdOperativa','cCalidadLlamadas','cPVSAnterior','cEncuestable','nWorkdays','nHoursPerweek','cEmployment','nLoginUnificado','cTenure','cGerenciaJR','cGerente1','cAPC_ID','cBlackout','cAttuid_jefe_inmediato','nEmp_jefe_inmediato','cJefe_inmediato','cExclusiones','cMotivos_Excepciones_Calidad','cUsuarioWebBo2','cExcepcionCallID']].copy()
            monthly_blue = df_monthly[['cATTUID','cUsuarioUnico','nSuccesFactors','cLoginPTN','nLoginAvaya','cUsuarioPVS','cUsuarioCCI','cUsuarioCRM','cEstatusCRM','cUsuarioWebBo','nIex_Id','cMU','cIdCMS','nExtensionVirtual','cUsuarioChat','cUsuarioPolo','cUsuarioWFO','cLicenciaRemedy','cLicenciaSmartchat','cNombre','cPaterno','cMaterno','cNombreCompleto','cPuesto','dFechaIngreso','cNomina','cMarca','cDescanso','tEntrada','tSalida','nJornada','cTurno','cAreaOperativa','cColor','cAplicativo','cTipoCanal','cNombreSkill','cVP','cAVP','cDireccion','cDirector','cGerenciaSR','cGerente','cSupervisor','cClasificacion','cSite','cProveedor','cAgrupacion','cComentarios','cSupervisorACE','cPuestoSimplificado','cClasificacionSimplificada','dFechaEntregaOperacion','cCapacitadorAula','cAnalistaCalidad','cLunes','cMartes','cMiercoles','cJueves','cViernes','cSabado','cDomingo','cAntiguedad','cCampII','cEsquemaComision','dEntregaPosicion','cPostIdPDV','nAccesoPeatonal','cVPN','cHomeOffice','cEquipoComputo','cVideoCamara','cSilla','nWeek','cTenure','cGerenciaJR','cBlackout','cAttuid_jefe_inmediato','nEmp_jefe_inmediato','cJefe_inmediato','cExclusiones','cMotivos_Excepciones_Calidad','cUsuarioWebBo2','cExcepcionCallID']].copy()
            monthly_blue.columns = ['attuid','user_only','succes_factors','login_ptn','login_avaya','user_pvs','user_cci','user_crm','status_crm','user_webbo','iex_id','mu','id_cms','extension_virtual','user_chat','user_polo','user_wfo','license_remedy','license_smartchat','name','paternal','maternal','complete_name','position','date_income','payroll','mark','rest','entrance','exit','working_day','inning','operational_area','color','applicative','type_channel','name_skill','vp','avp','address','director','management_sr','manager','supervisor','classification','site','provider','group','comments','supervisor_ace','position_simplified','classification_simplified','date_delivery_operation','trainer_classroom','analyst_quality','monday','tuesday','wednesday','thursday','friday','saturday','sunday','antiquity','campii','commission_scheme','position_delivery','post_id_pdv','pedestrian_access','vpn','home_office','computer_equipment','video_camera','chair','year_month','tenure','jr_management','blackout','immediate_boss_attuid','emp_immediate_boss','immediate_boss','exclusions','reasons_exceptions_quality','web_user_bo2','call_id_exception']
            self.trns += 1
            return monthly_red, monthly_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on df_hc: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on df_hc')
    #5.Limpia SQL
    def clean_sql(self, conn, cursor, week, table):
        try:
            if table == 'tbl_hc_weekly': campo = 'year_week'
            elif table == 'tbl_hc_monthly': campo = 'year_month'
            else: campo = 'nWeek'
            qry_clean = "DELETE FROM hc." + table + " WHERE " + campo + " = " + str(week)
            cursor.execute(qry_clean)
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpieza completada para hc.' + table)
            self.trns += 1
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on clean_sql: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on clean_sql')
    #6.Load SQL
    def load_to_sql(self, engine, conn, df_load, table):
        try:
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            df_load.to_sql(table, engine, index=False, if_exists="append", schema="hc")
            conn.commit()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga hc.' + table + ' completada') 
            self.trns += 1
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on load_to_sql: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on load_to_sql')
    #7.Move file
    def move_file(self):
        try:
            for file in os.listdir(path_insumo):
                if file.endswith('.xlsx') and file.startswith('HC AT&T'):
                    insumo = path_insumo + file
                    os.replace(insumo, path_insumo + 'Loaded/' + file.replace('.xlsx','_') + file_date + '.xlsx')
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': HC movido al historico') 
            self.trns += 1
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on move_file: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on move_file')
    #11.Proceso completo
    def load(self, proc):
        try:
            engine, conn, cursor = hc_weekly.conn_red(self)
            engine_blue, conn_blue, cursor_blue = hc_weekly.conn_blue(self)
            excel_file = hc_weekly.read_file(self)
            print(excel_file)
            df, col_names, max_week = hc_weekly.file_val(self, excel_file)
            list_weeks, mes_replica = hc_weekly.df_week(self, engine, max_week)
            for week, first_day in list_weeks:
                df_red, df_blue = hc_weekly.df_hc(self, df, col_names, week, first_day)
                #Rojo
                #df_red.to_sql('tmp_Acumulado_os',engine, index = False, if_exists = 'replace', chunksize=10000, schema='hc')
                hc_weekly.clean_sql(self, conn, cursor, week, 'tbl_Acumulado')
                hc_weekly.load_to_sql(self, engine, conn, df_red, 'tbl_Acumulado')
                #Azul
                hc_weekly.clean_sql(self, conn_blue, cursor_blue, week,'tbl_hc_weekly')
                hc_weekly.load_to_sql(self, engine_blue, conn_blue, df_blue,'tbl_hc_weekly')
            #Replicar hc_mensual
            monthly_red, monthly_blue = hc_weekly.df_monthly(self, df, mes_replica)
            hc_weekly.clean_sql(self, conn, cursor, mes_replica, 'tbl_HcMonthly')
            hc_weekly.load_to_sql(self, engine, conn, monthly_red,'tbl_HcMonthly')
            #Azul
            hc_weekly.clean_sql(self, conn_blue, cursor_blue, mes_replica, 'tbl_hc_monthly')
            hc_weekly.load_to_sql(self, engine_blue, conn_blue, monthly_blue,'tbl_hc_monthly')
            #Finalizar
            hc_weekly.move_file(self)            
        except Exception as error:
            status = 'NOK'
            msg_proc = 'Caught this error: ' + repr(error) if int(self.no_info) == 0 else 'SIN_INFO Caught this error: ' + repr(error)
            #mail.send_notification('Error Job', msg_proc, 'Load HC Weekly', str(today), self.trns, self.err, st_hostn, exec_path)
        else:
            status = 'OK'
            msg_proc =  'Nothing went wrong'
            #mail.send_notification('Confirmation Job', msg_proc, 'Load HC Weekly', str(today), self.trns, self.err, st_hostn, exec_path)
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            print(status, msg_proc)
            return status, msg_proc

def main():
    runObj = hc_weekly()
    run_process = str(Key)
    result = runObj.load(run_process)
main()
'''
'''