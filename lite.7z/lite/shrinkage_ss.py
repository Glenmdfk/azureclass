'''   ##########  Comienza importación de módulos ##########   '''
from datetime import date, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Módulos Generales
import pathlib, socket, os, sys, warnings,shutil
import pandas as pd
#SQL Alchemy
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.config as config
import Libraries.lib_mail as mail
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')
'''   ##########  Comienza definición de variables ##########   '''
Key = 'shrinkage_ss'
warnings.filterwarnings("ignore")
#Detalles de ejecución
path_file = pathlib.Path(__file__)
st_hostn = socket.gethostname()
exec_path = str(os.getcwd())
today = date.today()
run_date=dt.today().strftime("%Y%m%d")
hostname = str(socket.gethostname())
attuid=st_hostn[9:15]
old_local_backup = 'C:/Users/'+attuid+'/Downloads/Shrinkage_SS/'# + str(run_date) + '/'
carpet = os.path.exists(old_local_backup)
if not carpet:
    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')+': Creating path: ' + old_local_backup)
    os.mkdir(old_local_backup)
else:
    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')+': Path exists, continuing process')
local_backup = 'C:/Users/'+attuid+'/Downloads/Shrinkage_SS/' + str(run_date) + '/'
#local_backup = 'C:/Users/om988b/Downloads/Shrinkage_SS/' + str(run_date) + '/'
#Variables de directorio
path = pathlib.Path(__file__).parent.absolute()
path_insumo = '//135.208.36.233/wfm/Shrinkage/'
sheet_list = ['ATC_RSS','COB']

print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')

'''   ##########  Comineza ejecución del programa ##########   '''
class shrinkage_ss:
    #0.Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
        self.no_info = 0
    #1.Conexión a DataManagement
    def conn_red(self):
        try:
            server = config.DATAMANAGEMENT_CONFIG["Server"]
            conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_ChardDM_Connection()})
            engine = create_engine(conn_url)
            conn = engine.raw_connection()
            cursor = conn.cursor()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa DM Red Server')
            return engine, conn, cursor
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_red: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_red')
    #1.Conexión a OI Bue Server
    def conn_blue(self):
        try:
            conn_url, engine_blue, conn_blue, cursor_blue = dbConn.get_ETL_OIEngineBlue_Connection()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa OI Bue Server')
            return engine_blue, conn_blue, cursor_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_blue: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_blue')
    #2.Read File Shrinkage
    def read_file(self,local_path):
        try:
            count_fie = 0
            list_files = []
            for file in os.listdir(path_insumo):
                if file.endswith('.xlsx') and file.startswith('STAR'):
                    insumo = path_insumo + file
                    list_files.append(insumo)
                    count_fie += 1
            for i in list_files:
                is_exist = os.path.exists(local_path)
                if not is_exist:
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')+': Creating path: ' + local_path)
                    os.mkdir(local_path)
                else:
                    print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')+': Path exists')                                
                shutil.copy2(i, local_path)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S')+': file copied from : '+ str(path_insumo) + ' to ' + str(local_path))                         
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lectura de archivos completada')
            return list_files, count_fie
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on read_file: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on read_file')
    #3.Time function
    def function_time(datetime):
        if datetime == None or datetime == '--:--':
            ok_time = None
        else:
            #ok_time = pd.to_datetime(datetime, format="%H:%M:%S")
            ok_time = dt.strptime(str(datetime), "%H:%M:%S").time()
        return ok_time
    #4.DataFrame SS
    def df_ss(self, file, sheet):
        try:
            cols = ['dDate','detail','nID','cName','vacio','tScheduleStart','tScheduleEnd','tScheduleLength','tBreak1Start','tBreak1End','Break1Length','tLunchStart','tLunchEnd','LunchLength','tBreak2Start','tBreak2End','tBreak2Length']
            df = pd.read_excel(file, sheet_name=sheet, usecols='A:Q', names=cols, header=0)
            min_date = min(df['dDate'])
            max_date = max(df['dDate'])
            df['nSecondON'] = 0
            df_work = df[['dDate','nID','cName','tScheduleStart','tScheduleEnd','tScheduleLength','nSecondON','tBreak1Start','tBreak1End','tBreak2Start','tBreak2End','tLunchStart','tLunchEnd']][df['tScheduleStart'] != '--:--']
            df_work['dDate'] = df_work['dDate'].astype(str)
            df_work['cName'] = df_work['cName'].replace(to_replace=r'[.,\/"…]', value='',regex=True)
            df_work['tScheduleStart'] = df_work['tScheduleStart'].apply(shrinkage_ss.function_time)
            df_work['tScheduleEnd'] = df_work['tScheduleEnd'].apply(shrinkage_ss.function_time)
            df_work['tScheduleLength'] = pd.to_datetime(df_work['tScheduleLength'], format="%H:%M:%S")
            #df_work['tScheduleLength'] = df_work['tScheduleLength'].apply(shrinkage_ss.function_time)
            df_work['nSecondON'] = df_work['tScheduleLength'].dt.second + (df_work['tScheduleLength'].dt.minute*60) + (df_work['tScheduleLength'].dt.hour*3600)
            df_work['tBreak1Start'] = df_work['tBreak1Start'].apply(shrinkage_ss.function_time)
            df_work['tBreak1End'] = df_work['tBreak1End'].apply(shrinkage_ss.function_time)
            df_work['tBreak2Start'] = df_work['tBreak2Start'].apply(shrinkage_ss.function_time)
            df_work['tBreak2End'] = df_work['tBreak2End'].apply(shrinkage_ss.function_time)
            df_work['tLunchStart'] = df_work['tLunchStart'].apply(shrinkage_ss.function_time)
            df_work['tLunchEnd'] = df_work['tLunchEnd'].apply(shrinkage_ss.function_time)
            df_work['cCampaign'] = sheet
            df_red = df_work[['dDate','nID','cName','tScheduleStart','tScheduleEnd','nSecondON','tBreak1Start','tBreak1End','tBreak2Start','tBreak2End','tLunchStart','tLunchEnd','cCampaign']]
            df_blue = df_work[['dDate','nID','cName','tScheduleStart','tScheduleEnd','nSecondON','tBreak1Start','tBreak1End','tBreak2Start','tBreak2End','tLunchStart','tLunchEnd','cCampaign']]
            df_blue.columns = ['date','id','name','schedule_start','schedule_end','second_on','break1_start','break1_end','break2_start','break2_end','lunch_start','lunch_end','campaign']
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': DataFrame ' + sheet + ' Listo para carga')
            return df_red, df_blue, min_date, max_date
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on df_ss: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on df_ss')
    #5.Limpia SQL
    def clean_sql(self, conn, cursor, sheet, min_date, max_date, table):
        try:
            if table == 'tbl_start_stop_acum':
                campana = 'campaign'
                fecha = 'date'
            else:
                campana = 'cCampaign'
                fecha = 'dDate'
            qry_clean = """DELETE FROM iex.""" + table + """
                WHERE """ + campana+ """ = '""" + sheet + """'
                AND """ + fecha + """ BETWEEN '""" + str(min_date) + """' AND ' """ + str(max_date) + """';"""
            cursor.execute(qry_clean)
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpieza ' + sheet + ' completada para ss')
            self.trns += 1
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on clean_sql: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on clean_sql')
    #6. Load SQL
    def load_to_sql(self, engine, conn, df_to_load, sheet, table):
        try:
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            df_to_load.to_sql(table, engine, index=False, if_exists="append", schema="iex")
            conn.commit()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga ss ' + sheet + ' completada') 
            self.trns += 1
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on load_to_sql: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on load_to_sql')
    #11.Proceso completo
    def load(self, proc):
        try:
            engine, conn, cursor = shrinkage_ss.conn_red(self)
            engine_blue, conn_blue, cursor_blue = shrinkage_ss.conn_blue(self)
            table_red = 'tbl_StartStopAcum'
            table_blue = 'tbl_start_stop_acum'
            list_files, count_fie = shrinkage_ss.read_file(self,local_backup)
            if count_fie == 0:
                self.no_info += 1
                raise ValueError('SIN INFO')
            else:
                for file in list_files:
                    for sheet in sheet_list:
                        df_red, df_blue, min_date, max_date = shrinkage_ss.df_ss(self, file, sheet)
                        #red
                        print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Proceso servidor rojo')
                        shrinkage_ss.clean_sql(self, conn, cursor, sheet, min_date, max_date, table_red)
                        shrinkage_ss.load_to_sql(self, engine, conn, df_red, sheet, table_red)
                        #blue
                        print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Proceso servidor azul')
                        shrinkage_ss.clean_sql(self, conn_blue, cursor_blue, sheet, min_date, max_date, table_blue)
                        shrinkage_ss.load_to_sql(self, engine_blue, conn_blue, df_blue, sheet, table_blue)
        except Exception as error:
            status = 'NOK'
            msg_proc = 'Caught this error: ' + repr(error) if int(self.no_info) == 0 else 'SIN_INFO Caught this error: ' + repr(error)
            mail.send_notification('Error Job', msg_proc, 'Shrinkage SS', str(today), self.trns, self.err, st_hostn, exec_path)
        else:
            status = 'OK'
            msg_proc =  'Nothing went wrong'
            mail.send_notification('Confirmation Job', msg_proc, 'Shrinkage SS', str(today), self.trns, self.err, st_hostn, exec_path)
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            print(status, msg_proc)
            return status, msg_proc


'''
def main():
    runObj = shrinkage_ss()
    run_process = str(Key)
    result = runObj.load(run_process)
main()
'''