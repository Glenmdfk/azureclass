import  smtplib
import time
import win32com.client as win32
import os, sys
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import yaml
from yaml.loader import SafeLoader
import json
import re
import glob
from datetime import date, datetime as dt
import datetime 

data_yml = []
data_json = []
to_list = []
cc_list = []
bcc_list = []

def load_yaml():
    # Open the file and load the file
    with open('C:\App\Variables\Domain.yml') as f:
        yml = yaml.load(f, Loader=SafeLoader)

    return yml

def load_json(path):
    # Opening JSON file
    f = open(path,'r')
    
    # returns JSON object as
    # a dictionary
    data_json = json.load(f)
    
    # list
    for i in data_json['Distribution_List']['To']['to_distro']:
        to_list.append(data_json['Distribution_List']['To']['to_distro'][i])

    for i in data_json['Distribution_List']['CC']['cc_distro']:
        cc_list.append(data_json['Distribution_List']['CC']['cc_distro'][i])

    for i in data_json['Distribution_List']['BCC']['bcc_distro']:
        bcc_list.append(data_json['Distribution_List']['BCC']['bcc_distro'][i])
    
    # Closing file
    f.close()

    separator = '; '
    receiver = separator.join(to_list)
    cc = separator.join(cc_list)
    bcc = separator.join(bcc_list)
    subject = data_json['Asunto']
    body = data_json['SaludoHTML'] + data_json['CuerpoHTML'] + data_json['FirmaHTML']
    attach = data_json['Attach']
    process = data_json['job_name_distro']

    return receiver, cc, bcc, subject, body, attach, process

def smtp_distro(smpt_path, proc = 'wo_proc'):

    data_yml = load_yaml()

    sender_email = "rm-mx.atc.operative.intelligence@mx.att.com"

    receiver_email, cc_email, bcc_email, asunto, cuerpo, adjunto, proceso = load_json(smpt_path)

    if proc != 'wo_proc' and proc != proceso:
        print(proc, proceso, 'process called and distribution list doesn\'t match')
        raise ValueError('Unable to send mail the process called and distribution list doesn\'t match')
    else:
        message = MIMEMultipart("alternative")
        message["Subject"] = asunto
        message["From"] = sender_email
        message["To"] = receiver_email
        message["CC"] = cc_email
        message["BCC"] = bcc_email

        # Create the plain-text and HTML version of your message
        text = """\
        Por favor ver adjunto"""
        html = """\
        <html>
        <body>""" + cuerpo + """
        </body>
        </html>
        """


        # Turn these into plain/html MIMEText objects
        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")

        filename = adjunto
        namefile = filename.split("\\")
        file_pos = len(namefile)
        final_file = []
        final_file.append(namefile[file_pos - 1])

        if len(adjunto) > 0:
            # Open PDF file in binary mode
            with open(filename, "rb") as attachment:
                # Add file as application/octet-stream
                # Email client can usually download this automatically as attachment
                part = MIMEBase("application", "octet-stream")
                part.set_payload(attachment.read())

            # Encode file in ASCII characters to send by email    
            encoders.encode_base64(part)

            # Add header as key/value pair to attachment part
            part.add_header(
                "Content-Disposition",
                f"attachment; filename= {namefile[file_pos - 1]}",
            )

            # Add attachment to message and convert message to string
            message.attach(part)

            # Add HTML/plain-text parts to MIMEMultipart message
            # The email client will try to render the last part first
            message.attach(part1)
            message.attach(part2)
            #message.attach(data_json['Attach'])
        
        #"""
        server = smtplib.SMTP('135.208.33.18', 587)
        server.starttls()
        server.login(data_yml['USDomain'], data_yml['PSDomain'])
        server.sendmail(
        sender_email, 
        receiver_email, 
        message.as_string())
        server.quit()
        #"""

        time.sleep(5)

def win32_distro(win32_path, proc = 'wo_proc'):
    sender_email = "rm-mx.atc.operative.intelligence@mx.att.com"

    receiver_email, cc_email, bcc_email, asunto, cuerpo, adjunto, proceso = load_json(win32_path)

    if proc != 'wo_proc' and proc != proceso:
        print(proc, proceso, 'process called and distribution list doesn\'t match')
        raise ValueError('Unable to send mail the process called and distribution list doesn\'t match')
    else:
        olApp = win32.Dispatch('Outlook.Application')
        olNS = olApp.GetNameSpace('MAPI')

        mailItem = olApp.CreateItem(0)
        mailItem.Subject = asunto
        mailItem.BodyFormat = 2 #1 texto plano, 2 html
        mailItem.HTMLBody = cuerpo
        mailItem.To = receiver_email
        mailItem.Cc = cc_email
        mailItem.Bcc = bcc_email
        mailItem.SentOnBehalfOfName = sender_email
        mailItem.Attachments.Add(Source=adjunto)
        mailItem.Send()    

def send_distro(distro_path, proc = 'wo_proc'):
    try:
        smtp_distro(distro_path,proc)
    except Exception as error:
        print('SMTP send mail fail => Caught this error: ' + repr(error))
        try:
            win32_distro(distro_path,proc)
        except Exception as error:
            raise ValueError('Unable to send mail => Caught this error: ' + repr(error))

def smtp_notification(nType, proc_result, internal_name, dDate, NR, ERR, hostname, cur_dir, mail_de = 0):
    
    today = date.today()

    data_yml = load_yaml()

    sender_email = "rm-mx.atc.operative.intelligence@mx.att.com"
    if mail_de == 1:
        receiver_email = "cn6253@mx.att.com; om988b@mx.att.com; gg421b@mx.att.com; jr0407@mx.att.com;"
        cc_email = "jj0669@mx.att.com"
    else:
        receiver_email = "mx.atcoperativeintelligenc@mx.att.com"
        cc_email = "jj0669@mx.att.com"

    ResultMail = proc_result
    mail_date = dDate

    if nType == 'Error Job' and ResultMail[:8] == 'SIN_INFO':
        nType = 'SIN INFO'
        Leyenda = 'No se cuenta con insumo para la ejecución del job:'
        Formato = '<b style="color:#FB1F6E">'
    else:
        if nType == 'Error Job' and ResultMail[:8] != 'SIN_INFO':
            Leyenda = 'Se produjo un error durante la ejecución del Job:'
            Formato = '<b style="color:#FB1F6E">'
        else:
            Leyenda = 'Confirmación de ejecución para el job:'
            Formato = '<b style="color:black;">'

    path_name = '//135.208.36.251/migracion_io/IO/DEVELOPMENT/Logs/' + str(internal_name) + '/'
    #print(path_name)
    
    isExist = os.path.exists(path_name)

    if not isExist:
        #print('not isExist')
        text_body = '<br>'
    else:
        #print('isExist')
        list_of_files = glob.glob(path_name + '*.log')
        latest_file = max(list_of_files, key=os.path.getctime)
        #print(str(latest_file))

        m_time = os.path.getmtime(latest_file)
        #print(m_time)
        dt_m = datetime.datetime.fromtimestamp(m_time)
        #print(dt_m)
        #print(today)
        #print(dt_m.date())

        if  dt_m.date() == today:
            #print('log')
            f = open(latest_file, "r")
            text_file = f.read()
            text_file_rn = re.sub("\r\n","<br>",text_file)
            text_file_r = re.sub("\r","<br>",text_file_rn)
            text_file_n = re.sub("\n","<br>",text_file_r)
            text_body = text_file_n + '<br>'
        else:
            #print('wo_log')
            text_body = '<br>'


    html = '''
            <html><head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <style type="text/css">p {font-size: 11pt; font-family: 'calibri'}</style>
            </head>
            <body>
                ''' + Formato + Leyenda + '''</b><br>
                <p>''' + ResultMail + '''</p><br>
                <ul>
                    <li><b>JOB:</b> ''' + str(internal_name) + '''</li>
                    <li><b>DATE:</b> ''' + str(dDate) + '''</li>
                    <li><b>TRNS:</b>  ''' + str(NR) + '''</li>
                    <li><b>HOSTNAME:</b> ''' + str(hostname) + '''</li>
                    <li><b>ERROR:</b>  ''' + str(ERR) + '''</li>
                    <li><b>JOB SCRIPTS:</b>  ''' + str(cur_dir) + '''</li>
                </ul>
                ''' + text_body + '''

                <span style=\"font-size:10.5pt;font-family:&quot;Segoe UI&quot;,sans-serif; color:black\">
                <b>Operational Intelligence</b>
                </span>
                <br>
                <span style=\"font-size:10.0pt;font-family:&quot;Segoe UI&quot;,sans-serif;color:#242424\">
                Atencion a Clientes y Empresas<br>
                Transformacion Atencion al Cliente
                </span>
                <br><b>
                <span style=\"color:#FB1F6E;\">
                #CambiaElJuego
                </span>
                </b>
                <b><span style=\"color:#BF0CEA;font-size:48pt;\">&middot;</span>
                <p>
                <b style="color:#00B0F0">AT&T México</b><br>
                Blvd Manuel  Ávila Camacho 5 Lomas de Sotelo, Naucalpan de Juárez, Estado de México, CP 53390<br><br>
                El uso o divulgación fuera de las empresas AT&T está prohibido, excepto mediante acuerdo escrito.
                Este mensaje y cualesquiera archivos adjuntos contienen información confidencial de la empresa dirigidos exclusivamente para los destinatarios.
                Si usted ha recibido este mensaje por error, favor de no reenviar o distribuir a cualquier otra persona
                , pero favor de llamar al teléfono [55.8184.5854]  para reportar el error y posteriormente le pedimos borrar este mensaje de su sistema
                </p>
            </body>
            </html>
            '''
    asunto = 'IO | ' + nType + ' | ' + internal_name + ' | ' + mail_date

    message = MIMEMultipart("alternative")
    message["Subject"] = asunto
    message["From"] = sender_email
    message["To"] = receiver_email
    message["CC"] = cc_email

    # Create the plain-text and HTML version of your message
    text = """\
    Por favor ver adjunto"""

    # Turn these into plain/html MIMEText objects
    part1 = MIMEText(text, "plain")
    part2 = MIMEText(html, "html")
    message.attach(part2)

    #"""
    server = smtplib.SMTP('135.208.33.18', 587)
    server.starttls()
    server.login(data_yml['USDomain'], data_yml['PSDomain'])
    server.sendmail(
    sender_email, 
    receiver_email, 
    message.as_string())
    server.quit()
    #"""

    time.sleep(5)    
    pass

def win32_notification(nType, proc_result, internal_name, dDate, NR, ERR, hostname, cur_dir, mail_de = 0):
    #Config Mail
    olApp = win32.Dispatch('Outlook.Application')
    olNS = olApp.GetNameSpace('MAPI')
    #Var date
    today = date.today()
    #mail_date = dt.strftime(today, '%Y-%m-%d')
    #Var HTML
    sender_email = "rm-mx.atc.operative.intelligence@mx.att.com"
    if mail_de == 1:
        receiver_email = "cn6253@mx.att.com; om988b@mx.att.com; gg421b@mx.att.com; jr0407@mx.att.com;"
        cc_email = "os940m@mx.att.com"
    else:
        receiver_email = "mx.atcoperativeintelligenc@mx.att.com"
        cc_email = "jj0669@mx.att.com; os940m@mx.att.com"

    ResultMail = proc_result
    #Body Mail
    if nType == 'Error Job' and ResultMail[:8] == 'SIN_INFO':
        nType = 'Error Job'
        Leyenda = 'No se cuenta con insumo para la ejecución del job:'
        Formato = '<b style="color:#FB1F6E">'
    else:
        if nType == 'Error Job' and ResultMail[:8] != 'SIN_INFO':
            Leyenda = 'Se produjo un error durante la ejecución del Job:'
            Formato = '<b style="color:#FB1F6E">'
        else:
            Leyenda = 'Confirmación de ejecución para el job:'
            Formato = '<b style="color:black;">'
    mailItem = olApp.CreateItem(0)

    path_name = '//135.208.36.251/migracion_io/IO/DEVELOPMENT/Logs/' + str(internal_name) + '/'
    print(path_name)
    
    isExist = os.path.exists(path_name)

    if not isExist:
        print('not isExist')
        text_body = '<br>'
    else:
        print('isExist')
        list_of_files = glob.glob(path_name + '*.log')
        latest_file = max(list_of_files, key=os.path.getctime)
        print(str(latest_file))

        m_time = os.path.getmtime(latest_file)
        #print(m_time)
        dt_m = datetime.datetime.fromtimestamp(m_time)
        #print(dt_m)
        #print(today)
        #print(dt_m.date())

        if  dt_m.date() == today:
            #print('log')
            f = open(latest_file, "r")
            text_file = f.read()
            text_file_rn = re.sub("\r\n","<br>",text_file)
            text_file_r = re.sub("\r","<br>",text_file_rn)
            text_file_n = re.sub("\n","<br>",text_file_r)
            text_body = text_file_n + '<br>'
        else:
            #print('wo_log')
            text_body = '<br>'

    body = '''
            <html><head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <style type="text/css">p {font-size: 11pt; font-family: 'calibri'}</style>
            </head>
            <body>
                ''' + Formato + Leyenda + '''</b><br>
                <p>''' + ResultMail + '''</p><br>
                <ul>
                    <li><b>JOB:</b> ''' + internal_name + '''<\li>
                    <li><b>DATE:</b> ''' + dDate + '''<\li>
                    <li><b>TRNS:</b>  ''' + NR + '''<\li>
                    <li><b>HOSTNAME:</b> ''' + hostname + '''<\li>
                    <li><b>ERROR:</b>  ''' + ERR + '''<\li>
                    <li><b>JOB SCRIPTS:</b>  ''' + cur_dir + '''<\li>
                </ul>
                ''' + text_body + '''

                <span style=\"font-size:10.5pt;font-family:&quot;Segoe UI&quot;,sans-serif; color:black\">
                <b>Operational Intelligence</b>
                </span>
                <br>
                <span style=\"font-size:10.0pt;font-family:&quot;Segoe UI&quot;,sans-serif;color:#242424\">
                Atencion a Clientes y Empresas<br>
                Transformacion Atencion al Cliente
                </span>
                <br><b>
                <span style=\"color:#FB1F6E;\">
                #CambiaElJuego
                </span>
                </b>
                <b><span style=\"color:#BF0CEA;font-size:48pt;\">&middot;</span>
                <p>
                <b style="color:#00B0F0">AT&T México</b><br>
                Blvd Manuel  Ávila Camacho 5 Lomas de Sotelo, Naucalpan de Juárez, Estado de México, CP 53390<br><br>
                El uso o divulgación fuera de las empresas AT&T está prohibido, excepto mediante acuerdo escrito.
                Este mensaje y cualesquiera archivos adjuntos contienen información confidencial de la empresa dirigidos exclusivamente para los destinatarios.
                Si usted ha recibido este mensaje por error, favor de no reenviar o distribuir a cualquier otra persona
                , pero favor de llamar al teléfono [55.8184.5854]  para reportar el error y posteriormente le pedimos borrar este mensaje de su sistema
                </p>
            </body>
            </html>
            '''
    asunto = 'IO | ' + nType + ' | ' + internal_name + ' | ' + dDate

    #Parametros de construcción mail
    mailItem.Subject = asunto
    mailItem.BodyFormat = 2 #1 texto plano, 2 html
    mailItem.HTMLBody = body
    mailItem.To = receiver_email
    mailItem.Cc = cc_email
    mailItem.SentOnBehalfOfName = sender_email
    mailItem.Send()

def send_notification(nType, proc_result, internal_name, dDate, NR, ERR, hostname, cur_dir, mail_de = 0):
    try:
        smtp_notification(nType, proc_result, internal_name, dDate, NR, ERR, hostname, cur_dir, mail_de = 0)
    except Exception as error:
        print('SMTP send mail fail => Caught this error: ' + repr(error))
        try:
            win32_notification(nType, proc_result, internal_name, dDate, NR, ERR, hostname, cur_dir, mail_de = 0)
        except Exception as error:
            raise ValueError('Unable to send mail => Caught this error: ' + repr(error))
        finally:
            print('Mail send via Win32')    
    finally:
        print('Mail send via smtp')
#send_distro('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots/Libraries/Distro.json','halog')
#send_notification('Confirmation Job','Nothing went Wrong','test_proc','2022-10-20',5,0,'TR15AC01LOS940M',os.getcwd())

#om988b

def smtp_distro_file(smpt_path,file_path, proc = 'wo_proc'):
    
    data_yml = load_yaml()
    
    sender_email = "rm-mx.atc.operative.intelligence@mx.att.com"
    
    receiver_email, cc_email, bcc_email, asunto, cuerpo, adjunto, proceso = load_json(smpt_path)
    #print(receiver_email)
    
    if proc != 'wo_proc' and proc != proceso:
        
        print(proc, proceso, 'process called and distribution list doesn\'t match')
        raise ValueError('Unable to send mail the process called and distribution list doesn\'t match')
    else:
        lista = []
        f = open(smpt_path,'r')
        data_json = json.load(f)
        for i in data_json['Distribution_List']['To']['to_distro']:
            lista.append(data_json['Distribution_List']['To']['to_distro'][i]) 
        message = MIMEMultipart("alternative")
        Date = date.today()
        asunto = asunto + str(Date)
        message["Subject"] = asunto
        message["From"] = sender_email
        #receiver_email_list = ['gg421b@mx.att.com','om988b@mx.att.com','pb217j@mx.att.com','cn6253@mx.att.com']
        receiver_email_list = lista
        message["To"] = receiver_email
        message["CC"] = cc_email
        message["BCC"] = bcc_email

        # Create the plain-text and HTML version of your message
        text = """\
        Por favor ver adjunto"""
        html = """\
        <html>
        <body>""" + cuerpo + """
        </body>
        </html>
        """


        # Turn these into plain/html MIMEText objects
        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")

        filename = file_path
        namefile = filename.split("\\")
        file_pos = len(namefile)
        final_file = []
        final_file.append(namefile[file_pos - 1])

        if len(file_path) > 0:
            # Open PDF file in binary mode
            with open(filename, "rb") as attachment:
                # Add file as application/octet-stream
                # Email client can usually download this automatically as attachment
                part = MIMEBase("application", "octet-stream")
                part.set_payload(attachment.read())

            # Encode file in ASCII characters to send by email    
            encoders.encode_base64(part)

            # Add header as key/value pair to attachment part
            part.add_header(
                "Content-Disposition",
                f"attachment; filename= {namefile[file_pos - 1]}",
            )

            # Add attachment to message and convert message to string
            message.attach(part)

            # Add HTML/plain-text parts to MIMEMultipart message
            # The email client will try to render the last part first
            message.attach(part1)
            message.attach(part2)
            #message.attach(data_json['Attach'])
        
        #"""
        server = smtplib.SMTP('135.208.33.18', 587)
        server.starttls()
        server.login(data_yml['USDomain'], data_yml['PSDomain'])
        server.sendmail(
        sender_email, 
        receiver_email_list, 
        message.as_string())
        server.quit()
        #"""

        
        time.sleep(5)

def win32_distro_file(win32_path,file_path, proc = 'wo_proc'):
    sender_email = "rm-mx.atc.operative.intelligence@mx.att.com"

    receiver_email, cc_email, bcc_email, asunto, cuerpo, adjunto, proceso = load_json(win32_path)


    if proc != 'wo_proc' and proc != proceso:
        print(proc, proceso, 'process called and distribution list doesn\'t match')
        raise ValueError('Unable to send mail the process called and distribution list doesn\'t match')
    else:
        olApp = win32.Dispatch('Outlook.Application')
        olNS = olApp.GetNameSpace('MAPI')

        mailItem = olApp.CreateItem(0)
        mailItem.Subject = asunto
        mailItem.BodyFormat = 2 #1 texto plano, 2 html
        mailItem.HTMLBody = cuerpo
        mailItem.To = receiver_email
        mailItem.Cc = cc_email
        mailItem.Bcc = bcc_email
        mailItem.SentOnBehalfOfName = sender_email
        mailItem.Attachments.Add(Source=file_path)
        mailItem.Send()    

def send_distro_file(distro_path, file_path ,proc = 'wo_proc' ):
    try:
        
        smtp_distro_file(distro_path,file_path,proc)
    except Exception as error:
        print('SMTP send mail fail => Caught this error: ' + repr(error))
        try:
            win32_distro_file(distro_path,file_path,proc)
        except Exception as error:
            raise ValueError('Unable to send mail => Caught this error: ' + repr(error))

#Proceso de envio Telesales

def smtp_distro_Telesales(smpt_path, proc = 'wo_proc'):
    
    data_yml = load_yaml()
    
    sender_email = "rm-mx.atc.operative.intelligence@mx.att.com"
    
    receiver_email, cc_email, bcc_email, asunto, cuerpo, adjunto, proceso = load_json(smpt_path)
    #print(receiver_email)
    
    if proc != 'wo_proc' and proc != proceso:
        
        print(proc, proceso, 'process called and distribution list doesn\'t match')
        raise ValueError('Unable to send mail the process called and distribution list doesn\'t match')
    else:
        lista = []
        f = open(smpt_path,'r')
        data_json = json.load(f)
        for i in data_json['Distribution_List']['To']['to_distro']:
            lista.append(data_json['Distribution_List']['To']['to_distro'][i]) 
        message = MIMEMultipart("alternative")
        Date = date.today()
        asunto = asunto + str(Date)
        message["Subject"] = asunto
        message["From"] = sender_email
        #receiver_email_list = ['gg421b@mx.att.com','om988b@mx.att.com','pb217j@mx.att.com','cn6253@mx.att.com']
        receiver_email_list = lista
        message["To"] = receiver_email
        message["CC"] = cc_email
        message["BCC"] = bcc_email

        # Create the plain-text and HTML version of your message
        text = """\
        Por favor ver adjunto"""
        html = """\
        <html>
        <body>""" + cuerpo + """
        </body>
        </html>
        """


        # Turn these into plain/html MIMEText objects
        part1 = MIMEText(text, "plain")
        part2 = MIMEText(html, "html")
        
        message.attach(part1)
        message.attach(part2)
        
        #"""
        server = smtplib.SMTP('135.208.33.18', 587)
        server.starttls()
        server.login(data_yml['USDomain'], data_yml['PSDomain'])
        server.sendmail(
        sender_email, 
        receiver_email_list, 
        message.as_string())
        server.quit()
        #"""

        
        time.sleep(5)

def win32_distro_Telesales(win32_path,file_path, proc = 'wo_proc'):
    sender_email = "rm-mx.atc.operative.intelligence@mx.att.com"

    receiver_email, cc_email, bcc_email, asunto, cuerpo, adjunto, proceso = load_json(win32_path)


    if proc != 'wo_proc' and proc != proceso:
        print(proc, proceso, 'process called and distribution list doesn\'t match')
        raise ValueError('Unable to send mail the process called and distribution list doesn\'t match')
    else:
        olApp = win32.Dispatch('Outlook.Application')
        olNS = olApp.GetNameSpace('MAPI')

        mailItem = olApp.CreateItem(0)
        mailItem.Subject = asunto
        mailItem.BodyFormat = 2 #1 texto plano, 2 html
        mailItem.HTMLBody = cuerpo
        mailItem.To = receiver_email
        mailItem.Cc = cc_email
        mailItem.Bcc = bcc_email
        mailItem.SentOnBehalfOfName = sender_email
        mailItem.Attachments.Add(Source=file_path)
        mailItem.Send()    

def send_distro_Telesales(distro_path ,proc = 'wo_proc' ):
    try:
        
        smtp_distro_Telesales(distro_path,proc)
    except Exception as error:
        print('SMTP send mail fail => Caught this error: ' + repr(error))
        try:
            win32_distro_Telesales(distro_path,proc)
        except Exception as error:
            raise ValueError('Unable to send mail => Caught this error: ' + repr(error))

