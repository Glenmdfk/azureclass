import os
import re
import pandas as pd

def read_qry(str_path, doc = 0):
    txt_qry = ''
    if doc == 1:
        str_path = '//135.208.36.251/Op_Intelligence/DOCUMENTACION/BASE_DE_DATOS' + str_path

    valid_path = os.path.exists(str_path)
    if valid_path:
        try:
            fd = open(str_path,'r',encoding='utf-8')
            txt_qry = fd.read()
            fd.close()
        except Exception as error:
            raise ValueError('Unable to read ' + str(str_path) + ' => Caught this error: ' + repr(error))
    else:
        raise ValueError('Unable to read ' + str(str_path) + ' doesn\'t exists')
    
    return txt_qry

def assign_variables(txt, variable_name, variable_value, is_in = 0):

    #print(type(variable_value))

    #print(type(variable_value))
    
    if is_in == 1:
        in_values = []
        
        if type(variable_value) is pd.core.frame.DataFrame:
            raise ValueError('Unable assign variable type \'pandas.core.frame.DataFrame\' valid types (tuple, list, dict)')

        if type(variable_value) is tuple:
            for value in variable_value:
                if type(value) is str:
                    in_values.append('\'' + value + '\'')
                elif type(value) is int:
                    in_values.append(value)
                elif type(value) is float:
                    in_values.append(value)
                else:
                    raise ValueError('Unable assign variable ' +type(value)+ ' in tuple valid types (str, int, float)')
            
            in_str = ", ".join(in_values)
            sql_qry = re.sub('\<' + variable_name + '\>', in_str, txt)

        if type(variable_value) is list:
            for value in variable_value:
                if type(value) is str:
                    in_values.append('\'' + value + '\'')
                elif type(value) is int:
                    in_values.append(value)
                elif type(value) is float:
                    in_values.append(value)
                else:
                    raise ValueError('Unable assign variable ' +type(value)+ ' in list valid types (str, int, float)')
                
            in_str = ", ".join(in_values)
            sql_qry = re.sub('\<' + variable_name + '\>', in_str, txt)
        
        if type(variable_value) is dict:
            for value in variable_value:
                if type(variable_value[value]) is str:
                    in_values.append('\'' + variable_value[value] + '\'')
                elif type(variable_value[value]) is int:
                    in_values.append(variable_value[value])
                elif type(variable_value[value]) is float:
                    in_values.append(variable_value[value])
                else:
                    raise ValueError('Unable assign variable ' +type(variable_value[value])+ ' in dict valid types (str, int, float)')
                
            in_str = ", ".join(in_values)
            sql_qry = re.sub('\<' + variable_name + '\>', in_str, txt)

    else:

        if type(variable_value) is str:
            sql_qry = re.sub('\<' + variable_name + '\>', '\'' + variable_value + '\'', txt)

        if type(variable_value) is int:
            sql_qry = re.sub('\<' + variable_name + '\>', str(variable_value), txt)

        if type(variable_value) is float:
            sql_qry = re.sub('\<' + variable_name + '\>', str(variable_value), txt)

    return sql_qry

#qry_contratos = read_qry('//135.208.36.251/Op_Intelligence/MASTER_REPORTS/TELESALES/SALESCC/ETL/Insumos/sales_incentive_renovaciones.txt')
#qry_contratos = read_qry('/VERTICA/qry_detalle_contratos_blue.txt', 1)
#cuentas = ("1345678","3456789","34567890")
#sql_contratos = assign_variables(qry_contratos, 'NUM_CUENTA', cuentas, 1)
#print(sql_contratos)

