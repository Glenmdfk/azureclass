# SQL Server Database Connection Properties
VSO_CONFIG = {
    'Driver': 'SQL Server',
    'Server': '10.106.18.166',
    'Database': 'MIS',
    'UID': 'User_WF_O',
    'Password': '1993Mexico'
}

CMS_CONFIG ={
    'jar' : '//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots/Libraries/informix-jdbc-complete-4.50.4.1.jar',
    'host': '10.103.133.77:50000',
    'dbname' : 'cms',
    'servername' : 'cms_net',
    'user': 'jx1636', #'os940m',
    'password': 'Madero896523#'
    }

CMS_BACKUP_CONFIG ={
    'jar' : '//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots/Libraries/informix-jdbc-complete-4.50.4.1.jar',
    'host': '10.106.161.48:50000',
    'dbname' : 'cms',
    'servername' : 'cms_net',
    'user': 'jx1636', #'os940m',
    'password': 'Madero896523#'
    }

DATAMANAGEMENT_CONFIG ={
    'Driver': 'SQL Server',
    'Server': '10.103.133.108',
    'Database': 'DataManagement',
    'UID': 'ETLUserMaster',
    'Password': 'i0i0_$p3c1Al%=!'
    }

DATAMART_CONFIG ={
    'Driver': 'SQL Server',
    'Server': '10.103.133.108',
    'Database': 'DATAMART_ATC',
    'UID': 'ETLUserMaster',
    'Password': 'i0i0_$p3c1Al%=!'
    }

OB138_CONFIG ={
    'Driver': 'SQL Server',
    'Server': '10.103.133.108',
    'Database': 'Outbound__138',
    'UID': 'ETLUserMaster',
    'Password': 'i0i0_$p3c1Al%=!'
    }

Portabilidad_CONFIG ={
    'Driver': 'SQL Server',
    'Server': '10.103.133.108',
    'Database': 'Portabilidad',
    'UID': 'ETLUserMaster',
    'Password': 'i0i0_$p3c1Al%=!'
    }

BLUE_CONFIG ={
    'Driver': 'SQL Server',
    'Server': '135.208.51.103',
    'Database': 'development_test',    
}

OI_BLUE_CONFIG ={
    'Driver': 'SQL Server',
    'Server': '135.208.51.103',
    'Database': 'OI',    
}

ETL_OI_BLUE_CONFIG ={
    'Driver': 'SQL Server',
    'Server': '135.208.51.103',
    'Database': 'OI',    
    'UID': 'ETLUserMaster',
    'Password': 'Vp6Y8@VD'
}

VERTICA_CONFIG = {
    'Server': '10.103.53.19',
    'Database': 'PRDVRTDL',
    'Port': '5433',
    'UID': 'gg421b',
    'Password': 'BbYAbCQ497$'
    }

VERTICA_CONFIG_MATRIX = {
    'Server': '10.103.53.19',
    'Database': 'PRDVRTDL',
    'Port': '5433',
    'UID': 'gg421b',
    'Password': 'BbYAbCQ497$'
    }

SDK_CONFIG2 = {
    'Driver': 'SQL Server',
    'Server': '10.103.156.45',
    'Database': 'CentralDWH',
    'UID': 'CN6253',
    'Password': 'Avaya.2023!'
    }

SDK_CONFIG = {
    'Driver': 'SQL Server',
    'Server': 'wfo-db.glb.cala.attmx.avayacloud.com',
    'Database': 'CentralDWH',
    'Port': '5433',
    'UID': 'CN6253',
    'Password': 'Avaya.2023!'
    }

CMS_CLOUD_CONFIG = {
    'Driver': 'SQL Server',
    'Server': '10.103.133.137',
    'Database': 'AVAYA',
    'UID': 's05556',
    'Password': 'M3xic0_2023*'
    }

#Definiciones Español Ingles
MESES_ESP = {
    'January' : 'Enero',
    'February' : 'Febrero',
    'March' : 'Marzo',
    'April' : 'Abril',
    'May' : 'Mayo',
    'June' : 'Junio',
    'July' : 'Julio',
    'August' : 'Agosto',
    'September' : 'Septiembre',
    'October' : 'Octubre',
    'November' : 'Noviembre',
    'December' : 'Diciembre'
}

DIAS_ESP = {
    'Monday' : 'Lunes',
    'Tuesday' : 'Martes',
    'Wednesday' : 'Miércoles',
    'Thursday' : 'Jueves',
    'Friday' : 'Viernes',
    'Saturday' : 'Sábado',
    'Sunday' : 'Domingo'
}

DIA_ESP = {
    'Monday' : 'Lunes',
    'Tuesday' : 'Martes',
    'Wednesday' : 'Xiércoles',
    'Thursday' : 'Jueves',
    'Friday' : 'Viernes',
    'Saturday' : 'Sábado',
    'Sunday' : 'Domingo'
}
