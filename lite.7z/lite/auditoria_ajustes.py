'''   ##########  Comienza importación de módulos ##########   '''
from datetime import date, timedelta, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Módulos Generales
from plyer import notification
import pathlib, socket, os, sys, warnings
import win32com.client as win32
import pandas as pd
import numpy as np
#Config Mail
olApp = win32.Dispatch('Outlook.Application')
olNS = olApp.GetNameSpace('MAPI')
#SQL Alchemy
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.config as config
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')
'''   ##########  Comienza definición de variables ##########   '''
Key = 'auditoria_ajustes'
warnings.filterwarnings("ignore")
#Detalles de ejecución
path_file = pathlib.Path(__file__) #Lectura archivo actual
st_pathn = str(path_file).upper() #Ruta Mayuscula
st_hostn = socket.gethostname() #Hostname
#Fechas
today = date.today()
#Variables de directorio
path_insumo = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/AUDITORIA ATC/BONUSES/ETL/Insumos/'
icono = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/AUDITORIA ATC/BONUSES/DOCUMENTACION/att.ico'
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')
'''   ##########  Comineza ejecución del programa ##########   '''
class auditoria_ajustes:
    #0.Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
    #0.Queries
    def qry_clean(self, dStart, dEnd):
        try:
            qryclean = "DELETE FROM aud.tbl_bonificaciones WHERE CAST(dtDateCreate AS DATE) BETWEEN '" + str(dStart) + "' AND '" + str(dEnd) + "';"
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Consulta lista para limpiar del ' + str(dStart) + ' al '+ str(dEnd))
            return qryclean
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on qry_clean: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on qry_clean')
    #1.Conexión a DataManagement
    def conn_red(self):
        try:
            server = config.DATAMANAGEMENT_CONFIG["Server"]
            conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_ChardDM_Connection()})
            engine = create_engine(conn_url)
            conn = engine.raw_connection()
            cursor = conn.cursor()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa al servidor: ' + str(server))
            return engine, conn, cursor
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_red: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_red')
    #2.Base Politica
    def politica(self):
        try:
            base_name = 'Base_Politica.xlsx'
            df = pd.read_excel(
                io = path_insumo + base_name,
                engine="openpyxl",
                header=0,
                usecols="B:C",
                names=['Puesto','nMonto'],
                )
            df_politica = df.drop_duplicates()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Base politica lista para cruce')
            return df_politica
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on base_politica: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on base_politica')
    #3.Lista de archivos
    def list_of_files(self):
        try:
            list_files = []
            for i in os.listdir(path_insumo):
                if i.endswith('.xlsx') and i.startswith('Base_Ajustes'):
                    list_files.append(i)
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lista de archivos declarada')
            return list_files
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on list_of_files: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on list_of_files')
    #4.Leer excel
    def read_excel(self, i):
        try:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Leyendo ' + i)
            df = pd.read_excel(
                io = path_insumo + i,
                engine="openpyxl",
                header=0,
                usecols="A:AF",
                names=['nIdFolio','cIdCase','dtDateCreate','dFecha_aplicacion','cStatusSubscription','cAplicant','nAmmount','cIsUser','cUserAuth','nAccountId','nCustomerId','nContract','nMDN','cCurrentBalance','cCustomerType','cPlan','nAmountApr','cReasRej','cEstatus','cMotivoReal','dDateCreate','cAgrupacionCanal','cCanal','cPuesto','cRegion','cGerenteTda','cCoordinador','cGerenteRegional','cDirectorRegional','cAVP','cVpgm','cStatusEjecutivo'],
                )
            df_ajustes = df.where(pd.notnull(df), None)
            df_ajustes['nMDN'] = np.where(df_ajustes['nMDN'] == 'DEF', None, df_ajustes['nMDN'])
            df_ajustes[['nMDN','cRegion','cGerenteTda','cCoordinador','cGerenteRegional','cDirectorRegional','cAVP','cVpgm','cStatusEjecutivo']] = df_ajustes[['nMDN','cRegion','cGerenteTda','cCoordinador','cGerenteRegional','cDirectorRegional','cAVP','cVpgm','cStatusEjecutivo']].replace('#N/A','')
            dStart = dt.strftime(min(df_ajustes['dDateCreate']),'%Y-%m-%d')
            dEnd = dt.strftime(max(df_ajustes['dDateCreate']),'%Y-%m-%d')
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lectura de ' + i + ' completada')
            return df_ajustes, dStart, dEnd
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on read_excel: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on read_excel')    
    #5.Transformaciones
    def transform(self, df_politica, df_ajustes):
        try:
            df_m = pd.merge(df_ajustes, df_politica, left_on='cPuesto', right_on='Puesto', how='left')
            df_m['cPuestoCorrecto'] = np.where((df_m['cPuesto'] == None) | (df_m['cPuesto'] == '')
                | (df_m['cPuesto'] == '-') | (df_m['cPuesto'] == '0') | (df_m['cPuesto'] == 'NULL')
                | (df_m['cPuesto'] == 'OTROS'), 'Puesto no visible en base de ajustes'
                ,np.where(df_m['cCanal'] == 'PRUEBAS', 'Pruebas', 'Si'))
            df_m['monto1'] = np.where(((df_m['cPuesto'] == 'NULL') | (df_m['cPuesto'] == '-')) & ((df_m['cAgrupacionCanal'] == 'CONTACT CENTER')
                | (df_m['cAgrupacionCanal'] == 'CONTACT CENTER') | (df_m['cAgrupacionCanal'] == 'CC')), 1500
                ,np.where((df_m['cCanal'] == 'ED') | (df_m['cAgrupacionCanal'] == 'DISTRIBUIDORES') | (df_m['cCanal'] == 'DISTRIBUIDORES'), 1200
                ,np.where((df_m['cPuesto'] == '0') | (df_m['cPuesto'] == 'OTROS') | (df_m['cPuesto'] == '-'), None, df_m['nMonto'])))
            df_m['cMontoDeAcuerdo'] = np.where((df_m['monto1'] == None) | (df_m['monto1'].notna().astype(int) == 0), 'No Data'
                ,np.where((df_m['monto1'] < df_m['nAmmount']) & (df_m['cEstatus'] == 'CERRADO'), 'Autorizado'
                ,np.where((df_m['monto1'] < df_m['nAmmount']) & (df_m['cEstatus'] != 'CERRADO'), 'No', 'Si')))
            df_m['nAmountApr'] = np.where((df_m['nAmountApr'] == '') | (df_m['nAmountApr'].notna().astype(int) == 0), None, df_m['nAmountApr'])
            df_m['dtLoad'] = dt.now()
            df_bonificaciones = df_m[['nIdFolio','cIdCase','dtDateCreate','dFecha_aplicacion','cStatusSubscription','cAplicant','nAmmount','cIsUser','cUserAuth','nAccountId','nCustomerId','nContract','nMDN','cCurrentBalance','cCustomerType','cPlan','nAmountApr','cReasRej','cEstatus','cMotivoReal','dDateCreate','cAgrupacionCanal','cCanal','cPuesto','cRegion','cGerenteTda','cCoordinador','cGerenteRegional','cDirectorRegional','cAVP','cVpgm','cStatusEjecutivo','cPuestoCorrecto','nMonto','cMontoDeAcuerdo','dtLoad']]
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Dataframe listo para carga')
            return df_bonificaciones
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on transform: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on transform')
    #6.Carga SQL
    def load_df(self, qryclean, df_bonificaciones, engine, conn, cursor):
        try:
            cursor.execute(qryclean)
            conn.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpiando aud.tbl_bonificaciones')
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(
            conn, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            df_bonificaciones.to_sql('tbl_bonificaciones', engine, index=False, if_exists="append", schema="aud")
            conn.commit()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga Completada')
            return df_bonificaciones
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on load_df: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on load_df')
    #7.Notificación
    def notification(self, resultado, proc):
        try:
            if resultado.find('Error') >= 1: mensaje = proc + ' no pudo finalizar por un error en el proceso, favor de contactar a desarrollo'
            else: mensaje = proc + ' ha finalizado exitosamente'
            notification.notify(
                title=resultado,
                message=mensaje,
                app_icon=icono,
                timeout=8
            )
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Notificación correcta')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on notification: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on notification')
    #9.Proceso completo
    def load(self, proc):
        try:
            engine, conn, cursor = auditoria_ajustes.conn_red(self)
            df_politica = auditoria_ajustes.politica(self)
            list_files = auditoria_ajustes.list_of_files(self)
            for i in list_files:
                df_ajustes, dStart, dEnd = auditoria_ajustes.read_excel(self, i)
                df_bonificaciones = auditoria_ajustes.transform(self, df_politica, df_ajustes)
                qryclean = auditoria_ajustes.qry_clean(self, dStart, dEnd)
                auditoria_ajustes.load_df(self, qryclean, df_bonificaciones, engine, conn, cursor)
            resultado = 'Proceso completado'
            status = 'OK'
            msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Nothing went wrong'
        except Exception as error:
            resultado = 'Error durante la ejecución'
            auditoria_ajustes.notification(self, resultado)
            status = 'NOK'
            msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' + repr(error)
        finally:
            auditoria_ajustes.notification(self, resultado, proc)
            conn.close()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            return status, msg_proc
def main():
    runObj = auditoria_ajustes()
    run_process = str(Key)
    result = runObj.load(run_process)
main()
'''
'''