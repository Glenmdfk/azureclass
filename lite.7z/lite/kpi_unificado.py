#Modulos propios
import sys, os
from os.path import basename
import shutil 
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.lib_mail as mail
import Libraries.config as config
import Libraries.distro as distro
import Libraries.data_profiling as dp
#Selenium
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium import webdriver
from time import sleep
from datetime import date, datetime, timedelta
from datetime import date, timedelta, datetime as dt
from dateutil.relativedelta import relativedelta
import warnings
import socket
import pandas as pd
import numpy as np
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
#Email
import win32com.client as win32
olApp = win32.Dispatch('Outlook.Application')
olNS = olApp.GetNameSpace('MAPI')
#Email SMTP
import smtplib
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.message import EmailMessage as msg
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
warnings.filterwarnings("ignore")
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')

# Variables fecha
today = date.today()
ayer = today - timedelta(days = 1)
inicio = today - timedelta(days = 7)
hoy_6 = today - timedelta(days = 6)
difference = today - inicio
variable_inicial = 'input[value="' + dt.strftime(hoy_6, '%d/%m/%Y') + '"]'
variable_final = 'input[value="' + dt.strftime(today, '%d/%m/%Y') + '"]'

filepath = '\\\\135.208.36.251\\Op_Intelligence\\MASTER_REPORTS\\SPEECH ANALYTICS\\ETL\\INSUMOS\\'
path_download = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/SPEECH ANALYTICS/ETL/INSUMOS/'
historico = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/SPEECH ANALYTICS/ETL/INSUMOS/CARGADOS/'

jVar = pd.read_json('C:\\App\\Variables\\Domain.json')
user = jVar['Username']['CFR']
us_wfo = user[:6]
password = jVar['Password']['PASS_CFR']

hostname = str(socket.gethostname())
table_both ='tbl_wfo'
schema_both= 'echi'
fecha_red = 'dDate'
fecha_blue = 'call_date'


'''   ##########  Comienza definición de variables ##########   '''


class kpi_unificado:
        #Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
        self.no_info = 0
    #Conexion server
    def conn_db (self):
        try:
            conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_ChardDM_Connection()})
            engine = create_engine(conn_url)
            connection = engine.raw_connection()
            crsr = connection.cursor()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa a servidor')
            return connection,engine,crsr
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on servidor: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on servidor')

    def conn_blue(self):
        try:
            conn_url, engine_blue, conn_blue, cursor_blue = dbConn.get_ETL_OIEngineBlue_Connection()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa OI Bue Server')
            return conn_blue, engine_blue, cursor_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_blue: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_blue')
    
    def dp_dates(self, conn):
        try:
            qry = '''
                SELECT CAST(dDate AS DATE) dFecha, COUNT(*) Reg
                    FROM echi.tbl_wfo
                WHERE CAST(dDate AS DATE) BETWEEN CAST(GETDATE()-7 AS DATE) AND CAST(GETDATE()-2 AS DATE)
                GROUP BY CAST(dDate AS DATE) ORDER BY dFecha
            '''
            df_val_wfo = pd.read_sql(qry, conn)
            df_fechas = pd.concat([pd.DataFrame([inicio + timedelta(days = i)],columns=['Fecha']) for i in range(difference.days)],ignore_index=True)
            df_fechas['Fecha_str'] = df_fechas['Fecha'].astype(str)
            df_merge = pd.merge(df_fechas, df_val_wfo, left_on='Fecha_str', right_on='dFecha', how='left')
            date_list = df_merge['Fecha'][df_merge['dFecha'].isnull()].values.tolist()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Validación realizada con éxito')
            return date_list
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on dp_dates: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on dp_dates')
    #6.scrapping_chat
    def wfo_scrapping(self, portal,fecha_ok, filename):
        try:
            #Variables Chrome
            url=portal
            driver_path = '//135.208.36.251/Op_Intelligence/DOCUMENTACION/CONTROLES_INTERNOS/Aplicaciones/chromedriver.exe'
            driver_service = Service(executable_path=driver_path)
            #Opciones de navegación
            prefs = {"download.default_directory" : filepath}
            options = Options()
            options.add_argument("--window-size=1950,1100")
            options.add_argument('--disable-extensions')
            options.add_experimental_option("prefs",prefs)
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            driver = webdriver.Chrome(service=driver_service, options=options)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': La configuración de Chrome esta lista')
            #Navegación iniciada
            driver.get(url)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Navegador iniciado')
            sleep(5)
            #Uid
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Introduciendo Usuario')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'username')))\
                .send_keys(us_wfo)
            sleep(2)
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CLASS_NAME, 'loginButton')))\
                .click()
            sleep(3)
            #Pwd
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Introduciendo Contraseña')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'password')))\
                .send_keys(password)
            sleep(2)
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CLASS_NAME, 'loginButton')))\
                .click()
            sleep(10)
            #Navegación
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Menú de funciones')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'as-navdrawer-arrow-btnEl')))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Speech Analytics')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'SPEECH_ANALYTICS')))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Interacciones')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR,
                    'div[tabid="SPEECH_ANALYTICS->SPEECH_ANALYZE->ANALYZE_INTERACTIONS"]')))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conjunto (filtro)')
            conj_class = 'x-btn.x-unselectable.x-box-item.x-btn-default-small.SA_silderMenuButton.m_button_metadata'
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CLASS_NAME, conj_class)))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Menú para Fechas')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="Fecha"]')))\
                .click()
            sleep(6)            
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Radio Button')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.XPATH, "(//*[@data-ref='displayEl'])[3]")))\
                .click()
            sleep(5)
            #fecha inicial
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpia fecha Inicial')
            print(variable_inicial)
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR,variable_inicial)))\
                .clear()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Fecha Inicial')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR,variable_inicial)))\
                .send_keys(fecha_ok)
            sleep(3)
            #fecha final
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpia fecha final')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, variable_final)))\
                .clear()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Fecha final')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, variable_final)))\
                .send_keys(fecha_ok)
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Boton Aplicar')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="Aplicar"]')))\
                .click()
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Boton Exportar')
                    
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'span[data-ref="btnEl"]')))\
                .click()
            sleep(5)
            
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Datos interaccion')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="Exportar datos de interacción"]')))\
                .click()
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Datos hasta 2 millones')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="Conjunto de resultados actual (hasta 2 millones)"]')))\
                .click()
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Continuar ')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="Continuar"]')))\
                .click()
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Nombre de archivo')
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' css')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'input[maxlength="128"]')))\
                .send_keys(filename)                            
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Terminar')
            WebDriverWait(driver, 5) \
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="Terminar"]')))\
                .click()
            sleep(5)
            #Navegación
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Menú de funciones')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'as-navdrawer-arrow-btnEl')))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Speech Analytics')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.ID, 'SPEECH_ANALYTICS')))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Interacciones')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR,
                    'div[tabid="SPEECH_ANALYTICS->SPEECH_REPORTS->EXPORTS"]')))\
                .click()
            sleep(90) ##Sugerencia 50 seg
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Descargar archivo')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="' + filename +'"]')))\
                .click()
            #Espera a que termine la descarga
            w = 0
            while w == 0:
                count = 0
                li = os.listdir(path_download)
                for w in li:
                    if w.endswith(".xlsx"):
                        count = count + 1
                if count == 0:
                    w = 0
                else:
                    w = 1
            sleep(15)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Eliminar archivo')
            WebDriverWait(driver, 5)\
                .until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'td[class="x-grid-cell x-grid-td x-grid-cell-reportHeaderDelete x-unselectable"]')))\
                .click()
            sleep(3)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Finaliza proceso scrapping con exito') #Sí
            WebDriverWait(driver, 5) \
            .until(EC.element_to_be_clickable((By.XPATH, '//*[text()="Sí"]')))\
            .click()
            sleep(5)
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S:') +' Archivo descargado con exito')
            driver.quit()
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on wfo_scrapping')
    
    def read_file(self,paht):
        try:
            df = pd.read_excel(paht,sheet_name='Speech',header=27,dtype={'ID de llamada del conmutador':np.str_})
            if paht.endswith('old.xlsx'):
                df['origin']='WFO'
            else:
                df['origin']='WFO_NEW'    

            #float
            df['% de tiempo de conversación del empleado']=df['% de tiempo de conversación del empleado'].replace('',None).astype('float64')
            df['% de tiempo de conversación superpuesta']=df['% de tiempo de conversación superpuesta'].replace('',None).astype('float64')
            df['% de tiempo en silencio']=df['% de tiempo en silencio'].replace('',None).astype('float64')
            
            #string
            df['ANI']=df['ANI'].replace('',None).astype('str')
            df['Dirección']=df['Dirección'].replace('',None).astype('str')
            df['Hora local de inicio']=df['Hora local de inicio'].replace('',None).astype('str')
            df['ID de llamada del conmutador']=df['ID de llamada del conmutador'].astype('str').replace('',None)
            df['ID de PBX']=df['ID de PBX'].replace('',None).astype('str')
            df['Pantalla']=df['Pantalla'].replace('',None).astype('str')
            
            df['Duración (segundos)']=pd.to_numeric(df['Duración (segundos)'])
            df['Número de conferencias']=pd.to_numeric(df['Número de conferencias'])
            df['Número de llamadas en espera']=pd.to_numeric(df['Número de llamadas en espera'])
            df['Número de llamadas transferidas']=pd.to_numeric(df['Número de llamadas transferidas'])
            df['Tiempo de conversación total del cliente (seg)']=pd.to_numeric(df['Tiempo de conversación total del cliente (seg)'])
            df['Tiempo de conversación total del empleado (seg)']=pd.to_numeric(df['Tiempo de conversación total del empleado (seg)'])
            df['Tiempo de finalización']=pd.to_numeric(df['Tiempo de finalización'])
            df['Tiempo total de conversación fuera de plazo (seg)']=pd.to_numeric(df['Tiempo total de conversación fuera de plazo (seg)'])
            df['Tiempo total en espera (s)']=pd.to_numeric(df['Tiempo total en espera (s)'])
            df['Tiempo total en silencio (seg)']=pd.to_numeric(df['Tiempo total en silencio (seg)'])
                       
            df_completo = df[['% de tiempo de conversación del empleado',
                    '% de tiempo en silencio',
                    'ANI',
                    '% de tiempo de conversación superpuesta',
                    'Dirección',
                    'Duración (segundos)',
                    'ID de llamada del conmutador',
                    'Hora local de inicio',
                    'ID de PBX',
                    'Número de conferencias',
                    'Número de llamadas en espera',
                    'Número de llamadas transferidas',
                    'Pantalla',
                    'Tiempo de conversación total del cliente (seg)',
                    'Tiempo de conversación total del empleado (seg)',
                    'Tiempo de finalización',
                    'Tiempo total de conversación fuera de plazo (seg)',
                    'Tiempo total en espera (s)',
                    'Tiempo total en silencio (seg)',
                    'origin'
                ]]
            
            df_red = df_completo.rename(columns={'% de tiempo de conversación del empleado':'nPorcConverEmpleado',
                '% de tiempo de conversación superpuesta':'nPorcConverSuperpuesta',
                '% de tiempo en silencio':'nPorcSilencio',
                'ANI':'cMDN',
                'Dirección':'cDireccion',
                'Duración (segundos)':'nDuracion',
                'Hora local de inicio':'dDate',
                'ID de llamada del conmutador':'cUCID',
                'ID de PBX':'cAnsLogin',
                'Número de conferencias':'nConferencias',
                'Número de llamadas en espera':'nEspera',
                'Número de llamadas transferidas':'nTransferidas',
                'Pantalla':'cPantalla',
                'Tiempo de conversación total del cliente (seg)':'nTiempoConversacionCliente',
                'Tiempo de conversación total del empleado (seg)':'nTiempoConversacionEmpleado',
                'Tiempo de finalización':'nFinalizacion',
                'Tiempo total de conversación fuera de plazo (seg)':'nTiempoFueraPlazo',
                'Tiempo total en espera (s)':'nTiempoEspera',
                'Tiempo total en silencio (seg)':'nTiempoSilencio',
                'origin':'origin'
                })
            
            df_blue = df_completo.rename(columns={'% de tiempo de conversación del empleado':'porcentaje_conversacion_empleado',
                '% de tiempo de conversación superpuesta':'porcentaje_conversacion_superpuesta',
                '% de tiempo en silencio':'porcentaje_silencio',
                'ANI':'mdn',
                'Dirección':'direction',
                'Duración (segundos)':'duration',
                'Hora local de inicio':'call_date',
                'ID de llamada del conmutador':'ucid',
                'ID de PBX':'answered_login',
                'Número de conferencias':'conference_number',
                'Número de llamadas en espera':'espera',
                'Número de llamadas transferidas':'transferidas',
                'Pantalla':'pantalla',
                'Tiempo de conversación total del cliente (seg)':'tiempo_conversacion_cliente',
                'Tiempo de conversación total del empleado (seg)':'tiempo_conversacion_empleado',
                'Tiempo de finalización':'tiempo_finalizacion',
                'Tiempo total de conversación fuera de plazo (seg)':'tiempo_fuera_plazo',
                'Tiempo total en espera (s)':'tiempo_espera',
                'Tiempo total en silencio (seg)':'tiempo_silencio',
                'origin':'origin'})

            
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa a servidor')
            return df_red,df_blue
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on read_file: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on read_file')    
    
    def delete_server (self,cursor,condb,table,sch,campo_fecha,fecha):

        query_clean="delete from "+sch+"."+table+" where CAST("+campo_fecha+" AS DATE)='"+fecha+"'"
        print(query_clean)
        try:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpiando '+table+' para '+fecha)
            cursor.execute(query_clean)
            condb.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Limpieza de  '+table+' completa')
            self.trns += 1
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on conn_db: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_db')  
    
    def move_file(self,origen,destino):
        try:
            shutil.move(origen,destino)
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': archivo movido a historico')
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on move_file: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on move_file')  

    def load_fast(self,df,egne,conexion,cursor,tbl,schem):
        try:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Inicia carga rapida a SQl')
            @event.listens_for(egne, "before_cursor_execute")
            def receive_before_cursor_execute(
            conexion, cursor, statement, params, context, executemany
            ):
                if executemany:
                    cursor.fast_executemany = True
            df.to_sql(tbl, egne, index=False, if_exists="append", schema=schem)
            conexion.commit()
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Error on load_fast: ' +  repr(error)) 
            self.err += 1
        else:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Carga de tabla '+tbl+' completada')
            self.trns += 1            
    
    def exec_sp(self,sp,parametro,connection,crsr):
        try:
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': inicia ejecucion de SP') 
            Query = 'exec '+ sp +' '+ str(parametro)
            crsr.execute(Query)
            connection.commit()
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Finaliza ejecucion de SP') 
        except Exception as error:
            print(datetime.strftime(datetime.now(), '%d/%m/%Y %H:%M:%S') + ': Error on exec_sp: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on exec_sp')
        
    def load(self,proc):
        try:
            con_red, engin_red, cursor_red = kpi_unificado.conn_db(self)
            #con_blue,engin_blue,cursos_blue = kpi_unificado.conn_blue(self)
            date_list = kpi_unificado.dp_dates(self, con_red)
            first_day_this_month = today - timedelta(today.day - 1)
            first_day_last_month = first_day_this_month - relativedelta(months = 1)
            
            #Scrapping
            for date in date_list:
                old_portal='https://wfo.mx.att.com/wfo/control/signin'
                new_portal='https://wfo-app.glb.cala.attmx.avayacloud.com/wfo/control/signin'
                fecha_ok = dt.strftime(date, '%d/%m/%Y')
                filename = 'WFO_' + str(dt.strftime(date, '%d%m%Y')) + '_old'
                new_filename = 'WFO_' + str(dt.strftime(date, '%d%m%Y'))
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') +': Fecha a procesar '+ fecha_ok)
            
                #try: kpi_unificado.wfo_scrapping(self, old_portal,fecha_ok, filename)
                #except: raise ValueError('Error on wfo_scrapping: ' + repr(error))
                try: kpi_unificado.wfo_scrapping(self, new_portal, fecha_ok, new_filename)
                except: raise ValueError('Error on wfo_scrapping new portal: ' + repr(error))
            #Carga
            lista = os.listdir(filepath)
            for j in lista:
                if j.endswith('.xlsx'):
                    completo = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/SPEECH ANALYTICS/ETL/INSUMOS/' + j
                    red, blue = kpi_unificado.read_file(self,completo)
                    kpi_unificado.delete_server(self,cursor_red,con_red,table_both,schema_both,fecha_red,str(dt.strftime(date,'%Y-%m-%d')))
                    kpi_unificado.load_fast(self,red,engin_red,con_red,cursor_red,table_both,schema_both)
                    kpi_unificado.move_file(self,completo,historico)
                    
                else:
                    print('omitir archivo')
            #Stored procedure
            if int(today.day) <= 8:
                yearm=[str(first_day_last_month.year * 100 + first_day_last_month.month),str(today.year*100+today.month)]
            else:
                yearm=[str(today.year*100+today.month)]
            for meses in yearm:         
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') +'procesando dbo.sp_CallsID para :' + meses)
                kpi_unificado.exec_sp(self,'dbo.sp_CallsID',meses,con_red,cursor_red)
                print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') +'procesando dbo.sp_KPI_Unificado para :' + meses)
                kpi_unificado.exec_sp(self,'dbo.sp_KPI_Unificado',meses,con_red,cursor_red)
        except Exception as error:
            print('Caught this error: ' + repr(error))
            status = 'NOK'
            msg_proc = 'Caught this error: ' + repr(error) if int(self.no_info) == 0 else 'SIN_INFO Caught this error: ' + repr(error)
            print('Error en el proceso')        
            mail.send_notification('Error Job', msg_proc, 'kpi_unificado', str(today), self.trns, self.err, hostname, my_lib_path)
        else:
            print('Nothing went wrong')
            status = 'OK'
            msg_proc =  'Nothing went wrong'
            mail.send_notification('Confirmation Job', msg_proc, 'kpi_unificado',str(today), self.trns, self.err, hostname, my_lib_path)
        finally:
            print("The 'kpi_unificado' is finished")
            return status, msg_proc
        
'''
def main():
    runObj = kpi_unificado()
    run_process = str('kpi_unificado')
    result = runObj.load(run_process)
main()
''' 