import jaydebeapi, pypyodbc, json, os
os.chdir('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots/Libraries/')
from sqlalchemy.engine.url import URL
from sqlalchemy import create_engine
import vertica_python as vertica
from . import config as config
import urllib

# Return the sql connection 
#DataManagement
def get_ETLDM_Connection():
     try:
          ETLDM_connection = pypyodbc.connect("Driver= {"+config.DATAMANAGEMENT_CONFIG["Driver"]+"} ;Server=" + config.DATAMANAGEMENT_CONFIG["Server"] + ";Database=" + config.DATAMANAGEMENT_CONFIG["Database"] + ";uid=" + config.DATAMANAGEMENT_CONFIG["UID"] + ";pwd=" + config.DATAMANAGEMENT_CONFIG["Password"])
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return ETLDM_connection

def get_TrustedDM_Connection():
     try:
          TrustedDM_connection = pypyodbc.connect("Driver= {"+config.DATAMANAGEMENT_CONFIG["Driver"]+"} ;Server=" + config.DATAMANAGEMENT_CONFIG["Server"] + ";Database=" + config.DATAMANAGEMENT_CONFIG["Database"] + ";Trusted_Connection=yes;")
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return TrustedDM_connection

def get_ChardDM_Connection():
     try:
          CharDM_connection = 'Driver=' + config.DATAMANAGEMENT_CONFIG['Driver'] + ';Server=' + config.DATAMANAGEMENT_CONFIG['Server'] + ';Database=' + config.DATAMANAGEMENT_CONFIG['Database'] + ';uid=' + config.DATAMANAGEMENT_CONFIG['UID'] + ';pwd=' + config.DATAMANAGEMENT_CONFIG["Password"]
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return CharDM_connection

def get_TrustedChardDM_Connection():
     try:
          TrustedCharDM_connection = 'Driver=' + config.DATAMANAGEMENT_CONFIG['Driver'] + ';Server=' + config.DATAMANAGEMENT_CONFIG['Server'] + ';Database=' + config.DATAMANAGEMENT_CONFIG['Database'] + ';Trusted_Connection=yes;'
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return TrustedCharDM_connection
#Datamart
def get_ETLDMA_Connection():
     try:
          ETLDMA_connection = pypyodbc.connect("Driver= {"+config.DATAMART_CONFIG["Driver"]+"} ;Server=" + config.DATAMART_CONFIG["Server"] + ";Database=" + config.DATAMART_CONFIG["Database"] + ";uid=" + config.DATAMART_CONFIG["UID"] + ";pwd=" + config.DATAMART_CONFIG["Password"])
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return ETLDMA_connection

def get_TrustedDMA_Connection():
     try:
          TrustedDMA_connection = pypyodbc.connect("Driver= {"+config.DATAMART_CONFIG["Driver"]+"} ;Server=" + config.DATAMART_CONFIG["Server"] + ";Database=" + config.DATAMART_CONFIG["Database"] + ";Trusted_Connection=yes;")
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return TrustedDMA_connection
#Outbound__138
def get_ETLOB138_Connection():
     try:
          ETLOB138_connection = pypyodbc.connect("Driver= {"+config.OB138_CONFIG["Driver"]+"} ;Server=" + config.OB138_CONFIG["Server"] + ";Database=" + config.OB138_CONFIG["Database"] + ";uid=" + config.OB138_CONFIG["UID"] + ";pwd=" + config.OB138_CONFIG["Password"])
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return ETLOB138_connection

def get_TrustedOB138_Connection():
     try:
          TrustedOB138_connection = pypyodbc.connect("Driver= {"+config.OB138_CONFIG["Driver"]+"} ;Server=" + config.OB138_CONFIG["Server"] + ";Database=" + config.OB138_CONFIG["Database"] + ";Trusted_Connection=yes;")
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return TrustedOB138_connection
     
def get_ChardOB138_Connection():
     try:
          CharOB138_connection = 'Driver=' + config.OB138_CONFIG['Driver'] + ';Server=' + config.OB138_CONFIG['Server'] + ';Database=' + config.OB138_CONFIG['Database'] + ';uid=' + config.OB138_CONFIG['UID'] + ';pwd=' + config.OB138_CONFIG["Password"]
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return CharOB138_connection
     
#PORTABILIDAD

def get_ChardPortabilidad_Connection():
     try:
          CharPortabilidad_connection = 'Driver=' + config.Portabilidad_CONFIG['Driver'] + ';Server=' + config.Portabilidad_CONFIG['Server'] + ';Database=' + config.Portabilidad_CONFIG['Database'] + ';uid=' + config.Portabilidad_CONFIG['UID'] + ';pwd=' + config.Portabilidad_CONFIG["Password"]
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return CharPortabilidad_connection

#Development_test
def get_TrustedBlue_Connection():
     try:
          TrustedBlue_connection = pypyodbc.connect("Driver= {"+config.OI_BLUE_CONFIG["Driver"]+"} ;Server=" + config.BLUE_CONFIG["Server"] + ";Database=" + config.BLUE_CONFIG["Database"] + ";Trusted_Connection=yes;")
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return TrustedBlue_connection

def get_TrustedEngineBlue_Connection():
     try:
          conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": 'Driver=' + config.BLUE_CONFIG['Driver'] + ';Server=' + config.BLUE_CONFIG['Server'] + ';Database=' + config.BLUE_CONFIG['Database'] + ';Trusted_connection="Yes"'})
          engine = create_engine(conn_url)
          conn = engine.raw_connection()
          cursor = conn.cursor()
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return conn_url, engine, conn, cursor
#OI Blue
def get_TrustedOIB_Connection():
     try:
          TrustedOIB_connection = pypyodbc.connect("Driver= {"+config.OI_BLUE_CONFIG["Driver"]+"} ;Server=" + config.OI_BLUE_CONFIG["Server"] + ";Database=" + config.OI_BLUE_CONFIG["Database"] + ";Trusted_Connection=yes;")
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return TrustedOIB_connection

def get_TrustedOIEngineBlue_Connection():
     try:
          conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": 'Driver=' + config.OI_BLUE_CONFIG['Driver'] + ';Server=' + config.OI_BLUE_CONFIG['Server'] + ';Database=' + config.OI_BLUE_CONFIG['Database'] + ';Trusted_connection="Yes"'})
          engine = create_engine(conn_url)
          conn = engine.raw_connection()
          cursor = conn.cursor()
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return conn_url, engine, conn, cursor

def get_ETL_OIEngineBlue_Connection():
     try:
          conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": 'Driver=' + config.ETL_OI_BLUE_CONFIG['Driver'] + ';Server=' + config.ETL_OI_BLUE_CONFIG['Server'] + ';Database=' + config.ETL_OI_BLUE_CONFIG['Database'] + ';uid=' + config.ETL_OI_BLUE_CONFIG['UID'] + ';pwd=' + config.ETL_OI_BLUE_CONFIG['Password']})
          engine = create_engine(conn_url)
          conn = engine.raw_connection()
          cursor = conn.cursor()
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return conn_url, engine, conn, cursor
     
#Vertica
def get_Vertica_Connection():
     try:
          Vertica_connection = vertica.connect(**json.loads('{"host" : "' + config.VERTICA_CONFIG['Server'] + '", "port" : 5433, "user" : "' + config.VERTICA_CONFIG['UID'] + '", "password" : "' + config.VERTICA_CONFIG['Password'] + '", "database" : "'+ config.VERTICA_CONFIG['Database'] +'", "read_timeout":600, "unicode_error" : "strict"}'))
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e          
     else:
          return Vertica_connection

#Vertica
def get_Vertica_Matrix_Connection():
     try:
          Vertica_connection = vertica.connect(**json.loads('{"host" : "' + config.VERTICA_CONFIG_MATRIX['Server'] + '", "port" : 5433, "user" : "' + config.VERTICA_CONFIG_MATRIX['UID'] + '", "password" : "' + config.VERTICA_CONFIG_MATRIX['Password'] + '", "database" : "'+ config.VERTICA_CONFIG_MATRIX['Database'] +'", "read_timeout":600, "unicode_error" : "strict"}'))
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e          
     else:
          return Vertica_connection
     
def get_Vertica_Connection_priv():
     try:
          with open('C:\\App\\Variables\\Domain.json') as Archivo:
               datos = json.load(Archivo)   
          Usuarios = datos['Username']
          Psw = datos['Password']
          Vertica_connection = vertica.connect(**json.loads('{"host" : "' + config.VERTICA_CONFIG['Server'] + '", "port" : 5433, "user" : "' + Usuarios['VERTICA'] + '", "password" : "' +  Psw['PASS_VERTICA'] + '", "database" : "'+ config.VERTICA_CONFIG['Database'] +'", "read_timeout":600, "unicode_error" : "strict"}'))
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e          
     else:
          return Vertica_connection


#SDK
def get_SDK_Connection():
     try:
          SDK_connection = pypyodbc.connect("Driver= {"+config.SDK_CONFIG["Driver"]+"} ;Server=" + config.SDK_CONFIG["Server"] + ";Database=" + config.SDK_CONFIG["Database"] + ";uid=" + config.SDK_CONFIG["UID"] + ";pwd=" + config.SDK_CONFIG["Password"])
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return SDK_connection

def get_ChardSDK_Connection():
     try:
          CharSDK_connection = 'Driver=' + config.SDK_CONFIG['Driver'] + ';Server=' + config.SDK_CONFIG['Server'] + ';Database=' + config.SDK_CONFIG['Database'] + ';uid=' + config.SDK_CONFIG['UID'] + ';pwd=' + config.SDK_CONFIG["Password"]
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:     
          return CharSDK_connection
#VSO
def get_VSO_Connection():
     try:
          VSO_connection = pypyodbc.connect("Driver= {"+config.VSO_CONFIG["Driver"]+"} ;Server=" + config.VSO_CONFIG["Server"] + ";Database=" + config.VSO_CONFIG["Database"] + ";uid=" + config.VSO_CONFIG["UID"] + ";pwd=" + config.VSO_CONFIG["Password"])
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return VSO_connection
#CMS
def get_CMS_Connection():
     try:
          CMS_Connection =  jaydebeapi.connect('com.informix.jdbc.IfxDriver',
                                             'jdbc:informix-sqli://' + config.CMS_CONFIG['host'] + '/' + config.CMS_CONFIG['dbname'] + '=' + config.CMS_CONFIG['servername'],
                                             {'user': config.CMS_CONFIG['user'], 'password': config.CMS_CONFIG['password']},
                                             config.CMS_CONFIG['jar'])
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return CMS_Connection

def get_CMS_BackUp_Connection():
     try:
          CMS_Connection =  jaydebeapi.connect('com.informix.jdbc.IfxDriver',
                                             'jdbc:informix-sqli://' + config.CMS_BACKUP_CONFIG['host'] + '/' + config.CMS_BACKUP_CONFIG['dbname'] + '=' + config.CMS_BACKUP_CONFIG['servername'],
                                             {'user': config.CMS_BACKUP_CONFIG['user'], 'password': config.CMS_BACKUP_CONFIG['password']},
                                             config.CMS_BACKUP_CONFIG['jar'])
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return CMS_Connection

def get_ETL_Engine_Connection():
     try:
          conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": 'Driver=' + config.DATAMANAGEMENT_CONFIG['Driver'] + ';Server=' + config.DATAMANAGEMENT_CONFIG['Server'] + ';Database=' + config.DATAMANAGEMENT_CONFIG['Database'] + ';uid=' + config.DATAMANAGEMENT_CONFIG['UID'] + ';pwd=' + config.DATAMANAGEMENT_CONFIG['Password']})
          engine = create_engine(conn_url)
          conn = engine.raw_connection()
          cursor = conn.cursor()
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e
     else:
          return engine, conn, cursor
     
def get_CMS_Cloud_Connection():
     try:
          params = urllib.parse.quote_plus("DRIVER=" + config.CMS_CLOUD_CONFIG["Driver"] + ";"
                                             "SERVER=" + config.CMS_CLOUD_CONFIG["Server"] + ";"
                                             "DATABASE=" + config.CMS_CLOUD_CONFIG["Database"] + ";"
                                             "UID=" + config.CMS_CLOUD_CONFIG["UID"] + ";"
                                             "PWD=" + config.CMS_CLOUD_CONFIG["Password"] + "")

          engine = create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))
          conn = engine.raw_connection()
          cursor = conn.cursor()
          return engine, conn, cursor
     except Exception as e:
          print('Error: {}'.format(str(e)))
          raise e   