'''   ##########  Comienza importación de módulos ##########   '''
from datetime import date, timedelta, datetime as dt
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Ejecución iniciada')
#Modulos generales
import os, sys, pathlib, socket, smtplib
import win32com.client as win32
from os.path import basename
import pandas as pd
#Email
olApp = win32.Dispatch('Outlook.Application')
olNS = olApp.GetNameSpace('MAPI')
#Email SMTP
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.message import EmailMessage as msg
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
#SQL Alchemy
from sqlalchemy import create_engine
from sqlalchemy.engine.url import URL
#Modulos propios
my_lib_path = os.path.abspath('//135.208.36.251/Op_Intelligence/DOCUMENTACION/Scripts/Bots')
sys.path.append(my_lib_path)
import Libraries.db_connection as dbConn
import Libraries.distro as distro
import Libraries.config as config
import Libraries.lib_mail as mail
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Librerías importadas correctamente')

'''   ##########  Comienza definición de variables ##########   '''
#Fechas
today = date.today()
today_mail = dt.strftime(today, '%Y-%m-%d')
vd_date = today - timedelta(days = today.isoweekday() - 1) #Día vencido)
msql_date = dt.strftime(vd_date, '%Y-%m-%d') #Fecha YYYY-mm-ddd
#Variables para csv
file_css = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/CCS/Reporte/BASE CCS ' + today_mail + '.csv'
distro_ccs = '//135.208.36.251/Op_Intelligence/MASTER_REPORTS/CCS/ETL/Distro.json'
#Detalles de ejecución
path_file = pathlib.Path(__file__)
st_hostn = socket.gethostname()
exec_path = str(os.getcwd())
#Mail Authentication
jVar = pd.read_json('C:/App/Variables/Domain.json')
UsMail = jVar['Username']['OUTLOOK']
PsMail = jVar['Password']['PASS_OUTLOOK']
MailFrom = distro.GeneralNew['Sender']
Host = '135.208.33.18'
Port = 587
#Class name
Key = 'Base_CCS'
print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Variables declaradas')

'''   ##########  Comineza ejecución del programa ##########   '''
class Base_CCS:
    #1.Transacciones y errores
    def __init__(self):
        self.trns = 0
        self.err = 0
        self.no_info = 0
    #2.Conexión a SQL:
    def conn_red(self):
        try:
            server = config.DATAMANAGEMENT_CONFIG["Server"]
            conn_url = URL.create("mssql+pyodbc", query={"odbc_connect": dbConn.get_ChardDM_Connection()})
            engine = create_engine(conn_url)
            conn = engine.raw_connection()
            cursor = conn.cursor()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Conexión éxitosa al servidor: ' + str(server))
            return engine, conn, cursor
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on conn_red')
    #3.Queries
    def queries(self):
        qry_val = "SELECT DISTINCT dFechaIncidencia FROM [dbo].[tbl_CCS] \
            WHERE dFechaIncidencia = '" + str(msql_date) + "'"
        qry_css = "SELECT nNoEmpleado \
                    ,cNombre \
                    ,cAlias \
                    ,cIncidencia \
                    ,dFechaEntrada \
                    ,dHoraEntrada \
                    ,dFechaSalida \
                    ,dHoraSalida \
                    ,dHorarioEntrada \
                    ,dHorarioSalida \
                    ,dFechaIncidencia \
                FROM [dbo].[tbl_CCS] \
                WHERE dFechaIncidencia = '" + str(msql_date) + "'"
        return qry_val, qry_css
    #4.Validación de disponibilidad
    def validation(self, engine, qry_val):
        try:
            df_val = pd.read_sql(qry_val, engine)
            last_date = max(df_val['dFechaIncidencia'])
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Validación correcta') 
            return last_date
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on validation')
    #5.Distro
    def distro_ccs(self):
        try:
            Distribution_list = pd.read_json(distro_ccs)
            w32_separator = '; '
            smtp_separator = ', '
            #To Distro
            list_to = []
            for i in Distribution_list['Distribution_List']['To']['to_distro']:
                list_to.append(Distribution_list['Distribution_List']['To']['to_distro'][i])
            MailTo = smtp_separator.join(list_to)
            wMailTo = w32_separator.join(list_to)
            #Cc Distro
            list_cc = []
            for j in Distribution_list['Distribution_List']['CC']['cc_distro']:
                list_cc.append(Distribution_list['Distribution_List']['CC']['cc_distro'][j])
            MailCC = smtp_separator.join(list_cc)
            wMailCC = w32_separator.join(list_cc)
            #To Client
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Lista de Distribución establecida') 
            self.trns += 1
            return MailTo, MailCC, wMailTo, wMailCC
        except Exception as error:
            self.err += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on distro_ccs')
    #6.Generar archivo
    def generate_css(self, engine, qry_css):
        try:
            df_css = pd.read_sql(qry_css, engine)
            df_csv = df_css[['nNoEmpleado', 'cNombre', 'cAlias', 'cIncidencia', 'dFechaEntrada', 'dHoraEntrada', 'dFechaSalida', 'dHoraSalida', 'dHorarioEntrada', 'dHorarioSalida', 'dFechaIncidencia']]
            df_csv.to_csv(file_css, index=False)
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Base CSV Generada correctamente') 
        except Exception as error:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            self.err += 1
            raise ValueError('Error on generate_css')
    #7.Envío df_csv correo SMTP
    def send_file_SMTP(self, MailTo, MailCC):
        try:
            subject = 'OM | Base CCS | ' + today_mail
            body = '''
            <html><head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <style type="text/css">
                p {font-size: 11pt; font-family: 'calibri'}
                table {border: 0px; border-spacing:0;}
                thead tr th {border: 0.5px solid black;text-align: center; background: rgb(91,155,213); color: white;}
                tbody {border-spacing:0; text-align: center; border: 0.5px solid black;}
            </style>
            </head>
            <body>
                <p>
                Saludos!<br>
                <br> Les compartimos la sabana de CCS.<br>
                <br> Para cualquier duda o comentario mandar un correo a:<br>
                <ul>
                    <li>Mexico ATC OI (mx.atcoperativeintelligenc@mx.att.com)</li>
                    <li>SUAREZ FERNANDEZ, OCTAVIO (os940m@mx.att.com)</li>
                    <li>JAIMES MARTINEZ JESUS ENRIQUE (jj0669@att.com)</li>
                </ul>
                <br> Saludos Cordiales.<br><br>
                <b style="color:black;">Operational Intelligence</b><br>
                <b style="color:#0070C0">Customer and Enterprise Care</b><br>
                <b style="color:#FB1F6E">#CambiaElJuego </b>
                <b style="font-size:24.0pt;color:#BF0CEA">•</b><br><br>
                <p>
                <b style="color:#00B0F0">AT&T México</b><br>
                Blvd Manuel Ávila Camacho 5 Lomas de Sotelo, Naucalpan de Juárez, Estado de México, CP 53390<br><br>
                El uso o divulgación fuera de las empresas AT&T está prohibido, excepto mediante acuerdo escrito.
                Este mensaje y cualesquiera archivos adjuntos contienen información confidencial de la empresa dirigidos exclusivamente para los destinatarios.
                Si usted ha recibido este mensaje por error, favor de no reenviar o distribuir a cualquier otra persona
                , pero favor de llamar al teléfono [55.30302737]  para reportar el error y posteriormente le pedimos borrar este mensaje de su sistema
                </p>
            </body>
            </html>
            '''
            part = MIMEBase('application', "octet-stream")
            with open(file_css, "rb") as fil:
                part = MIMEApplication(
                    fil.read(),
                    Name=basename(file_css)
                )
            # After the file is closed
            part['Content-Disposition'] = 'attachment; filename="%s"' % basename(file_css)
            load_msg = msg()
            load_msg = MIMEMultipart()
            load_msg['From'] = MailFrom
            load_msg['To'] = MailTo
            load_msg['Cc'] = MailCC
            load_msg['Subject'] = subject
            load_msg.attach(MIMEText(body, 'html'))
            load_msg.attach(part)
            load_conn = smtplib.SMTP(host = Host,port = Port)
            load_conn.starttls()
            load_conn.login(UsMail, PsMail)
            load_conn.send_message(load_msg)
            load_conn.quit()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Sabana CCS enviada con SMTP')
        except Exception as error:
            self.err += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on send_file_SMTP')
    #7.Envío df_csv correo WIN32
    def send_file_W32(self, wMailTo, wMailCC):
        try:
            mailItem = olApp.CreateItem(0)
            subject = 'OM | Base CCS | ' + today_mail
            body = '''
            <html><head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <style type="text/css">
                p {font-size: 11pt; font-family: 'calibri'}
                table {border: 0px; border-spacing:0;}
                thead tr th {border: 0.5px solid black;text-align: center; background: rgb(91,155,213); color: white;}
                tbody {border-spacing:0; text-align: center; border: 0.5px solid black;}
            </style>
            </head>
            <body>
                <p>
                Saludos!<br>
                <br> Les compartimos la sabana de CCS.<br>
                <br> Para cualquier duda o comentario mandar un correo a:<br>
                <ul>
                    <li>Mexico ATC OI (mx.atcoperativeintelligenc@mx.att.com)</li>
                    <li>SUAREZ FERNANDEZ, OCTAVIO (os940m@mx.att.com)</li>
                    <li>JAIMES MARTINEZ JESUS ENRIQUE (jj0669@att.com)</li>
                </ul>
                <br> Saludos Cordiales.<br><br>
                <b style="color:black;">Operational Intelligence</b><br>
                <b style="color:#0070C0">Customer and Enterprise Care</b><br>
                <b style="color:#FB1F6E">#CambiaElJuego </b>
                <b style="font-size:24.0pt;color:#BF0CEA">•</b><br><br>
                <p>
                <b style="color:#00B0F0">AT&T México</b><br>
                Blvd Manuel Ávila Camacho 5 Lomas de Sotelo, Naucalpan de Juárez, Estado de México, CP 53390<br><br>
                El uso o divulgación fuera de las empresas AT&T está prohibido, excepto mediante acuerdo escrito.
                Este mensaje y cualesquiera archivos adjuntos contienen información confidencial de la empresa dirigidos exclusivamente para los destinatarios.
                Si usted ha recibido este mensaje por error, favor de no reenviar o distribuir a cualquier otra persona
                , pero favor de llamar al teléfono [55.30302737]  para reportar el error y posteriormente le pedimos borrar este mensaje de su sistema
                </p>
            </body>
            </html>
            '''
            mailItem.BodyFormat = 2 #1 texto plano, 2 html
            mailItem.HTMLBody = body
            mailItem.Subject = subject
            mailItem.To = wMailTo
            mailItem.Cc = wMailCC
            mailItem.Sensitivity  = 2
            mailItem.SentOnBehalfOfName = MailFrom
            mailItem.Attachments.Add(file_css)
            mailItem.Send()
            self.trns += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Sabana CCS enviada con WIN32')
        except Exception as error:
            self.err += 1
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Caught this error: ' +  repr(error)) 
            raise ValueError('Error on send_file_W32')
    #8.Ejecución del proceso
    def load(self, proc):
        try:
            MailTo, MailCC, wMailTo, wMailCC = Base_CCS.distro_ccs(self)
            engine, conn, cursor = Base_CCS.conn_red(self)
            qry_val, qry_css = Base_CCS.queries(self)
            last_date = Base_CCS.validation(self, engine, qry_val)
            if str(last_date) != str(msql_date):
                self.no_info += 1
                raise ValueError('NO_INFO')
            else:
                Base_CCS.generate_css(self, engine, qry_css)
                try:Base_CCS.send_file_SMTP(self, MailTo, MailCC)
                except:Base_CCS.send_file_W32(self, wMailTo, wMailCC)
                status = 'OK'
                msg_proc =  dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ': Nothing went wrong'
        except Exception as error:
            status = 'NOK'
            msg_proc = 'Caught this error: ' + repr(error) if int(self.no_info) == 0 else 'SIN_INFO Caught this error: ' + repr(error)
            mail.send_notification('Error Job', msg_proc, 'Envio Base CCS', str(today), self.trns, self.err, st_hostn, exec_path)
        else:
            status = 'OK'
            msg_proc =  'Nothing went wrong'
            mail.send_notification('Confirmation Job', msg_proc, 'Envio Base CCS', str(today), self.trns, self.err, st_hostn, exec_path)
        finally:
            print(dt.strftime(dt.now(), '%d/%m/%Y %H:%M:%S') + ": The '" + proc + "' is finished")
            print(status, msg_proc)
            return status, msg_proc
'''
def main():
    runObj = Base_CCS()
    run_process = str(Key)
    result = runObj.load(run_process)
main()
'''